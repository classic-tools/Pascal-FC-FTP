/* Output from p2c, the Pascal-to-C translator */
/* From input file "pfccomp.pas" */


#include <p2c/p2c.h>
/* p2c: pfccomp.pas, line 1: 
 * Note: Unexpected name "progfile" in program header [262] */
/* p2c: pfccomp.pas, line 1: 
 * Note: Unexpected name "listfile" in program header [262] */
/* p2c: pfccomp.pas, line 1: 
 * Note: Unexpected name "objfile" in program header [262] */

/* Hack for non-char I/O. */
#define GETBINFILEBUF(f,type)    (*(((f)->__CAT__(f,_BFLAGS) == 1 &&   \
			       (((f)->__CAT__(f,_BFLAGS) = 2),   \
				fread(&((f)->__CAT__(f,_BUFFER)),  \
				      sizeof(type),1,(f)->file))),\
			      &((f)->__CAT__(f,_BUFFER))))
#define PUTBINFILE(f,type)        (fwrite(&((f)->__CAT__(f,_BUFFER)),sizeof(type),1,(f)->file),  \
			    ((f)->__CAT__(f,_BFLAGS) = 0))
#define SETUPBINFILEBUF(f,type)   ((f)->__CAT__(f,_BFLAGS) = 0)


/* Pascal-FC "universal" compiler system */
/* compiler "shell " */



/* @(#)globcons.i4.1 10/24/89 */

#define alng            10   /* length of identifiers */

#define xmax            LONG_MAX

#define omax            200   /* largest op-code for p-machine */
#define funmax          omax   /* highest function number */


/* impcons.i */
/* BM 1 version */


#define target          "UNIX"

#define maxmons         10   /* maximum monitor in a program */
#define maxcapsprocs    10   /* maximum exported procedures from a monitor */
#define intermax        10   /* max no. of mapped ipc primitives */
#define tmax            150   /* max size of symbol table */
#define bmax            50   /* max size of block table */
#define amax            20   /* max size of array table */
#define casemax         20   /* max number of case labels or selects */
#define chanmax         20   /* maximum size of channel table - gld */
#define cmax            2000   /* max size of p-code array */
#define lmax            7   /* max depth of block nesting */
#define smax            1500   /* max size of string table */
#define rmax            50   /* real constant table limit */
#define etmax           20   /* enumeration type upper bounds table */

#define llng            121   /* max source input line length */
#define tabstop         3   /* for 1 implementation - gld */
#define tabchar         9

#define fals            0
#define tru             1
#define charl           0   /* first legal ascii character */
#define charh           127   /* last legal ascii character */

#define intmax          32767   /* maximum integer on target */
#define intmsb          16   /* most sig. bit in target integer */

#define realmax         1e38
/* maximum real number on target
                                                                           or host, whichever is smaller */
#define minreal         1e-37   /* smallest real (for division) */

#define emax            38   /* maximum real exponent on target */
#define emin            (-emax)

#define bsmsb           7   /* most sig. bit in target bitset */

#define impfiles        false
#define impmapping      false
#define imptiming       false
#define impreals        true

#define monvarsize      2
#define protvarsize     3
#define chansize        3
#define entrysize       3   /* space for a process entry point */
#define sfsize          6   /* size of "frame" in a select statement */


#define bitsetsize      1
#define intsize         1
#define boolsize        1
#define charsize        1
#define semasize        1
#define condvarsize     1
#define synchrosize     0
#define procsize        1
#define enumsize        1
#define realsize        1


#define objalign        1

#define pushdown        false

/* interpreter-specific constants */

#define stepmax         8

#define statmax         200000L   /* maximum statements before "livelock */

/* NOTE - make (stmax - (stkincr * pmax)) >= stkincr */

#define stmax           5000
#define stkincr         200
#define pmax            20
#define msb             7


#define actrecsize      5   /* size of subprogram "housekeeping" block */




/* @(#)globtypes.i4.7 11/8/91 */


typedef enum {
  ldadr, ldval, ldind, updis, cobeg, coend, wait, asignal, stfun, ixrec, jmp,
  jmpiz, for1up, for2up, mrkstk, callsub, ixary, ldblk, cpblk, ldcon, ifloat,
  readip, wrstr, wrval, stop, retproc, retfun, repadr, notop, negate, store,
  relequ, relneq, rellt, relle, relgt, relge, orop, add, sub, andop, mul,
  divop, modop, rdlin, wrlin, selec0, chanwr, chanrd, delay, resum, enmon,
  exmon, mexec, mretn, lobnd, hibnd, pref, sleap, procv, ecall, acpt1, acpt2,
  rep1c, rep2c, btest, enmap, wrfrm, w2frm, wrsfm, wrbas, power2, slabl,
  blokk, param, case1, case2, selec1, sinit, prtex, prtjmp, prtsel, prtslp,
  prtcnd
} opcode;
/* p2c: pfccomp.pas, line 116:
 * Note: Line breaker spent 0.0 seconds, 5000 tries on line 130 [251] */

typedef long index_;

typedef Char alfa_[alng];
typedef enum {
  konstant, variable, type1, prozedure, funktion, monproc, address, grdproc,
  xgrdproc
} object;



typedef enum {
  notyp, ints, reals, bools, chars, arrays, records, semafors, channels,
  monvars, condvars, synchros, adrs, procs, entrys, enums, bitsets, protvars,
  protq
} types;

typedef long typset;


typedef Char fnametype[30];

typedef struct order {
  unsigned f : 7;
/* p2c: pfccomp.pas, line 136:
 * Note: Field width for F assumes enum opcode has 84 elements [105] */
  Signed int x : 4;
  long y;
  unsigned instyp : 5;
/* p2c: pfccomp.pas, line 139:
 * Note: Field width for INSTYP assumes enum types has 19 elements [105] */
  long line;
} order;

typedef order orderarray[cmax + 1];

typedef struct objorder {
  uchar f;
  Signed int x : 4;
  long y, l;
} objorder;

typedef objorder objorderarray[cmax + 1];

typedef struct tabrec {
  alfa_ name;
  index_ link;
  unsigned obj : 4;
/* p2c: pfccomp.pas, line 157:
 * Note: Field width for OBJ assumes enum object has 9 elements [105] */
  unsigned typ : 5;
/* p2c: pfccomp.pas, line 158:
 * Note: Field width for TYP assumes enum types has 19 elements [105] */
  index_ ref;
  unsigned normal : 1, lev : 3;
  long taddr;
  index_ auxref;
} tabrec;

typedef tabrec tabarray[tmax + 1];

typedef struct atabrec {
  unsigned inxtyp : 5, eltyp : 5;
/* p2c: pfccomp.pas, line 169:
 * Note: Field width for INXTYP assumes enum types has 19 elements [105] */
  index_ inxref, elref, low, high, elsize, size;
} atabrec;

typedef atabrec atabarray[amax];

typedef struct btabrec {
  index_ last, lastpar, psize, vsize;
  uchar tabptr;
} btabrec;

typedef btabrec btabarray[bmax];

typedef Char stabarray[smax + 1];
typedef double realarray[rmax];

typedef struct intabrec {
  unsigned tp : 5;
/* p2c: pfccomp.pas, line 186:
 * Note: Field width for TP assumes enum types has 19 elements [105] */
  unsigned lv : 3;
  long rf, vector, off, tabref;
} intabrec;

typedef intabrec intabarray[intermax];



/* unixtypes.i */

/* Pascal-FC "universal" compiler system */
/* implementation-dependent type declaration for Unix */


typedef struct objcoderec {
  fnametype fname;
  alfa_ prgname;
  objorderarray gencode;
  unsigned ngencode : 11;

  tabarray gentab;
  uchar ngentab;

  atabarray genatab;
  unsigned ngenatab : 5;

  btabarray genbtab;
  unsigned ngenbtab : 6;

  stabarray genstab;
  unsigned ngenstab : 11;
  realarray genrconst;

  uchar useridstart;


} objcoderec;


static char *progfilename;	/* YORK added in conversion. */

/* @(#)globvars.i4.4 6/16/92 */

Static fnametype filename;
Static FILE *progfile, *listfile;
Static alfa_ progname;
Static long lc, t, a, b, sx;
Static typset stantyps;
Static long display[lmax + 1];
Static tabarray tab;
Static atabarray atab;
Static btabarray btab;
Static stabarray stab;
Static realarray rconst;
Static double rnum;
Static long r, realindex, e;
Static orderarray code;
Static short ttt;
Static uchar useridstart;

Static intabarray intab;

Static long int_;
Static typset simpletyps, bittyps, ipctyps;

Static boolean success;




/* unixvars.i */

/* implementation-dependent variable declarations for 1 */

typedef struct {
    FILE *file;
    int objfile_BFLAGS ;   			   objcoderec objfile_BUFFER  ;
    char  name[120 ];
} _OBJFILE;

Static _OBJFILE xobjfile, *objfile = &xobjfile;




#define nkw             51   /* number of reserved words recognised */





typedef enum {
  intcon, realcon, charcon, string, notsy, plus, minus, times, idiv, rdiv,
  imod, andsy, orsy, eql, neq, gtr, geq, lss, leq, lparent, rparent, lbrack,
  rbrack, comma, semicolon, period, shriek, query, colon, becomes, arrow,
  constsy, typesy, varsy, functionsy, proceduresy, processsy, arraysy,
  recordsy, channelsy, programsy, ident, beginsy, ifsy, casesy, repeatsy,
  whilesy, forsy, foreversy, endsy, elsesy, untilsy, ofsy, dosy, tosy, thensy,
  selectsy, whensy, prisy, termsy, nullsy, exportsy, monitorsy, atsy,
  offsetsy, insy, adrsy, timeoutsy, resourcesy, guardedsy, requeuesy,
  forwardsy, entrysy, acceptsy, providessy, replicatesy, percent, rbrace
} symbol;
/* p2c: pfccomp.pas, line 299:
 * Note: Line breaker spent 0.0 seconds, 5000 tries on line 311 [251] */


typedef long symset[4];


typedef enum {
  erdec, erdup, erident, ertyp, erlparent, errparent, erlbrack, errbrack,
  ercolon, ersemi, erperiod, ereql, erbecomes, erprogram, erof, erthen,
  eruntil, erdo, erto, erbegin, erend, erselect, erexport, erreplicate, erpar,
  ervarpar, erparmatch, erchar, ersym, erstring, erlev, ernum, erassign,
  ercapsprocdecs, erinx, erent, ernotinproc, ermap, ertimetermelse, ercob,
  erfordec, erprovdec, ervar, erentmiss, ercasedup, erprocinrec, ersetlit,
  ernotprocvar, ersub, erconst, erentext, erentmatch, ernestacpt,
  eracptinproc, ernotingrdproc, eronlyingrdproc, ermustbeguarded, eronlyinres,
  ergrdcall
} er;
/* p2c: pfccomp.pas, line 314:
 * Note: Line breaker spent 0.0 seconds, 5000 tries on line 329 [251] */




typedef struct item {
  types typ;
  index_ ref;
} item;

typedef struct keytabrec {
  alfa_ key;
  symbol ksy;
} keytabrec;


typedef struct _REC_chantab {
  unsigned eltyp : 5;
/* p2c: pfccomp.pas, line 353:
 * Note: Field width for ELTYP assumes enum types has 19 elements [105] */
  index_ elref, elsize;   /* chantab */
} _REC_chantab;

typedef struct _REC_capsproctab {
  alfa_ name;
  boolean foundec;
} _REC_capsproctab;

typedef struct _REC_bounds {
  long upper, lower;
} _REC_bounds;


#define maxdigits       80
    /* maximum digits in real constant before point or e */


typedef struct conrec {
  types tp;
  union {
    long i;
    struct {
      long ordval;
      index_ ref;
    } U15;
    double r;
  } UU;
} conrec;


typedef struct _REC_casetab {
  index_ val, lc;
} _REC_casetab;

/* Local variables for pfcfront: */
struct LOC_pfcfront {
  boolean *success;
  jmp_buf _JL99;


  long linenum, lineold, linenew;
  symbol sy;
  alfa_ id;
  long inum, sleng;
  Char ch;
  Char line[llng];
  long cc, ll;
  long errs[3];
  long errpos;
  boolean skipflag;
  symset constbegsys, typebegsys, blockbegsys, facbegsys, statbegsys;
  keytabrec keywords[nkw];
  symbol sps[256];

  _REC_chantab chantab[chanmax];
  char chan;   /* index to chantab  */

  _REC_capsproctab capsproctab[maxcapsprocs];

  struct {
    char n;
    long startadds[maxmons];
  } montab;

  char ncapsprocs;
  uchar curcaps;
  boolean inguardedproc, numerror, negative;
  long digit, base;

  long legalchars[9];
  boolean incobegin, wascobegin, inprocessdec, inaloop;
  long et, internalnum;

  _REC_bounds bounds[etmax];
} ;

Local Void block PP((long *fsys, object lobj, long prt, long level,
		     struct LOC_pfcfront *LINK));





Local Void headermsg(tofile, LINK)
FILE **tofile;
struct LOC_pfcfront *LINK;
{
  fprintf(*tofile, "- Pascal-FC for %s - \n", target);
  fprintf(*tofile, "- Compiler Version P5.2\n\n");
  fprintf(*tofile, "G L Davies  &  A Burns, University of Bradford\n\n");
}  /* headermsg */

/* Local variables for initkeytab: */
struct LOC_initkeytab {
  struct LOC_pfcfront *LINK;
  long i;
} ;

Local Void sort(LINK)
struct LOC_initkeytab *LINK;
{

  /* sort table of keywords */
  boolean swap;
  long pass, j;
  keytabrec temp;



  swap = true;
  pass = 1;

  while (swap && pass < nkw) {
    swap = false;

    for (j = 1; j <= nkw - pass; j++) {
      if (strncmp(LINK->LINK->keywords[j - 1].key,
		  LINK->LINK->keywords[j].key, sizeof(alfa_)) > 0) {
	swap = true;
	temp = LINK->LINK->keywords[j - 1];
	LINK->LINK->keywords[j - 1] = LINK->LINK->keywords[j];
	LINK->LINK->keywords[j] = temp;
      }
    }

    pass++;
  }  /*while loop*/

}  /*sort*/


Local Void install(name, sym, LINK)
Char *name;
symbol sym;
struct LOC_initkeytab *LINK;
{
  keytabrec *WITH;

  WITH = &LINK->LINK->keywords[LINK->i - 1];
  memcpy(WITH->key, name, sizeof(alfa_));
  WITH->ksy = sym;
  LINK->i++;
}  /* install */



Local Void initkeytab(LINK)
struct LOC_pfcfront *LINK;
{

  /* set up table of keywords and sort */
  struct LOC_initkeytab V;


  V.LINK = LINK;
  V.i = 1;
  install("and       ", andsy, &V);
  install("array     ", arraysy, &V);
  install("begin     ", beginsy, &V);
  install("channel   ", channelsy, &V);
  install("cobegin   ", beginsy, &V);
  install("coend     ", endsy, &V);
  install("const     ", constsy, &V);
  install("div       ", idiv, &V);
  install("do        ", dosy, &V);
  install("else      ", elsesy, &V);
  install("end       ", endsy, &V);
  install("export    ", exportsy, &V);
  install("for       ", forsy, &V);
  install("forever   ", foreversy, &V);
  install("function  ", functionsy, &V);
  install("if        ", ifsy, &V);
  install("mod       ", imod, &V);
  install("monitor   ", monitorsy, &V);
  install("not       ", notsy, &V);
  install("null      ", nullsy, &V);
  install("of        ", ofsy, &V);
  install("or        ", orsy, &V);
  install("pri       ", prisy, &V);
  install("procedure ", proceduresy, &V);
  install("process   ", processsy, &V);
  install("program   ", programsy, &V);
  install("record    ", recordsy, &V);
  install("repeat    ", repeatsy, &V);
  install("select    ", selectsy, &V);
  install("terminate ", termsy, &V);
  install("then      ", thensy, &V);
  install("to        ", tosy, &V);
  install("type      ", typesy, &V);
  install("until     ", untilsy, &V);
  install("var       ", varsy, &V);
  install("when      ", whensy, &V);
  install("while     ", whilesy, &V);
  install("at        ", atsy, &V);
  install("offset    ", offsetsy, &V);
  install("address   ", adrsy, &V);
  install("timeout   ", timeoutsy, &V);
  install("forward   ", forwardsy, &V);
  install("entry     ", entrysy, &V);
  install("accept    ", acceptsy, &V);
  install("provides  ", providessy, &V);
  install("replicate ", replicatesy, &V);
  install("in        ", insy, &V);
  install("case      ", casesy, &V);
  install("resource  ", resourcesy, &V);
  install("guarded   ", guardedsy, &V);
  install("requeue   ", requeuesy, &V);

  sort(&V);
}  /* initkeytab */


Local Void errormsg(LINK)
struct LOC_pfcfront *LINK;
{
  er k;

  fprintf(listfile, "\n Error diagnostics\n\n");
  for (k = erdec; (long)k <= (long)ergrdcall; k = (er)((long)k + 1)) {
    if (P_inset(k, LINK->errs)) {
      putc('E', listfile);
      fprintf(listfile, "%d - ", (int)k);
      switch (k) {

      case erdec:
	fprintf(listfile, " undeclared identifier\n");
	break;

      case erdup:
	fprintf(listfile, " identifier duplicated\n");
	break;

      case erident:
	fprintf(listfile, " identifier expected\n");
	break;

      case ertyp:
	fprintf(listfile, " type error\n");
	break;

      case erlparent:
	fprintf(listfile, " '(' expected\n");
	break;

      case errparent:
	fprintf(listfile, " ')' expected\n");
	break;

      case erlbrack:
	fprintf(listfile, " '[' expected\n");
	break;

      case errbrack:
	fprintf(listfile, " ']' expected\n");
	break;

      case ercolon:
	fprintf(listfile, " ':' expected\n");
	break;

      case ersemi:
	fprintf(listfile, " ';' expected\n");
	break;

      case erperiod:
	fprintf(listfile, " '.' expected\n");
	break;

      case ereql:
	fprintf(listfile, " '=' expected\n");
	break;

      case erbecomes:
	fprintf(listfile, " ':=' expected\n");
	break;

      case erprogram:
	fprintf(listfile, " 'program' expected\n");
	break;

      case erof:
	fprintf(listfile, " 'of' expected\n");
	break;

      case erthen:
	fprintf(listfile, " 'then' expected\n");
	break;

      case eruntil:
	fprintf(listfile, " 'until' or 'forever' expected\n");
	break;

      case erdo:
	fprintf(listfile, " 'do' expected\n");
	break;

      case erto:
	fprintf(listfile, " 'to' expected\n");
	break;

      case erbegin:
	fprintf(listfile, " 'begin' expected\n");
	break;

      case erend:
	fprintf(listfile, " 'end' expected\n");
	break;

      case erselect:
	fprintf(listfile, " 'select' expected\n");
	break;

      case erexport:
	fprintf(listfile, " 'export' expected\n");
	break;

      case erreplicate:
	fprintf(listfile, " 'replicate' expected\n");
	break;

      case erpar:
	fprintf(listfile, " error in parameter list\n");
	break;

      case ervarpar:
	fprintf(listfile, " must be var parameter\n");
	break;

      case erparmatch:
	fprintf(listfile,
		" parameter list does not match previous declaration\n");
	break;

      case erchar:
	fprintf(listfile, " illegal character\n");
	break;

      case ersym:
	fprintf(listfile, " unexpected symbol\n");
	break;

      case erstring:
	fprintf(listfile, " string expected\n");
	break;

      case erlev:
	fprintf(listfile, " level error\n");
	break;

      case ernum:
	fprintf(listfile, " number error\n");
	break;

      case erassign:
	fprintf(listfile, " assignment not permitted\n");
	break;

      case ercapsprocdecs:
	fprintf(listfile,
		" exported monitor/resource procedure(s) not declared\n");
	break;

      case erinx:
	fprintf(listfile, " must not be var parameter\n");
	break;

      case erent:
	fprintf(listfile, " malformed entry call\n");
	break;

      case ernotinproc:
	fprintf(listfile, " not allowed in a process\n");
	break;

      case ermap:
	fprintf(listfile, " this type must not be mapped\n");
	break;

      case ertimetermelse:
	fprintf(listfile, " 'timeout' 'terminate' and 'else'");
	fprintf(listfile, " mutually exclusive\n");
	break;

      case ercob:
	fprintf(listfile, " multiple cobegins\n");
	break;

      case erfordec:
	fprintf(listfile, " 'forward' declaration(s) not resolved\n");
	break;

      case erprovdec:
	fprintf(listfile, " 'provides' declaration(s) not resolved\n");
	break;

      case ervar:
	fprintf(listfile, " variable expected\n");
	break;

      case erentmiss:
	fprintf(listfile,
		" missing entry or entries declared in \"provides\"\n");
	break;

      case ercasedup:
	fprintf(listfile, " case label duplicated\n");
	break;

      case erprocinrec:
	fprintf(listfile, " processes not allowed in record fields\n");
	break;

      case ersetlit:
	fprintf(listfile, " invalid set literal\n");
	break;

      case ernotprocvar:
	fprintf(listfile, " variable is an array, not a process\n");
	break;

      case ersub:
	fprintf(listfile, " error in array subscript declaration\n");
	break;

      case erconst:
	fprintf(listfile, " constant expected\n");
	break;

      case erentext:
	fprintf(listfile, " no corresponding \"provides\" declaration\n");
	break;

      case erentmatch:
	fprintf(listfile, " does not match \"provides\" declaration\n");
	break;

      case ernestacpt:
	fprintf(listfile, " illegally nested accept\n");
	break;

      case eracptinproc:
	fprintf(listfile, " accept not allowed in subprogram\n");
	break;

      case ernotingrdproc:
	fprintf(listfile, " not allowed in a guarded procedure\n");
	break;

      case eronlyingrdproc:
	fprintf(listfile, " only allowed in a guarded procedure body\n");
	break;

      case ermustbeguarded:
	fprintf(listfile, " destination must be guarded procedure\n");
	break;

      case eronlyinres:
	fprintf(listfile, " only allowed in a resource\n");
	break;

      case ergrdcall:
	fprintf(listfile, " call not allowed within a resource\n");
	break;
      }/* case */
    }  /* if k in errs */
  }
}  /* errormsg */


Local Void endskip(LINK)
struct LOC_pfcfront *LINK;
{

  /* underline skipped part of input */
  while (LINK->errpos < LINK->cc) {
    putc('-', listfile);
    LINK->errpos++;
  }
  LINK->skipflag = false;
}  /* endskip */


Local Void fatal(n, LINK)
long n;
struct LOC_pfcfront *LINK;
{
  alfa_ msg[20];

  putc('\n', listfile);
  errormsg(LINK);
  memcpy(msg[0], "identifier", sizeof(alfa_));
  memcpy(msg[1], "blocks    ", sizeof(alfa_));
  memcpy(msg[2], "strings   ", sizeof(alfa_));
  memcpy(msg[3], "arrays    ", sizeof(alfa_));
  memcpy(msg[4], "levels    ", sizeof(alfa_));
  memcpy(msg[5], "code      ", sizeof(alfa_));
  memcpy(msg[6], "channels  ", sizeof(alfa_));
  memcpy(msg[7], "select    ", sizeof(alfa_));
  memcpy(msg[8], "monprocs  ", sizeof(alfa_));
  memcpy(msg[9], "reals     ", sizeof(alfa_));
  memcpy(msg[10], "interrupts", sizeof(alfa_));
  memcpy(msg[11], "enum type ", sizeof(alfa_));
  memcpy(msg[12], "case      ", sizeof(alfa_));
  memcpy(msg[13], "monitors  ", sizeof(alfa_));

  fprintf(listfile, "\nFATAL ERROR - ");
  fprintf(listfile, "compiler table for %.*s is too small\n",
	  alng, msg[n - 1]);
  *LINK->success = false;
  longjmp(LINK->_JL99, 1);   /* terminate compilation */
}  /* fatal */

/* Local variables for nextch: */
struct LOC_nextch {
  struct LOC_pfcfront *LINK;
} ;

Local Void tabtospace(LINK)
struct LOC_nextch *LINK;
{

  /* replace tab character with sufficient spaces */
  LINK->LINK->ch = ' ';
  LINK->LINK->line[LINK->LINK->ll - 1] = LINK->LINK->ch;
  putc(LINK->LINK->ch, listfile);
  while (LINK->LINK->ll % tabstop != 0) {
/* p2c: pfccomp.pas, line 711:
 * Note: Using % for possibly-negative arguments [317] */
    LINK->LINK->ll++;
    if (LINK->LINK->ll <= llng)
      LINK->LINK->line[LINK->LINK->ll - 1] = LINK->LINK->ch;
    putc(LINK->LINK->ch, listfile);
  }
}  /* tabtospace */

Local Void fail(n, LINK)
long n;
struct LOC_nextch *LINK;
{
  putc('\n', listfile);
  errormsg(LINK->LINK);
  fprintf(listfile, "FATAL ERROR - ");
  if (n == 1)
    fprintf(listfile, "program incomplete\n");
  else
    fprintf(listfile, "input line too long\n");
  longjmp(LINK->LINK->_JL99, 1);
}  /* fail */




Local Void nextch(LINK)
struct LOC_pfcfront *LINK;
{

  /* read next character; process line end */
  struct LOC_nextch V;


  V.LINK = LINK;
  if (LINK->cc == LINK->ll) {
    if (P_eof(progfile))
      fail(1L, &V);
    if (LINK->errpos != 0) {
      if (LINK->skipflag)
	endskip(LINK);
      putc('\n', listfile);
      LINK->errpos = 0;
    }
    LINK->linenum++;
    fprintf(listfile, "%5ld %5ld ", LINK->linenum, lc);
    LINK->ll = 0;
    LINK->cc = 0;
    while (!P_eoln(progfile) && LINK->ll < llng - 1) {
      LINK->ll++;
      LINK->ch = getc(progfile);
      if (LINK->ch == '\n')
	LINK->ch = ' ';
      if (LINK->ch == tabchar)
	tabtospace(&V);
      else {
	putc(LINK->ch, listfile);
	LINK->line[LINK->ll - 1] = LINK->ch;
      }  /* else */
    }  /* now eoln or line buffer overflowed */
    if (!P_eoln(progfile))
      fail(2L, &V);
    putc('\n', listfile);
    LINK->ll++;
    LINK->line[LINK->ll - 1] = getc(progfile);
    if (LINK->line[LINK->ll - 1] == '\n')
      LINK->line[LINK->ll - 1] = ' ';
  }  /* if cc = ll */
  LINK->cc++;
  LINK->ch = LINK->line[LINK->cc - 1];
}  /*nextch*/

Local Void error(n, LINK)
er n;
struct LOC_pfcfront *LINK;
{
  long SET[3];

  if (LINK->errpos == 0)
    fprintf(listfile, "***********");
  if (LINK->cc <= LINK->errpos)
    return;
  if (n == erchar)
    fprintf(listfile, "%*c^%2d", (int)(LINK->cc - LINK->errpos), ' ', (int)n);
  else
    fprintf(listfile, "%*c^%2d ",
	    (int)(LINK->cc - LINK->errpos - 1), ' ', (int)n);
  LINK->errpos = LINK->cc + 3;
  P_addset(LINK->errs, (int)n);
}  /* error */




Local Void tolower_(alfavar, LINK)
Char *alfavar;
struct LOC_pfcfront *LINK;
{

  /* convert to lower case */
  char index;

  for (index = 0; index < alng; index++) {
    if (isupper(alfavar[index]))
      alfavar[index] = _tolower(alfavar[index]);
  }
}  /* tolower */

/* Local variables for insymbol: */
struct LOC_insymbol {
  struct LOC_pfcfront *LINK;
  long k, l;
  Char digitbuff[maxdigits];
} ;


Local Void collectint(LINK)
struct LOC_insymbol *LINK;
{
  LINK->l = 0;
  do {
    if (LINK->LINK->inum > intmax / 10)
      LINK->LINK->numerror = true;
    else {
      LINK->LINK->inum *= 10;
      LINK->l++;
      if (LINK->l > maxdigits)
	LINK->LINK->numerror = true;
      else
	LINK->LINK->digit = LINK->digitbuff[LINK->l - 1] - '0';
      if (LINK->LINK->digit > intmax - LINK->LINK->inum)
	LINK->LINK->numerror = true;
      else
	LINK->LINK->inum += LINK->LINK->digit;
    }
  } while (!(LINK->l == LINK->k || LINK->LINK->numerror));   /* collectint */
}


Local Void collectreal(LINK)
struct LOC_insymbol *LINK;
{

  /* collect whole number part from digit buffer */
  long l;

  l = 0;
  do {
    l++;
    if (rnum > realmax / 10.0)
      e++;
    else {
      rnum *= 10.0;
      if (l <= maxdigits) {
	LINK->LINK->digit = LINK->digitbuff[l - 1] - '0';
	if (LINK->LINK->digit <= realmax - rnum)
	  rnum += LINK->LINK->digit;
      }
    }
  } while (l != LINK->k);
  LINK->k -= e;
}  /* collectreal */





Local Void readscale(numerror, LINK)
boolean *numerror;
struct LOC_insymbol *LINK;
{
  long s, sign, digit;

  nextch(LINK->LINK);
  sign = 1;
  s = 0;
  if (LINK->LINK->ch == '+')
    nextch(LINK->LINK);
  else {
    if (LINK->LINK->ch == '-') {
      nextch(LINK->LINK);
      sign = -1;
    }
  }
  if (!isdigit(LINK->LINK->ch))
    *numerror = true;
  else {
    do {
      if (s > intmax / 10)
	*numerror = true;
      else {
	s *= 10;
	digit = LINK->LINK->ch - '0';
	if (digit > intmax - s)
	  *numerror = true;
	else
	  s += digit;
      }
      nextch(LINK->LINK);
    } while (isdigit(LINK->LINK->ch));
  }
  if (*numerror)
    e = 0;
  else
    e += s * sign;
}  /* readscale */


Local Void adjustscale(numerror, LINK)
boolean *numerror;
struct LOC_insymbol *LINK;
{
  long s;
  double d, t;

  if (LINK->k + e > emax) {
    *numerror = true;
    return;
  }
  while (e < emin) {
    rnum /= 10.0;
    e++;
  }
  s = labs(e);
  t = 1.0;
  d = 10.0;
  do {
    while (!(s & 1)) {
      s /= 2;
      d *= d;
    }
    s--;
    t = d * t;
  } while (s != 0);
  if (e < 0) {
    rnum /= t;
    return;
  }
  if (rnum > realmax / 10.0)
    *numerror = true;
  else
    rnum *= t;
}  /* adjustscale */




/*-----------------------------------------------------insymbol-*/


Local Void insymbol(LINK)
struct LOC_pfcfront *LINK;
{

  /* read next symbol (lexical analysis) */
  struct LOC_insymbol V;

  long i, j;



  V.LINK = LINK;
  LINK->lineold = LINK->linenew;
  LINK->linenew = LINK->linenum;
_L1:
  while (LINK->ch == ' ')
    nextch(LINK);
  if (P_inset(LINK->ch, LINK->legalchars)) {
    switch (LINK->ch) {

    case 'A':
    case 'B':
    case 'C':
    case 'D':
    case 'E':
    case 'F':
    case 'G':
    case 'H':
    case 'I':
    case 'J':
    case 'K':
    case 'L':
    case 'M':
    case 'N':
    case 'O':
    case 'P':
    case 'Q':
    case 'R':
    case 'S':
    case 'T':
    case 'U':
    case 'V':
    case 'W':
    case 'X':
    case 'Y':
    case 'Z':
    case 'a':
    case 'b':
    case 'c':
    case 'd':
    case 'e':
    case 'f':
    case 'g':
    case 'h':
    case 'i':
    case 'j':
    case 'k':
    case 'l':
    case 'm':
    case 'n':
    case 'o':
    case 'p':
    case 'q':
    case 'r':
    case 's':
    case 't':
    case 'u':
    case 'v':
    case 'w':
    case 'x':
    case 'y':
    case 'z':
      /*identifier or wordsymbol*/
      V.k = 0;
      memcpy(LINK->id, "          ", sizeof(alfa_));
      do {
	if (V.k < alng) {
	  V.k++;
	  LINK->id[V.k - 1] = LINK->ch;
	}
	nextch(LINK);
      } while (isalnum(LINK->ch));
      tolower_(LINK->id, LINK);
      i = 1;
      j = nkw;   /*binary search*/
      do {
	V.k = (i + j) / 2;
	if (strncmp(LINK->id, LINK->keywords[V.k - 1].key, sizeof(alfa_)) <= 0)
	  j = V.k - 1;
	if (strncmp(LINK->id, LINK->keywords[V.k - 1].key, sizeof(alfa_)) >= 0)
	  i = V.k + 1;
      } while (i <= j);
      if (i - 1 > j)
	LINK->sy = LINK->keywords[V.k - 1].ksy;
      else
	LINK->sy = ident;
      break;

    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9':
      /*number*/
      V.k = 0;
      LINK->inum = 0;
      LINK->sy = intcon;
      LINK->numerror = false;
      do {
	V.k++;
	if (V.k <= maxdigits)
	  V.digitbuff[V.k - 1] = LINK->ch;
	nextch(LINK);
      } while (isdigit(LINK->ch));
      if (LINK->ch != 'E' && LINK->ch != 'e' && LINK->ch != '.')
      {  /* integer */
	collectint(&V);
	if (LINK->numerror)
	  LINK->inum = 0;
	if (LINK->ch == '#') {  /* based integer */
	  nextch(LINK);
	  if ((unsigned long)LINK->inum < 32 &&
	      ((1L << LINK->inum) & 0x10104L) != 0)
	    LINK->base = LINK->inum;
	  else {
	    LINK->base = 16;
	    LINK->numerror = true;
	  }
	  LINK->inum = 0;
	  LINK->negative = false;
	  do {
	    if (LINK->negative)
	      LINK->numerror = true;
	    else {
	      if (LINK->inum > intmax / LINK->base) {
		if (LINK->inum <= intmax / (LINK->base / 2))
		  LINK->negative = true;
		else
		  LINK->numerror = true;
		LINK->inum %= intmax / LINK->base + 1;
/* p2c: pfccomp.pas, line 1024:
 * Note: Using % for possibly-negative arguments [317] */
	      }
	      LINK->inum *= LINK->base;
	      if (isdigit(LINK->ch))
		LINK->digit = LINK->ch - '0';
	      else {
		if (isupper(LINK->ch))
		  LINK->digit = LINK->ch + 10 - 'A';
		else {
		  if (islower(LINK->ch))
		    LINK->digit = LINK->ch + 10 - 'a';
		  else
		    LINK->numerror = true;
		}
	      }
	      if (LINK->digit >= LINK->base)
		LINK->numerror = true;
	      else
		LINK->inum += LINK->digit;
	    }
	    nextch(LINK);
	  } while (isalnum(LINK->ch));
	  if (LINK->negative) {
	    if (LINK->inum == 0)
	      LINK->numerror = true;
	    else
	      LINK->inum += -intmax - 1;
	  }
	  if (LINK->numerror)
	    LINK->inum = 0;
	}  /* based integer */
      }  /* integer */
      else {
	if (LINK->ch == '.') {  /* fractional part */
	  nextch(LINK);
	  if (LINK->ch == '.') {
	    LINK->ch = ':';
	    collectint(&V);
	  } else {
	    LINK->sy = realcon;
	    rnum = 0.0;
	    e = 0;
	    collectreal(&V);
	    if (isdigit(LINK->ch)) {
	      while (isdigit(LINK->ch)) {
		if (rnum <= realmax / 10.0) {
		  e--;
		  rnum = 10.0 * rnum;
		  LINK->digit = LINK->ch - '0';
		  if (LINK->digit <= realmax - rnum)
		    rnum += LINK->digit;
		}
		nextch(LINK);
	      }
	    } else
	      LINK->numerror = true;
	    if (LINK->ch == 'E' || LINK->ch == 'e')
	      readscale(&LINK->numerror, &V);
	    if (e != 0)
	      adjustscale(&LINK->numerror, &V);
	  }
	}  /* fractional part */
	else {
	  if (LINK->ch == 'E' || LINK->ch == 'e') {
	    LINK->sy = realcon;
	    rnum = LINK->inum;
	    e = 0;
	    collectreal(&V);
	    readscale(&LINK->numerror, &V);
	    if (e != 0)
	      adjustscale(&LINK->numerror, &V);
	  }
	}
      }
      if (LINK->numerror)
	error(ernum, LINK);
      break;
      /* number */

    case ':':
      nextch(LINK);
      if (LINK->ch == '=') {
	LINK->sy = becomes;
	nextch(LINK);
      } else
	LINK->sy = colon;
      break;

    case '<':
      nextch(LINK);
      if (LINK->ch == '=') {
	LINK->sy = leq;
	nextch(LINK);
      } else {
	if (LINK->ch == '>') {
	  LINK->sy = neq;
	  nextch(LINK);
	} else
	  LINK->sy = lss;
      }
      break;

    case '>':
      nextch(LINK);
      if (LINK->ch == '=') {
	LINK->sy = geq;
	nextch(LINK);
      } else
	LINK->sy = gtr;
      break;

    case '.':
      nextch(LINK);
      if (LINK->ch == '.') {
	LINK->sy = colon;
	nextch(LINK);
      } else
	LINK->sy = period;
      break;

    case '\'':
      V.k = 0;
_L2:
      nextch(LINK);
      if (LINK->ch == '\'') {
	nextch(LINK);
	if (LINK->ch != '\'')
	  goto _L3;
      }
      if (sx + V.k == smax)
	fatal(3L, LINK);
      stab[sx + V.k] = LINK->ch;
      V.k++;
      if (LINK->cc != 1)
	goto _L2;
      /*end of line*/
      V.k = 0;
_L3:
      if (V.k == 1) {
	LINK->sy = charcon;
	LINK->inum = stab[sx];
      } else {
	if (V.k == 0) {
	  error(erstring, LINK);
	  LINK->sy = charcon;
	  LINK->inum = 0;
	} else {
	  LINK->sy = string;
	  LINK->inum = sx;
	  LINK->sleng = V.k;
	  sx += V.k;
	}
      }
      break;


    case '(':
    case '{':
      if (LINK->ch == '(')
	nextch(LINK);
      if (LINK->ch == '{' || LINK->ch == '*') {
	/*comment*/
	nextch(LINK);
	do {
	  while (LINK->ch != '}' && LINK->ch != '*')
	    nextch(LINK);
	  if (LINK->ch == '*')
	    nextch(LINK);
	} while (LINK->ch != '}' && LINK->ch != ')');
	nextch(LINK);
	goto _L1;
      }
      LINK->sy = lparent;
      break;

    case '}':
      LINK->sy = rbrace;
      nextch(LINK);
      break;

    case '=':
      nextch(LINK);
      if (LINK->ch == '>') {
	LINK->sy = arrow;
	nextch(LINK);
      } else
	LINK->sy = eql;
      break;

    case '+':
    case '-':
    case '*':
    case '/':
    case ')':
    case ',':
    case '[':
    case ']':
    case ';':
    case '?':
    case '!':
    case '%':
      LINK->sy = LINK->sps[LINK->ch];
      nextch(LINK);
      break;

    }/* case */
    return;
  } else {  /* not legal character */
    error(erchar, LINK);
    nextch(LINK);
    goto _L1;
  }
}  /* insymbol */

#undef maxdigits



/*-----------------------------------------------------------------------enter---*/

Local Void enter(x0, x1, x2, x3, LINK)
Char *x0;
object x1;
types x2;
long x3;
struct LOC_pfcfront *LINK;
{
  tabrec *WITH;

  t++;   /*enter standard identifiers*/
  WITH = &tab[t];
  memcpy(WITH->name, x0, sizeof(alfa_));
  WITH->link = t - 1;
  WITH->obj = (unsigned)x1;
  WITH->typ = (unsigned)x2;
  WITH->ref = 0;
  WITH->normal = true;
  WITH->lev = 0;
  WITH->taddr = x3;
  WITH->auxref = 0;
}  /* enter */

Local Void enterarray(tp, l, h, LINK)
types tp;
long l, h;
struct LOC_pfcfront *LINK;
{
  atabrec *WITH;

  if (l > h)
    error(ersub, LINK);
  if (labs(l) > xmax || labs(h) > xmax) {
    error(ersub, LINK);
    l = 0;
    h = 0;
  }
  if (a == amax) {
    fatal(4L, LINK);
    return;
  }
  a++;
  WITH = &atab[a - 1];
  WITH->inxtyp = (unsigned)tp;
  WITH->low = l;
  WITH->high = h;
}  /* enterarray */

Local Void enterblock(LINK)
struct LOC_pfcfront *LINK;
{
  btabrec *WITH;

  if (b == bmax) {
    fatal(2L, LINK);
    return;
  }
  b++;
  WITH = &btab[b - 1];
  WITH->last = 0;
  WITH->lastpar = 0;
  WITH->tabptr = t;
}  /* enterblock */


Local Void enterreal(x, LINK)
double x;
struct LOC_pfcfront *LINK;
{
  if (r == rmax - 1) {
    fatal(10L, LINK);
    return;
  }
  rconst[r] = x;
  realindex = 1;
  while (rconst[realindex - 1] != x)
    realindex = 1;
  if (realindex > r)
    r = realindex;
}  /* enterreal */



Local Void emit0typed(fop, tp, LINK)
opcode fop;
types tp;
struct LOC_pfcfront *LINK;
{
  order *WITH;

  if (lc == cmax)
    fatal(6L, LINK);
  WITH = &code[lc];
  WITH->f = (unsigned)fop;
  WITH->instyp = (unsigned)tp;
  WITH->line = LINK->lineold;
  lc++;
}  /* emit0typed */


Local Void emit0(fop, LINK)
opcode fop;
struct LOC_pfcfront *LINK;
{
  emit0typed(fop, notyp, LINK);
}  /* emit0 */


Local Void emit1typed(fop, b, tp, LINK)
opcode fop;
long b;
types tp;
struct LOC_pfcfront *LINK;
{
  order *WITH;

  if (lc == cmax)
    fatal(6L, LINK);
  WITH = &code[lc];
  WITH->f = (unsigned)fop;
  WITH->y = b;
  WITH->instyp = (unsigned)tp;
  WITH->line = LINK->lineold;
  lc++;
}  /* emit1typed */



Local Void emit1(fop, b, LINK)
opcode fop;
long b;
struct LOC_pfcfront *LINK;
{
  emit1typed(fop, b, notyp, LINK);
}  /* emit1 */


Local Void emit2typed(fop, a, b, tp, LINK)
opcode fop;
long a, b;
types tp;
struct LOC_pfcfront *LINK;
{
  order *WITH;

  if (lc == cmax)
    fatal(6L, LINK);
  WITH = &code[lc];
  WITH->f = (unsigned)fop;
  WITH->x = a;
  WITH->y = b;
  WITH->instyp = (unsigned)tp;
  WITH->line = LINK->lineold;
  lc++;
}  /* emit2 */



Local Void emit2(fop, a, b, LINK)
opcode fop;
long a, b;
struct LOC_pfcfront *LINK;
{
  emit2typed(fop, a, b, notyp, LINK);
}  /* emit2 */


Local Void initmons(LINK)
struct LOC_pfcfront *LINK;
{

  /* initialise monitor procedure table */
  char i;
  _REC_capsproctab *WITH;

  LINK->ncapsprocs = 0;
  LINK->curcaps = 0;
  LINK->inguardedproc = false;
  for (i = 0; i < maxcapsprocs; i++) {
    WITH = &LINK->capsproctab[i];
    memcpy(WITH->name, "          ", sizeof(alfa_));
    WITH->foundec = false;
  }
}  /* initmons */

/* Local variables for block: */
struct LOC_block {
  struct LOC_pfcfront *LINK;
  symset fsys;
  long level, dx, entoffset, codelevel;
} ;

Local Void typ PP((long *fsys, types *tp, long *rf, long *sz,
		   struct LOC_block *LINK));
Local Void expression PP((long *fsys, item *x, struct LOC_block *LINK));
Local Void statement PP((long *fsys, struct LOC_block *LINK));
Local Void capsuledeclaration PP((types form, struct LOC_block *LINK));

Local Void skip(fsys, n, LINK)
long *fsys;
er n;
struct LOC_block *LINK;
{
  error(n, LINK->LINK);
  LINK->LINK->skipflag = true;
  while (!P_inset(LINK->LINK->sy, fsys))
    insymbol(LINK->LINK);
  if (LINK->LINK->skipflag)
    endskip(LINK->LINK);
}  /* skip */

Local Void test(s1, s2, n, LINK)
long *s1, *s2;
er n;
struct LOC_block *LINK;
{
  symset SET;

  if (!P_inset(LINK->LINK->sy, s1))
    skip(P_setunion(SET, s1, s2), n, LINK);
}  /* test */

Local Void testsemicolon(LINK)
struct LOC_block *LINK;
{
  long SET[(long)ident / 32 + 2];
  symset SET1;

  if (LINK->LINK->sy == semicolon)
    insymbol(LINK->LINK);
  else
    error(ersemi, LINK->LINK);
  test(P_setunion(SET1, P_addset(P_expset(SET, 0L), (int)ident),
		  LINK->LINK->blockbegsys), LINK->fsys, ersemi, LINK);
}  /* testsemicolon */



Local long searchblock(k, id, LINK)
long k;
Char *id;
struct LOC_block *LINK;
{

  /* search a single static level for an identifier */
  /* search symbol table backwards from k */
  memcpy(tab[0].name, id, sizeof(alfa_));
  while (strncmp(tab[k].name, id, sizeof(alfa_)))
    k = tab[k].link;
  return k;
}  /* searchblock */




Local Void enter_(id, k, LINK)
Char *id;
object k;
struct LOC_block *LINK;
{

  /* enter new identifier into symbol table */
  long j, l;
  tabrec *WITH;

  if (t == tmax) {
    fatal(1L, LINK->LINK);
    return;
  }
  l = btab[display[LINK->level] - 1].last;
  if (!strncmp(id, "          ", sizeof(alfa_)))
    j = 0;
  else
    j = searchblock(l, id, LINK);
  if (j != 0) {
    error(erdup, LINK->LINK);
    return;
  }
  t++;
  WITH = &tab[t];
  memcpy(WITH->name, id, sizeof(alfa_));
  WITH->link = l;
  WITH->obj = (unsigned)k;
  WITH->typ = (unsigned)notyp;
  WITH->ref = 0;
  WITH->lev = LINK->level;
  WITH->taddr = 0;
  WITH->auxref = 0;
  btab[display[LINK->level] - 1].last = t;

  /* j=0 */
}  /* enter */




Local long find(id, LINK)
Char *id;
struct LOC_block *LINK;
{

  /* find id in table or return 0 if not present */
  long i, j;

  i = LINK->level;
  do {
    j = searchblock(btab[display[i] - 1].last, id, LINK);
    i--;
  } while (i >= 0 && j == 0);
  return j;
}  /* find */



Local long loc(id, LINK)
Char *id;
struct LOC_block *LINK;
{

  /* find with an error message */
  long j;

  j = find(id, LINK);
  if (j == 0)
    error(erdec, LINK->LINK);
  return j;
}  /* loc */



Local Void constant(fsys, c, LINK)
long *fsys;
conrec *c;
struct LOC_block *LINK;
{
  long x, sign;
  boolean hasasign;
  symset SET;

  c->tp = notyp;
  c->UU.i = 0;
  hasasign = false;
  test(LINK->LINK->constbegsys, fsys, ersym, LINK);
  if (!P_inset(LINK->LINK->sy, LINK->LINK->constbegsys))
    return;
  if (LINK->LINK->sy == charcon) {
    c->tp = chars;
    c->UU.i = LINK->LINK->inum;
    insymbol(LINK->LINK);
  } else {
    sign = 1;
    if ((unsigned long)LINK->LINK->sy < 32 &&
	((1L << ((long)LINK->LINK->sy)) &
	 ((1L << ((long)plus)) | (1L << ((long)minus)))) != 0) {
      hasasign = true;
      if (LINK->LINK->sy == minus)
	sign = -1;
      insymbol(LINK->LINK);
    }
    if (LINK->LINK->sy == ident) {
      x = loc(LINK->LINK->id, LINK);
      if (x != 0) {
	if ((object)tab[x].obj != konstant)
	  error(erconst, LINK->LINK);
	else {
	  c->tp = (types)tab[x].typ;
	  if (hasasign &&
	      ((1L << ((long)c->tp)) &
	       ((1L << ((long)ints)) | (1L << ((long)reals)))) == 0)
	    error(ertyp, LINK->LINK);
	  switch (c->tp) {

	  case ints:
	    c->UU.i = sign * tab[x].taddr;
	    break;

	  case notyp:
	  case chars:
	  case bools:
	    c->UU.i = tab[x].taddr;
	    break;

	  case enums:
	    c->UU.U15.ordval = tab[x].taddr;
	    c->UU.U15.ref = tab[x].auxref;
	    break;

	  case reals:
	    c->UU.r = sign * rconst[tab[x].taddr - 1];
	    break;
	  }/* case c.tp of */
	}
      } else {  /* x = 0 */
	c->tp = notyp;
	c->UU.i = 0;
      }
      insymbol(LINK->LINK);
    }  /* sy was ident */
    else {
      if (LINK->LINK->sy == intcon) {
	c->tp = ints;
	c->UU.i = sign * LINK->LINK->inum;
	insymbol(LINK->LINK);
      } else {
	if (LINK->LINK->sy == realcon) {
	  c->tp = reals;
	  c->UU.r = sign * rnum;
	  insymbol(LINK->LINK);
	} else
	  skip(fsys, ersym, LINK);
      }
    }
  }
  test(fsys, P_expset(SET, 0L), ersym, LINK);
}  /* constant */


Local Void entervariable(LINK)
struct LOC_block *LINK;
{
  if (LINK->LINK->sy == ident) {
    enter_(LINK->LINK->id, variable, LINK);
    insymbol(LINK->LINK);
  } else
    error(erident, LINK->LINK);
}  /* entervariable */



Local Void align(dx, LINK)
long *dx;
struct LOC_block *LINK;
{

  /* align object to boundary required by target machine */
  long rem;

  rem = 0;
  if (rem > 0)
    *dx += objalign - rem;
}  /* align */



Local Void alloc(sz, dx, taddr, LINK)
long sz, *dx, *taddr;
struct LOC_block *LINK;
{

  /* allocate space for variable */
  if (pushdown) {
    *dx += sz;
    align(dx, LINK);
    *taddr = *dx;
    return;
  }
  align(dx, LINK);
  *taddr = *dx;
  *dx += sz;
}  /* alloc */




Local Void enterint(i, sz, dx, taddr, LINK)
long i, sz, *dx, *taddr;
struct LOC_block *LINK;
{

  /* enter mapped ipc type into interrupt map table */
  intabrec *WITH;
  tabrec *WITH1;

  if (int_ == intermax)
    fatal(11L, LINK->LINK);
  int_++;
  WITH = &intab[int_ - 1];   /* with */
  WITH->tabref = i;
  WITH1 = &tab[i];
  WITH->tp = (unsigned)((types)WITH1->typ);
  WITH->rf = WITH1->ref;
  WITH->lv = WITH1->lev;
  WITH->vector = WITH1->taddr;
  WITH->off = *dx;
  alloc(sz, dx, &WITH1->taddr, LINK);
  if (pushdown)
    WITH->off = *dx;
}  /* enterint */


Local boolean contains(targetset, tp, rf, LINK)
typset targetset;
types tp;
index_ rf;
struct LOC_block *LINK;
{

  /* returns true if any component of object is in target set */
  boolean found;
  long j;

  if (((1L << ((long)tp)) & targetset) != 0)
    return true;
  else {
    if (rf == 0)
      return false;
    else {
      if (tp == arrays)
	return (contains(targetset, (types)atab[rf - 1].eltyp,
			 atab[rf - 1].elref, LINK));
      else {
	if (tp == records) {
	  j = btab[rf - 1].last;
	  found = false;
	  while (!found && j != 0) {
	    found = contains(targetset, (types)tab[j].typ, tab[j].ref, LINK);
	    j = tab[j].link;
	  }  /* while */
	  return found;
	}  /* record */
	else
	  return false;
      }
    }
  }
}  /* contains */


Local Void getmapping(possibles, LINK)
long *possibles;
struct LOC_block *LINK;
{

  /* get mapping information if any */
  conrec ad;
  symset SET, SET1;

  if (LINK->LINK->sy != atsy) {
    return;
  }  /* sy was atsy */
  insymbol(LINK->LINK);
  if (!P_inset(LINK->LINK->sy, possibles)) {
    error(ersym, LINK->LINK);
    return;
  }
  if (!P_inset(LINK->LINK->sy, LINK->LINK->constbegsys))
    insymbol(LINK->LINK);
  tab[t].obj = (unsigned)address;
  constant(P_setunion(SET1, LINK->fsys,
	     P_expset(SET, (1L << ((long)comma)) | (1L << ((long)colon)))),
	   &ad, LINK);
  if (ad.tp == ints)
    tab[t].taddr = ad.UU.i;
  else {
    error(ertyp, LINK->LINK);
    tab[t].taddr = 0;
  }
}  /* getmapping */





Local Void internalname(internalnum, namestring, LINK)
long *internalnum;
Char *namestring;
struct LOC_block *LINK;
{
  long temp, index;

  memcpy(namestring, "$         ", sizeof(alfa_));
  (*internalnum)++;
  temp = *internalnum;
  index = 2;
  while (temp != 0) {
    namestring[index - 1] = (Char)(temp % 10 + '0');
/* p2c: pfccomp.pas, line 1762:
 * Note: Using % for possibly-negative arguments [317] */
    temp /= 10;
    if (index < 10)
      index++;
  }
}  /* internalname */

/* Local variables for typ: */
struct LOC_typ {
  struct LOC_block *LINK;
  symset fsys;
} ;

Local Void arraytyp(aref, arsz, LINK)
long *aref, *arsz;
struct LOC_typ *LINK;
{
  types eltp;
  conrec low, high;
  long irf, elrf, elsz;
  long SET[(long)ofsy / 32 + 2];
  symset SET1, SET2, SET3;
  atabrec *WITH;

  P_addset(P_expset(SET, 0L), (int)colon);
  P_addset(SET, (int)rbrack);
  constant(P_setunion(SET1, P_addset(SET, (int)ofsy), LINK->fsys), &low,
	   LINK->LINK);
  if (low.tp == reals)
    error(ertyp, LINK->LINK->LINK);
  if (LINK->LINK->LINK->sy == colon)
    insymbol(LINK->LINK->LINK);
  else
    skip(P_setunion(SET3,
	   P_setunion(SET1, LINK->fsys, LINK->LINK->LINK->constbegsys),
	   P_expset(SET2, (1L << ((long)rbrack)) | (1L << ((long)colon)))),
	 erperiod, LINK->LINK);
  P_addset(P_expset(SET, 0L), (int)rbrack);
  P_addset(SET, (int)comma);
  constant(P_setunion(SET1, P_addset(SET, (int)ofsy), LINK->fsys), &high,
	   LINK->LINK);
  if (high.tp != low.tp) {
    error(ertyp, LINK->LINK->LINK);
    high.UU.i = low.UU.i;
  } else {
    if (low.tp == enums) {
      if (low.UU.U15.ref != high.UU.U15.ref) {
	error(ertyp, LINK->LINK->LINK);
	irf = 0;
      } else
	irf = low.UU.U15.ref;
    } else
      irf = 0;
  }
  if (low.tp == reals)
    enterarray(notyp, 0L, 0L, LINK->LINK->LINK);
  else
    enterarray(low.tp, low.UU.i, high.UU.i, LINK->LINK->LINK);
  *aref = a;
  if (LINK->LINK->LINK->sy == comma) {
    insymbol(LINK->LINK->LINK);
    eltp = arrays;
    arraytyp(&elrf, &elsz, LINK);
  } else {
    if (LINK->LINK->LINK->sy == rbrack)
      insymbol(LINK->LINK->LINK);
    else
      error(errbrack, LINK->LINK->LINK);
    if (LINK->LINK->LINK->sy == ofsy)
      insymbol(LINK->LINK->LINK);
    else
      error(erof, LINK->LINK->LINK);
    typ(LINK->fsys, &eltp, &elrf, &elsz, LINK->LINK);
  }
  WITH = &atab[*aref - 1];
  *arsz = (WITH->high - WITH->low + 1) * elsz;
  WITH->size = *arsz;
  WITH->eltyp = (unsigned)eltp;
  WITH->elref = elrf;
  WITH->elsize = elsz;
  WITH->inxref = irf;
}  /* arraytyp */


Local Void enumtyp(LINK)
struct LOC_typ *LINK;
{

  /* parse enumeration type declaration */
  long ordval;
  tabrec *WITH;
  _REC_bounds *WITH1;

  if (LINK->LINK->LINK->et == etmax)
    fatal(12L, LINK->LINK->LINK);
  LINK->LINK->LINK->et++;
  ordval = 0;
  insymbol(LINK->LINK->LINK);
  while (LINK->LINK->LINK->sy == ident) {
    enter_(LINK->LINK->LINK->id, konstant, LINK->LINK);
    WITH = &tab[t];   /* with */
    WITH->typ = (unsigned)enums;
    WITH->ref = 0;
    WITH->auxref = LINK->LINK->LINK->et;
    WITH->taddr = ordval;
    ordval++;
    insymbol(LINK->LINK->LINK);
    if (LINK->LINK->LINK->sy == comma)
      insymbol(LINK->LINK->LINK);
  }  /* while */
  WITH1 = &LINK->LINK->LINK->bounds[LINK->LINK->LINK->et - 1];
  WITH1->lower = 0;
  WITH1->upper = ordval - 1;
  if (LINK->LINK->LINK->sy == rparent)
    insymbol(LINK->LINK->LINK);
  else
    error(errparent, LINK->LINK->LINK);
}  /* enumtyp */





Local Void typ(fsys_, tp, rf, sz, LINK)
long *fsys_;
types *tp;
long *rf, *sz;
struct LOC_block *LINK;
{
  struct LOC_typ V;
  types eltp;
  long elrf, x, elsz, offset, t0, t1;
  tabrec *WITH;
  long SET[(long)ident / 32 + 2];
  symset SET1;
  long SET2[(long)endsy / 32 + 2];
  symset SET3;
  long SET4[(long)offsetsy / 32 + 2];
  long SET5[(long)endsy / 32 + 2];
  symset SET6;
  _REC_chantab *WITH1;


  V.LINK = LINK;
  P_setcpy(V.fsys, fsys_);
  *tp = notyp;
  *rf = 0;
  *sz = 0;
  test(LINK->LINK->typebegsys, V.fsys, ersym, LINK);
  if (!P_inset(LINK->LINK->sy, LINK->LINK->typebegsys)) {
    return;
  }  /* sy was in typebegsys */
  switch (LINK->LINK->sy) {

  case ident:
    x = loc(LINK->LINK->id, LINK);
    if (x != 0) {
      WITH = &tab[x];
      if ((object)WITH->obj != type1)
	error(ertyp, LINK->LINK);
      else {
	*tp = (types)WITH->typ;
	if (*tp == enums)
	  *rf = WITH->auxref;
	else
	  *rf = WITH->ref;
	if (*tp == procs)
	  *sz = procsize;
	else
	  *sz = WITH->taddr;
	if (*tp == notyp)
	  error(ertyp, LINK->LINK);
      }
    }
    insymbol(LINK->LINK);
    break;
    /* sy was ident */

  case arraysy:
    insymbol(LINK->LINK);
    if (LINK->LINK->sy == lbrack)
      insymbol(LINK->LINK);
    else
      error(erlbrack, LINK->LINK);
    *tp = arrays;
    arraytyp(rf, sz, &V);
    break;
    /* sy was arraysy */

  case recordsy:
    insymbol(LINK->LINK);
    enterblock(LINK->LINK);
    *tp = records;
    *rf = b;
    if (LINK->level == lmax)
      fatal(5L, LINK->LINK);
    LINK->level++;
    display[LINK->level] = b;
    offset = 0;
    while (!P_inset(LINK->LINK->sy, P_setunion(SET3, P_setdiff(SET1, V.fsys,
		 (P_addset(P_expset(SET, 0L), (int)semicolon),
		  P_addset(SET, (int)comma), P_addset(SET, (int)ident))),
	       P_addset(P_expset(SET2, 0L), (int)endsy))))
/* p2c: pfccomp.pas, line 5464: 
 * Note: Line breaker spent 0.0 seconds, 5000 tries on line 2272 [251] */
    {  /* field section */
      if (LINK->LINK->sy == ident) {
	t0 = t;
	entervariable(LINK);
	getmapping(P_addset(P_expset(SET4, 0L), (int)offsetsy), LINK);
	while (LINK->LINK->sy == comma) {
	  insymbol(LINK->LINK);
	  entervariable(LINK);
	  getmapping(P_addset(P_expset(SET4, 0L), (int)offsetsy), LINK);
	}
	if (LINK->LINK->sy == colon)
	  insymbol(LINK->LINK);
	else
	  error(ercolon, LINK->LINK);
	t1 = t;
	P_addset(P_expset(SET5, 0L), (int)semicolon);
	P_addset(SET5, (int)endsy);
	P_addset(SET5, (int)comma);
	typ(P_setunion(SET6, V.fsys, P_addset(SET5, (int)ident)), &eltp,
	    &elrf, &elsz, LINK);
	if (contains(1L << ((long)procs), eltp, elrf, LINK))
	  error(erprocinrec, LINK->LINK);
	while (t0 < t1) {
	  t0++;
	  WITH = &tab[t0];
	  WITH->typ = (unsigned)eltp;
	  WITH->ref = elrf;
	  WITH->normal = true;
	  if ((object)WITH->obj == variable) {
	    align(&offset, LINK);
	    WITH->taddr = offset;
	    offset += elsz;
	  } else
	    offset = WITH->taddr + elsz;
	  WITH->obj = (unsigned)variable;
	}
      }  /* sy=ident */
      if (LINK->LINK->sy == endsy)
	continue;
      if (LINK->LINK->sy == semicolon)
	insymbol(LINK->LINK);
      else {
	error(ersemi, LINK->LINK);
	if (LINK->LINK->sy == comma)
	  insymbol(LINK->LINK);
      }
      P_addset(P_expset(SET5, 0L), (int)ident);
      P_addset(SET5, (int)endsy);
      test(P_addset(SET5, (int)semicolon), V.fsys, ersym, LINK);
    }  /* field section */
    align(&offset, LINK);
    btab[*rf - 1].vsize = offset;
    *sz = offset;
    btab[*rf - 1].psize = 0;
    insymbol(LINK->LINK);
    LINK->level--;
    break;
    /* records */

  case channelsy:  /* channel */
    insymbol(LINK->LINK);
    if (LINK->LINK->chan == chanmax)
      fatal(7L, LINK->LINK);
    else {
      LINK->LINK->chan++;
      *tp = channels;
      *rf = LINK->LINK->chan;
      *sz = chansize;
      if (LINK->LINK->sy == ofsy)
	insymbol(LINK->LINK);
      else
	error(erof, LINK->LINK);
      typ(P_setunion(SET3, V.fsys, P_expset(SET1, 1L << ((long)semicolon))),
	  &eltp, &elrf, &elsz, LINK);
      WITH1 = &LINK->LINK->chantab[LINK->LINK->chan - 1];
      WITH1->eltyp = (unsigned)eltp;
      WITH1->elref = elrf;
      WITH1->elsize = elsz;   /* with */
    }
    break;
    /* channel */

  case lparent:
    enumtyp(&V);
    *tp = enums;
    *rf = LINK->LINK->et;
    *sz = intsize;
    break;
    /* enum type */
  }/* case sy of */
  test(V.fsys, P_expset(SET1, 0L), ersym, LINK);
}  /* typ */





Local Void parameterlist(isentry, dx, LINK)
boolean isentry;
long *dx;
struct LOC_block *LINK;
{

  /* formal parameter list */
  types tp;
  long rf, sz, x, t0;
  boolean valpar;
  long SET[(long)ident / 32 + 2];
  symset SET1, SET2;
  tabrec *WITH;
  long SET3[(long)ident / 32 + 2];
  symset SET4;
  long SET5[(long)providessy / 32 + 2];

  LINK->entoffset = entrysize;
  insymbol(LINK->LINK);
  tp = notyp;
  rf = 0;
  sz = 0;
  P_addset(P_expset(SET, 0L), (int)ident);
  test(P_addset(SET, (int)varsy),
       P_setunion(SET2, LINK->fsys, P_expset(SET1, 1L << ((long)rparent))),
       erpar, LINK);
  while (LINK->LINK->sy == (int)varsy || LINK->LINK->sy == (int)ident)
  {   /* while sy in [ident,varsy] */
    if (LINK->LINK->sy != varsy)
      valpar = true;
    else {
      insymbol(LINK->LINK);
      valpar = false;
    }
    t0 = t;
    entervariable(LINK);
    while (LINK->LINK->sy == comma) {
      insymbol(LINK->LINK);
      entervariable(LINK);
    }
    if (LINK->LINK->sy == colon) {
      insymbol(LINK->LINK);
      if (LINK->LINK->sy != ident)
	error(erident, LINK->LINK);
      else {
	x = loc(LINK->LINK->id, LINK);
	insymbol(LINK->LINK);
	if (x != 0) {
	  WITH = &tab[x];
	  if ((object)WITH->obj != type1)
	    error(ertyp, LINK->LINK);
	  else {
	    tp = (types)WITH->typ;
	    if (tp == enums)
	      rf = WITH->auxref;
	    else
	      rf = WITH->ref;
	    if (valpar) {
	      if (contains((1L << ((long)semafors)) |
			   (1L << ((long)channels)) | (1L << ((long)condvars)),
			   (types)WITH->typ, WITH->ref, LINK))
		error(ervarpar, LINK->LINK);
	      sz = WITH->taddr;
	    } else
	      sz = intsize;
	  }
	}
      }
      P_addset(P_expset(SET, 0L), (int)comma);
      test(P_expset(SET1, (1L << ((long)semicolon)) | (1L << ((long)rparent))),
	   P_setunion(SET2, P_addset(SET, (int)ident), LINK->fsys), ersym,
	   LINK);
    }  /* sy was colon */
    else
      error(ercolon, LINK->LINK);
    while (t0 < t) {
      t0++;
      WITH = &tab[t0];
      WITH->typ = (unsigned)tp;
      if (tp == enums) {
	WITH->auxref = rf;
	WITH->ref = 0;
      } else {
	WITH->auxref = 0;
	WITH->ref = rf;
      }
      WITH->normal = valpar;
      if (isentry)
	WITH->lev = LINK->level - 1;
      alloc(sz, dx, &WITH->taddr, LINK);
    }
    if (LINK->LINK->sy == rparent)
      break;
    if (LINK->LINK->sy == semicolon)
      insymbol(LINK->LINK);
    else
      error(ersemi, LINK->LINK);
    P_addset(P_expset(SET3, 0L), (int)ident);
    test(P_addset(SET3, (int)varsy),
	 P_setunion(SET4, P_expset(SET2, 1L << ((long)rparent)), LINK->fsys),
	 ersym, LINK);
  }
  if (LINK->LINK->sy == rparent) {
    insymbol(LINK->LINK);
    P_addset(P_expset(SET5, 0L), (int)semicolon);
    P_addset(SET5, (int)colon);
    P_addset(SET5, (int)providessy);
    test(P_addset(SET5, (int)whensy), LINK->fsys, ersym, LINK);
  } else
    error(errparent, LINK->LINK);
}  /* parameterlist */

/* Local variables for parametercheck: */
struct LOC_parametercheck {
  struct LOC_block *LINK;
  boolean perror;
  long cp;
} ;


Local Void checkident(LINK)
struct LOC_parametercheck *LINK;
{
  LINK->cp++;
  if (strncmp(LINK->LINK->LINK->id, tab[LINK->cp].name, sizeof(alfa_)))
    LINK->perror = true;
  insymbol(LINK->LINK->LINK);
}  /* checkident */


Local Void parametercheck(i, LINK)
long i;
struct LOC_block *LINK;
{

  /* check consistency of formal entry parameter declarations */
  /* used by accept and when "provides" has been used */
  struct LOC_parametercheck V;
  boolean valpar;
  long lastp, k, t0, rf;
  types tp;
  long SET[(long)dosy / 32 + 2];
  tabrec *WITH;
  symset SET1;



  V.LINK = LINK;
  lastp = btab[tab[i].ref - 1].lastpar;
  V.cp = i;
  if (LINK->LINK->sy == lparent) {
    V.perror = false;
    insymbol(LINK->LINK);
    while (LINK->LINK->sy == (int)varsy || LINK->LINK->sy == (int)ident) {
      if (LINK->LINK->sy == varsy) {
	valpar = false;
	insymbol(LINK->LINK);
      } else
	valpar = true;
      t0 = V.cp;
      checkident(&V);
      while (LINK->LINK->sy == comma) {
	insymbol(LINK->LINK);
	checkident(&V);
      }
      if (LINK->LINK->sy == colon)
	insymbol(LINK->LINK);
      else
	error(ercolon, LINK->LINK);
      if (LINK->LINK->sy == ident) {
	k = find(LINK->LINK->id, LINK);
	if ((object)tab[k].obj != type1)
	  error(ersym, LINK->LINK);
	tp = (types)tab[k].typ;
	if (tp == enums)
	  rf = tab[k].auxref;
	else
	  rf = tab[k].ref;
	insymbol(LINK->LINK);
      } else
	error(erident, LINK->LINK);
      while (t0 < V.cp) {
	t0++;
	WITH = &tab[t0];
	if (valpar != WITH->normal || tp != (types)WITH->typ) {
	  V.perror = true;
	  continue;
	}
	if ((types)WITH->typ == enums) {
	  if (rf != WITH->auxref)
	    V.perror = true;
	} else {
	  if (rf != WITH->ref)
	    V.perror = true;
	}
      }
      if (LINK->LINK->sy == semicolon)
	insymbol(LINK->LINK);
    }  /* while sy in [ident, varsy] */
    if (V.perror)
      error(erparmatch, LINK->LINK);
    if (LINK->LINK->sy == rparent)
      insymbol(LINK->LINK);
    else {
      P_addset(P_expset(SET, 0L), (int)semicolon);
      skip(P_setunion(SET1, LINK->fsys, P_addset(SET, (int)dosy)), erlparent,
	   LINK);
    }
  }
  if (V.cp != lastp)
    error(erpar, LINK->LINK);
}  /* parametercheck */


Local Void entrycheck(i, LINK)
long i;
struct LOC_block *LINK;
{

  /* check consistency of entry declarations */
  /* used when "provides" was used */
  long k, prb;
  boolean missing;
  conrec ad;
  long SET[(long)entrysy / 32 + 2];
  symset SET1;
  long SET2[(long)endsy / 32 + 2];

  prb = tab[i].ref;
  k = btab[prb - 1].last;
  while (k != 0) {
    if ((types)tab[k].typ == entrys)
      tab[k].auxref = 1;
    k = tab[k].link;
  }
  while (LINK->LINK->sy == entrysy) {
    insymbol(LINK->LINK);
    if (LINK->LINK->sy != ident) {
      P_addset(P_expset(SET, 0L), (int)semicolon);
      skip(P_setunion(SET1, P_addset(SET, (int)entrysy), LINK->fsys), erident,
	   LINK);
    } else {  /* sy is ident */
      k = searchblock(btab[prb - 1].last, LINK->LINK->id, LINK);
      insymbol(LINK->LINK);
      if (k == 0 || (types)tab[k].typ != entrys) {
	P_addset(P_expset(SET, 0L), (int)semicolon);
	skip(P_setunion(SET1, P_addset(SET, (int)entrysy), LINK->fsys),
	     erentext, LINK);
      } else {  /* typ = entrys */
	tab[k].auxref = 0;
	parametercheck(k, LINK);
	if (LINK->LINK->sy == atsy) {
	  insymbol(LINK->LINK);
	  P_addset(P_expset(SET2, 0L), (int)semicolon);
	  constant(P_setunion(SET1, LINK->fsys, P_addset(SET2, (int)endsy)),
		   &ad, LINK);
	  if ((object)tab[k].obj != address)
	    error(erentmatch, LINK->LINK);
	  else {
	    if (ad.UU.i != tab[k].taddr)
	      error(erentmatch, LINK->LINK);
	  }
	} else {
	  if ((object)tab[k].obj == address)
	    error(erentmatch, LINK->LINK);
	}
      }  /* typ = entrys */
    }  /* sy is ident */
    if (LINK->LINK->sy == semicolon)
      insymbol(LINK->LINK);
    else
      error(ersemi, LINK->LINK);
  }  /* while sy = entrysy */
  missing = false;
  k = btab[prb - 1].last;
  while (k != 0 && !missing) {
    if ((types)tab[k].typ == entrys && tab[k].auxref != 0)
      missing = true;
    k = tab[k].link;
  }
  if (missing)
    error(erentmiss, LINK->LINK);
}  /* entrycheck */





Local Void constantdeclaration(LINK)
struct LOC_block *LINK;
{
  conrec c;
  long SET[(long)ident / 32 + 2];
  symset SET1;

  insymbol(LINK->LINK);
  test(P_addset(P_expset(SET, 0L), (int)ident), LINK->LINK->blockbegsys,
       erident, LINK);
  while (LINK->LINK->sy == ident) {
    enter_(LINK->LINK->id, konstant, LINK);
    insymbol(LINK->LINK);
    if (LINK->LINK->sy == eql)
      insymbol(LINK->LINK);
    else
      error(ereql, LINK->LINK);
    P_addset(P_expset(SET, 0L), (int)semicolon);
    P_addset(SET, (int)comma);
    constant(P_setunion(SET1, P_addset(SET, (int)ident), LINK->fsys), &c,
	     LINK);
    tab[t].typ = (unsigned)c.tp;
    tab[t].ref = 0;
    if (c.tp == enums) {
      tab[t].auxref = c.UU.U15.ref;
      tab[t].taddr = c.UU.U15.ordval;
    } else {
      if (c.tp == reals) {
	enterreal(c.UU.r, LINK->LINK);
	tab[t].taddr = realindex;
      } else
	tab[t].taddr = c.UU.i;
    }
    testsemicolon(LINK);
  }
}  /* constantdeclaration */

Local Void testlevel(tp, rf, LINK)
types tp;
index_ rf;
struct LOC_block *LINK;
{

  /* test for level error in type */
  if (contains((1L << ((long)semafors)) | (1L << ((long)channels)) |
	       (1L << ((long)procs)), tp, rf, LINK) && LINK->level != 1) {
    error(erlev, LINK->LINK);
    return;
  }
  if (!contains(1L << ((long)condvars), tp, rf, LINK))
    return;
  if (LINK->LINK->curcaps == 0)
  {  /* type declarations can be in main program */
    if (LINK->level != 1)
      error(erlev, LINK->LINK);
  } else {
    if (LINK->level != 2 || (types)tab[LINK->LINK->curcaps].typ != monvars)
      error(erlev, LINK->LINK);
  }
}  /* testleveL */



Local Void typedeclaration(LINK)
struct LOC_block *LINK;
{
  types tp;
  long rf, sz, t1;
  long SET[(long)ident / 32 + 2];
  symset SET1;
  tabrec *WITH;

  insymbol(LINK->LINK);
  test(P_addset(P_expset(SET, 0L), (int)ident), LINK->LINK->blockbegsys,
       erident, LINK);
  while (LINK->LINK->sy == ident) {
    enter_(LINK->LINK->id, type1, LINK);
    t1 = t;
    insymbol(LINK->LINK);
    if (LINK->LINK->sy == eql)
      insymbol(LINK->LINK);
    else
      error(ereql, LINK->LINK);
    P_addset(P_expset(SET, 0L), (int)semicolon);
    P_addset(SET, (int)comma);
    typ(P_setunion(SET1, P_addset(SET, (int)ident), LINK->fsys), &tp, &rf,
	&sz, LINK);
    testlevel(tp, rf, LINK);
    WITH = &tab[t1];
    WITH->typ = (unsigned)tp;
    if (tp == enums) {
      WITH->auxref = rf;
      WITH->ref = 0;
    } else {
      WITH->auxref = 0;
      WITH->ref = rf;
    }
    WITH->taddr = sz;
    if (tp == procs)
      WITH->normal = true;
    testsemicolon(LINK);
  }
}  /* typedeclaration */




Local Void variabledeclaration(dx, LINK)
long *dx;
struct LOC_block *LINK;
{
  long t0, t1, rf, sz;
  types tp;
  long SET[(long)ident / 32 + 2];
  symset SET1;
  long SET2[(long)adrsy / 32 + 2];
  tabrec *WITH;

  insymbol(LINK->LINK);
  test(P_addset(P_expset(SET, 0L), (int)ident),
       P_expset(SET1, (1L << ((long)colon)) | (1L << ((long)semicolon))),
       erident, LINK);
  while (LINK->LINK->sy == ident) {
    t0 = t;
    entervariable(LINK);
    getmapping(P_setunion(SET1, LINK->LINK->constbegsys,
			  P_addset(P_expset(SET2, 0L), (int)adrsy)), LINK);
    while (LINK->LINK->sy == comma) {
      insymbol(LINK->LINK);
      entervariable(LINK);
      getmapping(P_setunion(SET1, LINK->LINK->constbegsys,
			    P_addset(P_expset(SET2, 0L), (int)adrsy)), LINK);
    }
    if (LINK->LINK->sy == colon)
      insymbol(LINK->LINK);
    else
      error(ercolon, LINK->LINK);
    t1 = t;
    P_addset(P_expset(SET, 0L), (int)semicolon);
    P_addset(SET, (int)comma);
    typ(P_setunion(SET1, P_addset(SET, (int)ident), LINK->fsys), &tp, &rf,
	&sz, LINK);
    testlevel(tp, rf, LINK);
    if (contains(1L << ((long)condvars), tp, rf, LINK) &&
	LINK->LINK->curcaps == 0)
      error(erlev, LINK->LINK);
    while (t0 < t1) {
      t0++;
      WITH = &tab[t0];
      WITH->typ = (unsigned)tp;
      if (tp == enums) {
	WITH->auxref = rf;
	WITH->ref = 0;
      } else {
	WITH->auxref = 0;
	WITH->ref = rf;
      }
      WITH->normal = true;
      if ((object)WITH->obj != address) {
	if (LINK->LINK->curcaps != 0 && LINK->level == 2)
	  WITH->lev = 1;
	else
	  WITH->lev = LINK->level;
	alloc(sz, dx, &WITH->taddr, LINK);
      } else {
	if (((1L << WITH->typ) &
	     ((1L << ((long)semafors)) | (1L << ((long)channels)))) != 0)
	  enterint(t0, sz, dx, &WITH->taddr, LINK);
	else {
	  if (contains(ipctyps | (1L << ((long)procs)), tp, rf, LINK))
	    error(ermap, LINK->LINK);
	}
      }
    }
    testsemicolon(LINK);
  }
}  /* variabledeclaration */

Local boolean isexported(LINK)
struct LOC_block *LINK;
{

  /* returns true if procedure is exportable from monitor */
  boolean found;
  char i;

  found = false;
  if (LINK->LINK->curcaps == 0)
    return found;
  i = 0;
  while (i < LINK->LINK->ncapsprocs && !found) {
    i++;
    if (!strncmp(LINK->LINK->capsproctab[i - 1].name, LINK->LINK->id,
		 sizeof(alfa_))) {
      found = true;
      LINK->LINK->capsproctab[i - 1].foundec = true;
    }
  }
  return found;
}  /* isexported */

Local Void procdeclaration(LINK)
struct LOC_block *LINK;
{
  object lobj;
  long i, prt;
  symset SET, SET1;



  if (LINK->LINK->sy == functionsy)
    lobj = funktion;
  else
    lobj = prozedure;
  insymbol(LINK->LINK);
  if (LINK->LINK->sy != ident) {
    error(erident, LINK->LINK);
    memcpy(LINK->LINK->id, "          ", sizeof(alfa_));
    i = 0;
  } else
    i = searchblock(btab[display[LINK->level] - 1].last, LINK->LINK->id, LINK);
  if (i == 0 || tab[i].normal) {  /* no pending forward declaration */
    if (isexported(LINK)) {
      if (LINK->level != 2)
	error(erlev, LINK->LINK);
      enter_(LINK->LINK->id, monproc, LINK);
    } else
      enter_(LINK->LINK->id, lobj, LINK);
    tab[t].normal = true;
    tab[t].typ = (unsigned)notyp;
    prt = t;
  }  /* no pending forward declaration */
  else {  /* pending forward declaration */
    if ((object)tab[i].obj != lobj)
      error(erdup, LINK->LINK);
    prt = i;
  }  /* pending forward declared */
  insymbol(LINK->LINK);
  block(P_setunion(SET1, P_expset(SET, 1L << ((long)semicolon)), LINK->fsys),
	lobj, prt, LINK->level + 1, LINK->LINK);
  if (tab[prt].normal) {
    if (lobj == funktion)
      emit0typed(retfun, (types)tab[prt].typ, LINK->LINK);
    else
      emit0(retproc, LINK->LINK);
  }
  if (LINK->LINK->sy == semicolon)
    insymbol(LINK->LINK);
  else
    error(ersemi, LINK->LINK);
}  /* proceduredeclaration */


Local Void processdeclaration(LINK)
struct LOC_block *LINK;
{
  long i, prt;
  boolean anon, notforward, nestedproc;
  tabrec *WITH;
  symset SET, SET1;

  nestedproc = LINK->LINK->inprocessdec;
  LINK->LINK->inprocessdec = true;
  anon = false;
  notforward = true;
  if (nestedproc)
    error(ernotinproc, LINK->LINK);
  else {
    if (LINK->level != 1)
      error(erlev, LINK->LINK);
  }
  insymbol(LINK->LINK);
  if (LINK->LINK->sy == typesy)
    insymbol(LINK->LINK);
  else
    anon = true;
  if (LINK->LINK->sy != ident) {
    error(erident, LINK->LINK);
    memcpy(LINK->LINK->id, "          ", sizeof(alfa_));
  }
  if (!strncmp(LINK->LINK->id, "          ", sizeof(alfa_)))
    i = 0;
  else
    i = find(LINK->LINK->id, LINK);
  if (i != 0 && tab[i].lev == LINK->level) {
    if ((types)tab[i].typ != procs)
      error(erdup, LINK->LINK);
    else {  /* id seen before */
      notforward = false;
      if ((object)tab[i].obj == type1)
	prt = i;
      else
	prt = btab[tab[i].ref - 1].tabptr;
      if (tab[prt].normal || (object)tab[i].obj == type1 && anon ||
	  (object)tab[i].obj == variable && !anon)
	error(erdup, LINK->LINK);
    }  /* id seen before */
  } else {  /* id not seen before */
    if (anon) {
      enter_(LINK->LINK->id, variable, LINK);
      WITH = &tab[t];
      WITH->typ = (unsigned)procs;
      WITH->ref = b + 1;
      WITH->normal = true;
      WITH->lev = LINK->level;
      alloc((long)intsize, &LINK->dx, &WITH->taddr, LINK);
      /* enter cannot be used - $ not unique */
      if (t == tmax)
	fatal(1L, LINK->LINK);
      t++;
      WITH = &tab[t];
      memcpy(WITH->name, "$         ", sizeof(alfa_));
      WITH->obj = (unsigned)type1;
      WITH->link = btab[display[LINK->level] - 1].last;
      btab[display[LINK->level] - 1].last = t;
    }  /* if anon */
    else
      enter_(LINK->LINK->id, type1, LINK);
    tab[t].normal = true;
    tab[t].lev = LINK->level;
    tab[t].typ = (unsigned)procs;
    prt = t;
  }
  insymbol(LINK->LINK);
  block(P_setunion(SET1, P_expset(SET, 1L << ((long)semicolon)), LINK->fsys),
	prozedure, prt, LINK->level + 1, LINK->LINK);
  if (tab[prt].normal)
    emit2(retproc, 1L, 0L, LINK->LINK);
  if (LINK->LINK->sy == semicolon)
    insymbol(LINK->LINK);
  else
    error(ersemi, LINK->LINK);
  LINK->LINK->inprocessdec = nestedproc;
}  /* processdeclaration */


Local Void selector(fsys, v, LINK)
long *fsys;
item *v;
struct LOC_block *LINK;
{
  item x;
  long a, j;
  symset SET, SET1;

  do {
    if (LINK->LINK->sy == period) {  /* record field or process entry */
      insymbol(LINK->LINK);
      if (LINK->LINK->sy != ident)
	error(erident, LINK->LINK);
      else {
	if (((1L << ((long)v->typ)) &
	     ((1L << ((long)records)) | (1L << ((long)procs)))) == 0)
	  error(ertyp, LINK->LINK);
	else {  /* search for field or entry identifier */
	  j = searchblock(btab[v->ref - 1].last, LINK->LINK->id, LINK);
	  if (j == 0)
	    error(erdec, LINK->LINK);
	  else {
	    if (v->typ == procs) {
	      if ((types)tab[j].typ != entrys)
		error(ertyp, LINK->LINK);
	    }
	  }
	  v->typ = (types)tab[j].typ;
	  v->ref = tab[j].ref;
	  a = tab[j].taddr;
	  if (a != 0) {
	    if ((types)tab[j].typ == entrys)
	      emit1typed(ldcon, a, adrs, LINK->LINK);
	    else
	      emit1(ixrec, a, LINK->LINK);
	  }
	}
	insymbol(LINK->LINK);
      }
    } else {  /* array selector */
      if (LINK->LINK->sy != lbrack)
	error(erlbrack, LINK->LINK);
      do {
	insymbol(LINK->LINK);
	expression(P_setunion(SET1, fsys,
	    P_expset(SET, (1L << ((long)comma)) | (1L << ((long)rbrack)))),
	  &x, LINK);
	if (v->typ != arrays)
	  error(ertyp, LINK->LINK);
	else {
	  a = v->ref;
	  if ((types)atab[a - 1].inxtyp != x.typ)
	    error(ertyp, LINK->LINK);
	  else {
	    if (atab[a - 1].inxref != x.ref)
	      error(ertyp, LINK->LINK);
	    emit1typed(ixary, a, x.typ, LINK->LINK);
	  }
	  v->typ = (types)atab[a - 1].eltyp;
	  v->ref = atab[a - 1].elref;
	}
      } while (LINK->LINK->sy == comma);
      if (LINK->LINK->sy == rbrack)
	insymbol(LINK->LINK);
      else
	error(errbrack, LINK->LINK);
    }  /* array selector */
  } while ((unsigned long)LINK->LINK->sy < 32 &&
	   ((1L << ((long)LINK->LINK->sy)) &
	    ((1L << ((long)lbrack)) | (1L << ((long)period)))) != 0);
  test(fsys, P_expset(SET, 0L), ersym, LINK);
}  /* selector */



Local Void actparams(cp, lastp, LINK)
long *cp, *lastp;
struct LOC_block *LINK;
{
  long k;
  item x;
  symset SET, SET1;

  do {
    insymbol(LINK->LINK);
    if (*cp >= *lastp)
      error(erpar, LINK->LINK);
    else {
      (*cp)++;
      if (tab[*cp].normal) {
	/* value parameter */
	expression(P_setunion(SET1, LINK->fsys, P_expset(SET,
		       (1L << ((long)comma)) | (1L << ((long)colon)) |
		       (1L << ((long)rparent)))), &x, LINK);
/* p2c: pfccomp.pas, line 5464: 
 * Note: Line breaker spent 1.0 seconds, 5000 tries on line 3090 [251] */
	if (x.typ == (types)tab[*cp].typ) {
	  if (x.typ == enums) {
	    if (x.ref != tab[*cp].auxref)
	      error(ertyp, LINK->LINK);
	  } else {
	    if (x.ref != tab[*cp].ref)
	      error(ertyp, LINK->LINK);
	    else {
	      if (x.typ == arrays)
		emit1(ldblk, atab[x.ref - 1].size, LINK->LINK);
	      else {
		if (x.typ == records)
		  emit1(ldblk, btab[x.ref - 1].vsize, LINK->LINK);
		else {
		  if (x.typ == synchros)
		    emit1(ldblk, 0L, LINK->LINK);
		}
	      }
	    }
	  }

	} else {
	  if (x.typ == ints && (types)tab[*cp].typ == reals)
	    emit1(ifloat, 0L, LINK->LINK);
	  else {
	    if (x.typ != notyp)
	      error(ertyp, LINK->LINK);
	  }
	}
      }  /* value parameter */
      else {
	/*variable parameter*/
	if (LINK->LINK->sy != ident)
	  error(erident, LINK->LINK);
	else {
	  k = loc(LINK->LINK->id, LINK);
	  insymbol(LINK->LINK);
	  if (k != 0) {
	    if (((1L << tab[k].obj) &
		 ((1L << ((long)variable)) | (1L << ((long)address)))) == 0)
	      error(erpar, LINK->LINK);
	    x.typ = (types)tab[k].typ;
	    if (x.typ == enums)
	      x.ref = tab[k].auxref;
	    else
	      x.ref = tab[k].ref;
	    if ((object)tab[k].obj == address &&
		((1L << tab[k].typ) &
		 ((1L << ((long)semafors)) | (1L << ((long)channels)))) == 0)
	      emit1typed(ldcon, tab[k].taddr, adrs, LINK->LINK);
	    else {
	      if (tab[k].normal)
		emit2(ldadr, (long)tab[k].lev, tab[k].taddr, LINK->LINK);
	      else
		emit2typed(ldval, (long)tab[k].lev, tab[k].taddr, adrs,
			   LINK->LINK);
	    }
	    if ((unsigned long)LINK->LINK->sy < 32 &&
		((1L << ((long)LINK->LINK->sy)) &
		 ((1L << ((long)lbrack)) | (1L << ((long)period)))) != 0)
	      selector(P_setunion(SET1, LINK->fsys, P_expset(SET,
			   (1L << ((long)comma)) | (1L << ((long)colon)) |
			   (1L << ((long)rparent)))), &x, LINK);
/* p2c: pfccomp.pas, line 5464: 
 * Note: Line breaker spent 0.0 seconds, 5000 tries on line 3155 [251] */
	    if (x.typ == (types)tab[*cp].typ) {
	      if (x.typ == enums) {
		if (x.ref != tab[*cp].auxref)
		  error(ertyp, LINK->LINK);
	      } else {
		if (x.ref != tab[*cp].ref)
		  error(ertyp, LINK->LINK);
	      }
	    } else
	      error(ertyp, LINK->LINK);

	  }
	}
      }
    }
    test(P_expset(SET, (1L << ((long)comma)) | (1L << ((long)rparent))),
	 LINK->fsys, ersym, LINK);
  } while (LINK->LINK->sy == comma);
  if (LINK->LINK->sy == rparent)
    insymbol(LINK->LINK);
  else
    error(errparent, LINK->LINK);
}  /* actparams */



Local Void call(fsys, i, LINK)
long *fsys;
long i;
struct LOC_block *LINK;
{
  item p;
  long lastp, cp;
  boolean isaprocess;
  long lc1;
  long SET[(long)endsy / 32 + 2];
  symset SET1, SET2;



  isaprocess = contains(1L << ((long)procs), (types)tab[i].typ, tab[i].ref,
			LINK);
  if (isaprocess) {
    lc1 = lc;
    emit2(mrkstk, 1L, 0L, LINK->LINK);   /* markstack for process */
    emit2(ldadr, (long)tab[i].lev, tab[i].taddr, LINK->LINK);
    p.typ = (types)tab[i].typ;
    p.ref = tab[i].ref;
    if (LINK->LINK->sy == lbrack) {
      P_addset(P_expset(SET, 0L), (int)lparent);
      selector(P_setunion(SET2,
			  P_setunion(SET1, P_addset(SET, (int)endsy), fsys),
			  LINK->LINK->statbegsys), &p, LINK);
    }
    if (p.typ != procs)
      error(ernotprocvar, LINK->LINK);
    cp = btab[p.ref - 1].tabptr;
    code[lc1].y = cp;
    emit0(procv, LINK->LINK);
    lastp = btab[p.ref - 1].lastpar;
  } else {  /* not a process */
    emit2(mrkstk, 0L, i, LINK->LINK);   /* markstack for procedure/function */
    lastp = btab[tab[i].ref - 1].lastpar;
    if ((types)tab[i + 1].typ == protq)
      cp = i + 1;
    else
      cp = i;
  }
  if (LINK->LINK->sy == lparent)
    actparams(&cp, &lastp, LINK);
  if (cp < lastp)   /* too few actual parameters */
    error(erpar, LINK->LINK);
  if (isaprocess)
    emit2(callsub, 1L, btab[p.ref - 1].psize - intsize, LINK->LINK);
  else
    emit2(callsub, 0L, btab[tab[i].ref - 1].psize - intsize, LINK->LINK);
  if (tab[i].lev < LINK->codelevel)
    emit2(updis, (long)tab[i].lev, LINK->codelevel, LINK->LINK);
}  /* call */

Local Void capscall(i, LINK)
index_ i;
struct LOC_block *LINK;
{

  /* call exported capsule procedure */
  /* i points to tab entry of capsule */
  long j;

  if (LINK->LINK->sy == period)
    insymbol(LINK->LINK);
  else
    error(erperiod, LINK->LINK);
  if (LINK->LINK->sy != ident)
    return;
  j = searchblock(btab[tab[i].ref - 1].last, LINK->LINK->id, LINK);
  if (j == 0 || ((1L << tab[j].obj) &
		 ((1L << ((long)monproc)) | (1L << ((long)xgrdproc)))) == 0) {
    error(erdec, LINK->LINK);
    return;
  }
  if ((object)tab[j].obj == xgrdproc) {
    if (LINK->LINK->curcaps != 0 &&
	(types)tab[LINK->LINK->curcaps].typ == protvars)
      error(ergrdcall, LINK->LINK);
  }
  if (i != LINK->LINK->curcaps) {
    emit2(ldadr, (long)tab[i].lev, tab[i].taddr, LINK->LINK);
    emit0(enmon, LINK->LINK);
  }
  insymbol(LINK->LINK);
  call(LINK->fsys, j, LINK);
  if (i == LINK->LINK->curcaps)
    return;
  if ((types)tab[i].typ == monvars)
    emit0(exmon, LINK->LINK);
  else {
    emit1(prtcnd, tab[i].auxref, LINK->LINK);
    emit0(prtex, LINK->LINK);
  }
}  /* capscalL */




Local Void entrycall(fsys, i, LINK)
long *fsys;
long i;
struct LOC_block *LINK;
{

  /* parse entry call.  Only entered when tab[i].typ
     contains a process */
  item e;
  long cp, lastp;
  symset SET, SET1;

  emit2(ldadr, (long)tab[i].lev, tab[i].taddr, LINK->LINK);
  e.typ = (types)tab[i].typ;
  e.ref = tab[i].ref;
  if ((unsigned long)LINK->LINK->sy < 32 &&
      ((1L << ((long)LINK->LINK->sy)) &
       ((1L << ((long)period)) | (1L << ((long)lbrack)))) != 0) {
    selector(P_setunion(SET1, fsys, P_expset(SET, 1L << ((long)lparent))), &e,
	     LINK);
    if (LINK->level == 1)
      error(erlev, LINK->LINK);
  } else
    error(erent, LINK->LINK);
  if (e.typ != entrys) {
    skip(P_setunion(SET1, P_expset(SET, 1L << ((long)semicolon)), fsys),
	 erent, LINK);
    return;
  }
  lastp = btab[e.ref - 1].lastpar;
  cp = btab[e.ref - 1].tabptr;
  if (LINK->LINK->sy == lparent)
    actparams(&cp, &lastp, LINK);
  if (cp < lastp)   /* too few actual parameters */
    error(erpar, LINK->LINK);
  emit1(ecall, btab[e.ref - 1].psize, LINK->LINK);
}  /* entrycall */



Local types resulttype(a, b, LINK)
types a, b;
struct LOC_block *LINK;
{

  /* entered with op in [plus,minus,times] */
  types Result;

  if (((1L << ((long)a)) & ((1L << ((long)notyp)) | (1L << ((long)ints)) |
	 (1L << ((long)reals)) | (1L << ((long)bitsets)))) == 0 ||
      ((1L << ((long)b)) & ((1L << ((long)notyp)) | (1L << ((long)ints)) |
	 (1L << ((long)reals)) | (1L << ((long)bitsets)))) == 0) {
/* p2c: pfccomp.pas, line 5464: 
 * Note: Line breaker spent 0.0 seconds, 5000 tries on line 3334 [251] */
    error(ertyp, LINK->LINK);
    return notyp;
  }
  if (a == notyp || b == notyp)
    return notyp;
  switch (a) {

  case ints:
    if (b == ints)
      Result = ints;
    else {
      if (b == reals) {
	Result = reals;
	emit1(ifloat, 1L, LINK->LINK);
      } else {
	error(ertyp, LINK->LINK);
	Result = notyp;
      }
    }
    break;

  case reals:
    Result = reals;
    if (b == ints)
      emit1(ifloat, 0L, LINK->LINK);
    else {
      if (b != reals) {
	error(ertyp, LINK->LINK);
	Result = notyp;
      }
    }
    break;

  case bitsets:
    if (b == bitsets)
      Result = bitsets;
    else {
      error(ertyp, LINK->LINK);
      Result = notyp;
    }
    break;
  }/* case */
  return Result;
}  /* resulttype */

/* Local variables for expression: */
struct LOC_expression {
  struct LOC_block *LINK;
} ;

/* Local variables for simpleexpression: */
struct LOC_simpleexpression {
  struct LOC_expression *LINK;
} ;

/* Local variables for term: */
struct LOC_term {
  struct LOC_simpleexpression *LINK;
} ;

/* Local variables for factor: */
struct LOC_factor {
  struct LOC_term *LINK;
  symset fsys;
  item *x;
} ;

Local Void standfun(i, LINK)
long i;
struct LOC_factor *LINK;
{

  /* standard functions */
  /* i points to tab entry for the function */
  long n;
  item v;
  typset ts;
  symset SET, SET1;

  n = tab[i].taddr;
  if ((unsigned long)n < 32 && ((1L << n) & 0x2060000L) != 0)
	/* no parameters */
	  emit1typed(stfun, n, (types)tab[i].typ,
		     LINK->LINK->LINK->LINK->LINK->LINK);
  else {  /* parameter processing */
    if (LINK->LINK->LINK->LINK->LINK->LINK->sy == lparent)
      insymbol(LINK->LINK->LINK->LINK->LINK->LINK);
    else
      error(erlparent, LINK->LINK->LINK->LINK->LINK->LINK);
    expression(P_setunion(SET1, LINK->fsys,
			  P_expset(SET, 1L << ((long)rparent))), &v,
	       LINK->LINK->LINK->LINK->LINK);
    switch (n) {

    case 0:
    case 2:   /* abs, sqr */
      ts = (1L << ((long)ints)) | (1L << ((long)reals));
      if (((1L << ((long)v.typ)) & ts) != 0)
	tab[i].typ = (unsigned)v.typ;
      if (v.typ == reals)
	n++;
      break;

    case 4:
    case 5:   /* odd, char */
      ts = 1L << ((long)ints);
      break;

    case 6:   /* ord */
      ts = (1L << ((long)ints)) | (1L << ((long)chars)) |
	   (1L << ((long)bools)) | (1L << ((long)enums));
      break;

    case 7:   /* succ */
      ts = (1L << ((long)ints)) | (1L << ((long)bools)) |
	   (1L << ((long)chars)) | (1L << ((long)enums));
      if (((1L << ((long)v.typ)) & ts) != 0) {
	tab[i].typ = (unsigned)v.typ;
	switch (v.typ) {

	case ints:
	  emit1typed(hibnd, intmax - 1L, ints,
		     LINK->LINK->LINK->LINK->LINK->LINK);
	  break;

	case bools:
	  emit1typed(hibnd, (long)fals, bools,
		     LINK->LINK->LINK->LINK->LINK->LINK);
	  break;

	case chars:
	  emit1typed(hibnd, charh - 1L, chars,
		     LINK->LINK->LINK->LINK->LINK->LINK);
	  break;

	case enums:
	  emit1typed(hibnd,
	    LINK->LINK->LINK->LINK->LINK->LINK->bounds[v.ref - 1].upper - 1,
	    ints, LINK->LINK->LINK->LINK->LINK->LINK);
	  break;
	}/* case */
      }  /* if in ts */
      break;

    case 8:   /* pred */
      ts = (1L << ((long)ints)) | (1L << ((long)bools)) |
	   (1L << ((long)chars)) | (1L << ((long)enums));
      if (((1L << ((long)v.typ)) & ts) != 0) {
	tab[i].typ = (unsigned)v.typ;
	switch (v.typ) {

	case ints:
	  emit1typed(lobnd, 1L - intmax, ints,
		     LINK->LINK->LINK->LINK->LINK->LINK);
	  break;

	case bools:
	  emit1typed(lobnd, (long)tru, bools,
		     LINK->LINK->LINK->LINK->LINK->LINK);
	  break;

	case chars:
	  emit1typed(lobnd, charl + 1L, chars,
		     LINK->LINK->LINK->LINK->LINK->LINK);
	  break;

	case enums:
	  emit1typed(lobnd, 1L, ints, LINK->LINK->LINK->LINK->LINK->LINK);
	  break;
	}/* case */
      }  /* if in ts */
      break;

    case 9:
    case 10:
    case 11:
    case 12:
    case 13:
    case 14:
    case 15:
    case 16:
      ts = (1L << ((long)ints)) | (1L << ((long)reals));
      if (v.typ == ints)
	emit1(ifloat, 0L, LINK->LINK->LINK->LINK->LINK->LINK);
      break;

    case 19:   /* random */
      ts = 1L << ((long)ints);
      break;

    case 20:   /* empty */
      ts = 1L << ((long)condvars);
      break;

    case 21:   /* bits */
      ts = 1L << ((long)ints);
      break;

    case 24:   /* int */
      ts = 1L << ((long)bitsets);
      break;
    }/* case */
    if (((1L << ((long)v.typ)) & ts) != 0)
      emit1typed(stfun, n, (types)tab[i].typ,
		 LINK->LINK->LINK->LINK->LINK->LINK);
    else {
      if (v.typ != notyp)
	error(ertyp, LINK->LINK->LINK->LINK->LINK->LINK);
    }
    if (LINK->LINK->LINK->LINK->LINK->LINK->sy == rparent)
      insymbol(LINK->LINK->LINK->LINK->LINK->LINK);
    else
      error(errparent, LINK->LINK->LINK->LINK->LINK->LINK);
  }  /* parameter processing */
  LINK->x->typ = (types)tab[i].typ;
  if (LINK->x->typ == enums)
    LINK->x->ref = v.ref;
}  /* standfun */


Local Void setlit(fsys, v, LINK)
long *fsys;
item *v;
struct LOC_factor *LINK;
{
  item e;
  types basetyp;

  insymbol(LINK->LINK->LINK->LINK->LINK->LINK);
  if (LINK->LINK->LINK->LINK->LINK->LINK->sy == rbrack) {  /* empty set */
    emit1typed(ldcon, 0L, ints, LINK->LINK->LINK->LINK->LINK->LINK);
    insymbol(LINK->LINK->LINK->LINK->LINK->LINK);
  }  /* empty set */
  else {  /* not empty set */
    expression(fsys, &e, LINK->LINK->LINK->LINK->LINK);
    if (e.typ == ints)
      basetyp = ints;
    else
      basetyp = notyp;
    emit0(power2, LINK->LINK->LINK->LINK->LINK->LINK);
    while (LINK->LINK->LINK->LINK->LINK->LINK->sy == comma) {
      insymbol(LINK->LINK->LINK->LINK->LINK->LINK);
      expression(fsys, &e, LINK->LINK->LINK->LINK->LINK);
      if (e.typ != ints)
	basetyp = notyp;
      emit0(power2, LINK->LINK->LINK->LINK->LINK->LINK);
      emit0typed(orop, bitsets, LINK->LINK->LINK->LINK->LINK->LINK);
    }  /* while sy = comma */
    if (basetyp == notyp)
      error(ersetlit, LINK->LINK->LINK->LINK->LINK->LINK);
    if (LINK->LINK->LINK->LINK->LINK->LINK->sy == rbrack)
      insymbol(LINK->LINK->LINK->LINK->LINK->LINK);
    else
      error(errbrack, LINK->LINK->LINK->LINK->LINK->LINK);
  }  /* not empty set */
  v->typ = bitsets;
  v->ref = 0;
}  /* setlit */


Local Void factor(fsys_, x_, LINK)
long *fsys_;
item *x_;
struct LOC_term *LINK;
{
  struct LOC_factor V;
  long i;
  tabrec *WITH;
  symset SET, SET1;



  V.LINK = LINK;
  P_setcpy(V.fsys, fsys_);
  V.x = x_;
  V.x->typ = notyp;
  V.x->ref = 0;
  test(LINK->LINK->LINK->LINK->LINK->facbegsys, V.fsys, ersym,
       LINK->LINK->LINK->LINK);
  while (P_inset(LINK->LINK->LINK->LINK->LINK->sy,
		 LINK->LINK->LINK->LINK->LINK->facbegsys)) {
    switch (LINK->LINK->LINK->LINK->LINK->sy) {

    case ident:
      i = loc(LINK->LINK->LINK->LINK->LINK->id, LINK->LINK->LINK->LINK);
      insymbol(LINK->LINK->LINK->LINK->LINK);
      WITH = &tab[i];
      switch ((object)WITH->obj) {

      case konstant:
	V.x->typ = (types)WITH->typ;
	if (V.x->typ == enums)
	  V.x->ref = WITH->auxref;
	else
	  V.x->ref = 0;
	emit1typed(ldcon, WITH->taddr, V.x->typ, LINK->LINK->LINK->LINK->LINK);
	break;

      case variable:
	V.x->typ = (types)WITH->typ;
	if (V.x->typ == enums)
	  V.x->ref = WITH->auxref;
	else
	  V.x->ref = WITH->ref;
	if ((unsigned long)LINK->LINK->LINK->LINK->LINK->sy < 32 &&
	    ((1L << ((long)LINK->LINK->LINK->LINK->LINK->sy)) &
	     ((1L << ((long)lbrack)) | (1L << ((long)period)))) != 0)
	{  /* structured type */
	  if (WITH->normal)
	    emit2(ldadr, (long)WITH->lev, WITH->taddr,
		  LINK->LINK->LINK->LINK->LINK);
	  else
	    emit2typed(ldval, (long)WITH->lev, WITH->taddr, adrs,
		       LINK->LINK->LINK->LINK->LINK);
	  selector(V.fsys, V.x, LINK->LINK->LINK->LINK);
	  if (((1L << ((long)V.x->typ)) & simpletyps) != 0)
	    emit0typed(repadr, V.x->typ, LINK->LINK->LINK->LINK->LINK);
	}  /* structured type */
	else {
	  if (((1L << ((long)V.x->typ)) & simpletyps) != 0) {
	    if (WITH->normal)
	      emit2typed(ldval, (long)WITH->lev, WITH->taddr, V.x->typ,
			 LINK->LINK->LINK->LINK->LINK);
	    else
	      emit2typed(ldind, (long)WITH->lev, WITH->taddr, V.x->typ,
			 LINK->LINK->LINK->LINK->LINK);
	  } else {
	    if (WITH->normal)
	      emit2(ldadr, (long)WITH->lev, WITH->taddr,
		    LINK->LINK->LINK->LINK->LINK);
	    else
	      emit2typed(ldval, (long)WITH->lev, WITH->taddr, adrs,
			 LINK->LINK->LINK->LINK->LINK);
	  }
	}
	break;

      case address:
	V.x->typ = (types)WITH->typ;
	if (V.x->typ == enums)
	  V.x->ref = WITH->auxref;
	else
	  V.x->ref = WITH->ref;
	if ((types)WITH->typ == semafors)
	  emit2(ldadr, (long)WITH->lev, WITH->taddr,
		LINK->LINK->LINK->LINK->LINK);
	else
	  emit1typed(ldcon, WITH->taddr, adrs, LINK->LINK->LINK->LINK->LINK);
	if ((unsigned long)LINK->LINK->LINK->LINK->LINK->sy < 32 &&
	    ((1L << ((long)LINK->LINK->LINK->LINK->LINK->sy)) &
	     ((1L << ((long)lbrack)) | (1L << ((long)period)))) != 0)
	  selector(V.fsys, V.x, LINK->LINK->LINK->LINK);
	if (((1L << ((long)V.x->typ)) & simpletyps) != 0)
	  emit0typed(repadr, V.x->typ, LINK->LINK->LINK->LINK->LINK);
	break;

      case type1:
      case prozedure:
      case monproc:
      case xgrdproc:
      case grdproc:
	error(ertyp, LINK->LINK->LINK->LINK->LINK);
	break;

      case funktion:
	if (WITH->lev != 0) {
	  V.x->typ = (types)WITH->typ;
	  if (V.x->typ == enums)
	    V.x->ref = WITH->auxref;
	  call(V.fsys, i, LINK->LINK->LINK->LINK);
	} else
	  standfun(i, &V);
	break;
      }/* case obj */
      break;
      /* sy wa ident */

    case realcon:
    case charcon:
    case intcon:
      if (LINK->LINK->LINK->LINK->LINK->sy == realcon) {
	V.x->typ = reals;
	enterreal(rnum, LINK->LINK->LINK->LINK->LINK);
	emit1typed(ldcon, realindex, reals, LINK->LINK->LINK->LINK->LINK);
      } else {
	if (LINK->LINK->LINK->LINK->LINK->sy == charcon)
	  V.x->typ = chars;
	else
	  V.x->typ = ints;
	emit1typed(ldcon, LINK->LINK->LINK->LINK->LINK->inum, V.x->typ,
		   LINK->LINK->LINK->LINK->LINK);
      }  /* charcon, intcon */
      V.x->ref = 0;
      insymbol(LINK->LINK->LINK->LINK->LINK);
      break;
      /* intcon, realcon, charcon */

    case lbrack:
      setlit(P_setunion(SET1, V.fsys,
	       P_expset(SET, (1L << ((long)comma)) | (1L << ((long)rbrack)))),
	     V.x, &V);
      break;

    case lparent:
      insymbol(LINK->LINK->LINK->LINK->LINK);
      expression(P_setunion(SET1, V.fsys,
			    P_expset(SET, 1L << ((long)rparent))), V.x,
		 LINK->LINK->LINK->LINK);
      if (LINK->LINK->LINK->LINK->LINK->sy == rparent)
	insymbol(LINK->LINK->LINK->LINK->LINK);
      else
	error(errparent, LINK->LINK->LINK->LINK->LINK);
      break;
      /* lparent */

    case notsy:
      insymbol(LINK->LINK->LINK->LINK->LINK);
      factor(V.fsys, V.x, LINK);
      if (V.x->typ == bools)
	emit0typed(notop, bools, LINK->LINK->LINK->LINK->LINK);
      else {
	if (V.x->typ != notyp)
	  error(ertyp, LINK->LINK->LINK->LINK->LINK);
      }
      break;
      /* notsy */
    }/* case sy  */
    test(V.fsys, LINK->LINK->LINK->LINK->LINK->facbegsys, ersym,
	 LINK->LINK->LINK->LINK);
  }  /* while sy in facbegsys */
}  /* factor */

Local Void term(fsys, x, LINK)
long *fsys;
item *x;
struct LOC_simpleexpression *LINK;
{
  struct LOC_term V;
  item y;
  symbol op;
  symset SET, SET1;

  V.LINK = LINK;
  factor(P_setunion(SET1, fsys, P_expset(SET,
	     (1L << ((long)times)) | (1L << ((long)idiv)) | (1L << ((long)rdiv)) |
	     (1L << ((long)imod)) | (1L << ((long)andsy)))), x, &V);
/* p2c: pfccomp.pas, line 5464: 
 * Note: Line breaker spent 0.0 seconds, 5000 tries on line 3782 [251] */
  while ((unsigned long)LINK->LINK->LINK->LINK->sy < 32 &&
	 ((1L << ((long)LINK->LINK->LINK->LINK->sy)) &
	  ((1L << ((long)times)) | (1L << ((long)idiv)) | (1L << ((long)rdiv)) |
	   (1L << ((long)imod)) | (1L << ((long)andsy)))) != 0) {
    op = LINK->LINK->LINK->LINK->sy;
    insymbol(LINK->LINK->LINK->LINK);
    factor(P_setunion(SET1, fsys,
	     P_expset(SET, (1L << ((long)times)) | (1L << ((long)idiv)) |
			   (1L << ((long)rdiv)) | (1L << ((long)imod)) |
			   (1L << ((long)andsy)))), &y, &V);
/* p2c: pfccomp.pas, line 5464: 
 * Note: Line breaker spent 0.0 seconds, 5000 tries on line 3794 [251] */
    switch (op) {

    case times:
      x->typ = resulttype(x->typ, y.typ, LINK->LINK->LINK);
      if (((1L << ((long)x->typ)) & ((1L << ((long)ints)) |
	     (1L << ((long)reals)) | (1L << ((long)bitsets)))) != 0) {
	if (x->typ == bitsets)
	  emit0typed(andop, bitsets, LINK->LINK->LINK->LINK);
	else
	  emit0typed(mul, x->typ, LINK->LINK->LINK->LINK);
      }
      break;

    case andsy:
      if (x->typ == bools && y.typ == bools)
	emit0typed(andop, bools, LINK->LINK->LINK->LINK);
      else {
	if (x->typ != notyp && y.typ != notyp)
	  error(ertyp, LINK->LINK->LINK->LINK);
	x->typ = notyp;
      }
      break;

    case idiv:
    case imod:
      if (x->typ == ints && y.typ == ints) {
	if (op == idiv)
	  emit0typed(divop, ints, LINK->LINK->LINK->LINK);
	else
	  emit0typed(modop, ints, LINK->LINK->LINK->LINK);
      } else {
	if (x->typ != notyp && y.typ != notyp)
	  error(ertyp, LINK->LINK->LINK->LINK);
	x->typ = notyp;
      }
      break;

    case rdiv:
      if (y.typ == ints) {
	emit1(ifloat, 0L, LINK->LINK->LINK->LINK);
	y.typ = reals;
      }
      if (x->typ == ints) {
	emit1(ifloat, 1L, LINK->LINK->LINK->LINK);
	x->typ = reals;
      }
      if (x->typ == reals && y.typ == reals)
	emit0typed(divop, reals, LINK->LINK->LINK->LINK);
      else {
	if (x->typ != notyp && y.typ != notyp)
	  error(ertyp, LINK->LINK->LINK->LINK);
	x->typ = notyp;
      }
      break;
    }/* case */
  }  /* while */
}  /* term */

Local Void simpleexpression(fsys, x, LINK)
long *fsys;
item *x;
struct LOC_expression *LINK;
{
  struct LOC_simpleexpression V;
  item y;
  symbol op;
  symset SET, SET1;

  V.LINK = LINK;
  if ((unsigned long)LINK->LINK->LINK->sy < 32 &&
      ((1L << ((long)LINK->LINK->LINK->sy)) &
       ((1L << ((long)plus)) | (1L << ((long)minus)))) != 0) {
    op = LINK->LINK->LINK->sy;
    insymbol(LINK->LINK->LINK);
    term(P_setunion(SET1, fsys, P_expset(SET,
		      (1L << ((long)plus)) | (1L << ((long)minus)))), x, &V);
    if (((1L << ((long)x->typ)) & ((1L << ((long)notyp)) |
	   (1L << ((long)ints)) | (1L << ((long)reals)))) == 0)
      error(ertyp, LINK->LINK->LINK);
    else {
      if (op == minus)
	emit0typed(negate, x->typ, LINK->LINK->LINK);
    }
  } else
    term(P_setunion(SET1, fsys, P_expset(SET,
	     (1L << ((long)plus)) | (1L << ((long)minus)) | (1L << ((long)orsy)))),
	 x, &V);
  while ((unsigned long)LINK->LINK->LINK->sy < 32 &&
	 ((1L << ((long)LINK->LINK->LINK->sy)) & ((1L << ((long)plus)) |
	    (1L << ((long)minus)) | (1L << ((long)orsy)))) != 0) {
    op = LINK->LINK->LINK->sy;
    insymbol(LINK->LINK->LINK);
    term(P_setunion(SET1, fsys, P_expset(SET,
	     (1L << ((long)plus)) | (1L << ((long)minus)) | (1L << ((long)orsy)))),
	 &y, &V);
    if (op == orsy) {
      if (x->typ == bools && y.typ == bools)
	emit0typed(orop, bools, LINK->LINK->LINK);
      else {
	if (x->typ != notyp && y.typ != notyp)
	  error(ertyp, LINK->LINK->LINK);
	x->typ = notyp;
      }
      continue;
    }  /* if op = orsy */
    x->typ = resulttype(x->typ, y.typ, LINK->LINK);
    if (((1L << ((long)x->typ)) & ((1L << ((long)ints)) |
	   (1L << ((long)reals)) | (1L << ((long)bitsets)))) == 0)
      continue;
    if (op == plus) {
      if (x->typ == bitsets)
	emit0typed(orop, bitsets, LINK->LINK->LINK);
      else
	emit0typed(add, x->typ, LINK->LINK->LINK);
    } else
      emit0typed(sub, x->typ, LINK->LINK->LINK);
  }  /* while sy in plus, minus, orsy */

  /* sy in [plus,minus] */
}  /* simpleexpression */

Local Void expression(fsys, x, LINK)
long *fsys;
item *x;
struct LOC_block *LINK;
{
  struct LOC_expression V;
  item y;
  symbol op;
  long SET[(long)insy / 32 + 2];
  symset SET1;

  V.LINK = LINK;
  P_addset(P_expset(SET, 0L), (int)eql);
  P_addset(SET, (int)neq);
  P_addset(SET, (int)lss);
  P_addset(SET, (int)leq);
  P_addset(SET, (int)gtr);
  P_addset(SET, (int)geq);
  simpleexpression(P_setunion(SET1, fsys, P_addset(SET, (int)insy)), x, &V);
  if (LINK->LINK->sy != (int)insy && LINK->LINK->sy != (int)geq &&
      LINK->LINK->sy != (int)gtr && LINK->LINK->sy != (int)leq &&
      LINK->LINK->sy != (int)lss && LINK->LINK->sy != (int)neq &&
      LINK->LINK->sy != (int)eql)
    return;
  op = LINK->LINK->sy;
  insymbol(LINK->LINK);
  simpleexpression(fsys, &y, &V);
  if (op == insy) {
    if (x->typ != ints || y.typ != bitsets) {
      if (x->typ != notyp && y.typ != notyp)
	error(ertyp, LINK->LINK);
    } else
      emit0(btest, LINK->LINK);
  } else {
    if (((1L << ((long)x->typ)) & simpletyps) != 0) {
      if (x->typ == enums && y.typ == enums) {
	if (x->ref != y.ref)
	  error(ertyp, LINK->LINK);
      } else {
	if (x->typ == ints && y.typ == reals) {
	  x->typ = reals;
	  emit1(ifloat, 1L, LINK->LINK);
	} else {
	  if (x->typ == reals && y.typ == ints) {
	    y.typ = reals;
	    emit1(ifloat, 0L, LINK->LINK);
	  }
	}
      }
      if (x->typ != y.typ) {
	if (x->typ != notyp && y.typ != notyp)
	  error(ertyp, LINK->LINK);
      } else {
	switch (op) {

	case eql:
	  emit0typed(relequ, x->typ, LINK->LINK);
	  break;

	case neq:
	  emit0typed(relneq, x->typ, LINK->LINK);
	  break;

	case lss:
	  emit0typed(rellt, x->typ, LINK->LINK);
	  break;

	case leq:
	  emit0typed(relle, x->typ, LINK->LINK);
	  break;

	case gtr:
	  emit0typed(relgt, x->typ, LINK->LINK);
	  break;

	case geq:
	  emit0typed(relge, x->typ, LINK->LINK);
	  break;
	}/* case */
      }
    } else
      error(ertyp, LINK->LINK);
  }
  x->typ = bools;
}  /* expressioN */

/* Local variables for statement: */
struct LOC_statement {
  struct LOC_block *LINK;
  symset fsys;
  long i;
} ;









Local Void channelop2(tptr, x, inselect, LINK)
long tptr;
item x;
boolean inselect;
struct LOC_statement *LINK;
{

  /* second part of channel operation parser */
  /* entered from assignment or channelop with x a channel */
  types basetype;
  index_ baseref, basesize;
  long k, extra;
  item y;
  _REC_chantab *WITH;
  symset SET;
  tabrec *WITH1;
  long SET1[(long)endsy / 32 + 2];
  long SET2[(long)elsesy / 32 + 2];

  if ((object)tab[tptr].obj == address)
    extra = 4;
  else
    extra = 0;
  WITH = &LINK->LINK->LINK->chantab[x.ref - 1];
  basetype = (types)WITH->eltyp;
  baseref = WITH->elref;
  basesize = WITH->elsize;
  if ((unsigned long)LINK->LINK->LINK->sy >= 32 ||
      ((1L << ((long)LINK->LINK->LINK->sy)) &
       ((1L << ((long)shriek)) | (1L << ((long)query)))) == 0) {
    skip(P_expset(SET, 1L << ((long)semicolon)), ersym, LINK->LINK);
    return;
  }
  if (LINK->LINK->LINK->sy == query) {
    insymbol(LINK->LINK->LINK);
    if (LINK->LINK->LINK->sy != ident) {
      P_addset(P_expset(SET1, 0L), (int)semicolon);
      P_addset(SET1, (int)orsy);
      skip(P_addset(SET1, (int)endsy), erident, LINK->LINK);
      return;
    }  /* if sy = ident */
    k = loc(LINK->LINK->LINK->id, LINK->LINK);
    if (k == 0) {
      skip(P_expset(SET, 1L << ((long)semicolon)), erdec, LINK->LINK);
      return;
    }
    WITH1 = &tab[k];
    if (((1L << WITH1->obj) &
	 ((1L << ((long)variable)) | (1L << ((long)address)))) == 0) {
      skip(P_expset(SET, 1L << ((long)semicolon)), ervar, LINK->LINK);
      return;
    }
    y.typ = (types)WITH1->typ;
    if (y.typ == enums)
      y.ref = WITH1->auxref;
    else
      y.ref = WITH1->ref;
    if ((object)WITH1->obj == variable) {
      if (WITH1->normal)
	emit2(ldadr, (long)WITH1->lev, WITH1->taddr, LINK->LINK->LINK);
      else
	emit2typed(ldval, (long)WITH1->lev, WITH1->taddr, adrs,
		   LINK->LINK->LINK);
    } else
      emit1typed(ldcon, WITH1->taddr, adrs, LINK->LINK->LINK);
    insymbol(LINK->LINK->LINK);
    if ((unsigned long)LINK->LINK->LINK->sy < 32 &&
	((1L << ((long)LINK->LINK->LINK->sy)) &
	 ((1L << ((long)lbrack)) | (1L << ((long)period)))) != 0) {
      P_addset(P_expset(SET1, 0L), (int)semicolon);
      P_addset(SET1, (int)orsy);
      selector(P_setunion(SET, LINK->fsys, P_addset(SET1, (int)endsy)), &y,
	       LINK->LINK);
    }
    if (y.typ != basetype || y.ref != baseref) {
      error(ertyp, LINK->LINK->LINK);
      return;
    }
    if (inselect) {
      emit2(selec1, 3L, extra + 2, LINK->LINK->LINK);
      emit2(selec1, 4L, basesize, LINK->LINK->LINK);
    } else
      emit2(chanrd, extra, basesize, LINK->LINK->LINK);


    return;
  }  /* sy was query */
  insymbol(LINK->LINK->LINK);
  expression(P_setunion(SET, LINK->fsys,
			P_addset(P_expset(SET2, 0L), (int)elsesy)), &y,
	     LINK->LINK);
  if (y.typ != basetype || y.ref != baseref) {
    error(ertyp, LINK->LINK->LINK);
    return;
  }
  if (((1L << ((long)y.typ)) & simpletyps) != 0) {
    if (inselect) {
      emit2(selec1, 3L, extra, LINK->LINK->LINK);
      emit2(selec1, 4L, basesize, LINK->LINK->LINK);
    } else
      emit2typed(chanwr, extra, basesize, y.typ, LINK->LINK->LINK);


    return;
  }
  if (inselect) {
    emit2(selec1, 3L, extra + 1, LINK->LINK->LINK);
    emit2(selec1, 4L, basesize, LINK->LINK->LINK);
  } else
    emit2typed(chanwr, extra, basesize, y.typ, LINK->LINK->LINK);


  /* obj in [variable,address] */
  /* obj in [variable,address] */
  /* sy is shriek */
  /* sy was shriek */
}  /* channelop2 */

Local Void channelop(LINK)
struct LOC_statement *LINK;
{

  /* first part of channel operation parser */
  /* entered from selstatement with sy=id */
  long i;
  item x;
  symset SET;
  tabrec *WITH;
  symset SET1;

  i = loc(LINK->LINK->LINK->id, LINK->LINK);
  if (i == 0) {
    skip(P_expset(SET, 1L << ((long)semicolon)), erdec, LINK->LINK);
    return;
  }
  WITH = &tab[i];
  if (((1L << WITH->obj) &
       ((1L << ((long)variable)) | (1L << ((long)address)))) == 0) {
    skip(P_expset(SET, 1L << ((long)semicolon)), ervar, LINK->LINK);
    return;
  }
  insymbol(LINK->LINK->LINK);
  x.typ = (types)WITH->typ;
  x.ref = WITH->ref;
  if (WITH->normal)
    emit2(ldadr, (long)WITH->lev, WITH->taddr, LINK->LINK->LINK);
  else
    emit2typed(ldval, (long)WITH->lev, WITH->taddr, adrs, LINK->LINK->LINK);
  if ((unsigned long)LINK->LINK->LINK->sy < 32 &&
      ((1L << ((long)LINK->LINK->LINK->sy)) &
       ((1L << ((long)lbrack)) | (1L << ((long)period)))) != 0)
    selector(P_setunion(SET1,
	       P_expset(SET, (1L << ((long)becomes)) | (1L << ((long)eql)) |
			     (1L << ((long)shriek)) | (1L << ((long)query))),
	       LINK->fsys), &x, LINK->LINK);

  if (x.typ == channels)
    channelop2(i, x, true, LINK);
  else
    skip(P_expset(SET, 1L << ((long)semicolon)), ertyp, LINK->LINK);

  /* obj in [variable,address] */
  /* obj in [variable,address] */
}  /* channelop */







Local Void assignment(lv, ad, LINK)
long lv, ad;
struct LOC_statement *LINK;
{
  item x, y;
  symset SET, SET1;


  x.typ = (types)tab[LINK->i].typ;
  if (x.typ == enums)
    x.ref = tab[LINK->i].auxref;
  else
    x.ref = tab[LINK->i].ref;
  if ((object)tab[LINK->i].obj == address && x.typ != channels)
    emit1typed(ldcon, tab[LINK->i].taddr, adrs, LINK->LINK->LINK);
  else {
    if (tab[LINK->i].normal)
      emit2(ldadr, lv, ad, LINK->LINK->LINK);
    else
      emit2typed(ldval, lv, ad, adrs, LINK->LINK->LINK);
  }
  if ((unsigned long)LINK->LINK->LINK->sy < 32 &&
      ((1L << ((long)LINK->LINK->LINK->sy)) &
       ((1L << ((long)lbrack)) | (1L << ((long)period)))) != 0)
    selector(P_setunion(SET1,
	       P_expset(SET, (1L << ((long)shriek)) | (1L << ((long)query)) |
			     (1L << ((long)becomes)) | (1L << ((long)eql))),
	       LINK->fsys), &x, LINK->LINK);
  if (x.typ == channels) {
    channelop2(LINK->i, x, false, LINK);
    return;
  }
  if (contains((1L << ((long)semafors)) | (1L << ((long)channels)) |
	       (1L << ((long)condvars)), x.typ, x.ref, LINK->LINK))
    error(erassign, LINK->LINK->LINK);
  if (LINK->LINK->LINK->sy == becomes)
    insymbol(LINK->LINK->LINK);
  else
    error(erbecomes, LINK->LINK->LINK);
  expression(LINK->fsys, &y, LINK->LINK);
  if (x.typ == y.typ) {
    if (((1L << ((long)x.typ)) & simpletyps) != 0) {
      emit0typed(store, x.typ, LINK->LINK->LINK);
      if (x.typ == enums && x.ref != y.ref)
	error(ertyp, LINK->LINK->LINK);
      return;
    }
    if (x.ref != y.ref) {
      error(ertyp, LINK->LINK->LINK);
      return;
    }
    if (x.typ == arrays) {
      emit1(cpblk, atab[x.ref - 1].size, LINK->LINK->LINK);
      return;
    }
    if (x.typ == records)
      emit1(cpblk, btab[x.ref - 1].vsize, LINK->LINK->LINK);
    else {
      if (x.typ == synchros)
	emit1(cpblk, 0L, LINK->LINK->LINK);
    }
    return;
  }  /* x.typ = y.typ */
  if (x.typ == reals && y.typ == ints) {
    emit1(ifloat, 0L, LINK->LINK->LINK);
    emit0typed(store, reals, LINK->LINK->LINK);
  } else {
    if (y.typ != notyp)
      error(ertyp, LINK->LINK->LINK);
  }
}  /* assignment */


Local Void compoundstatement(LINK)
struct LOC_statement *LINK;
{
  long SET[(long)endsy / 32 + 2];
  symset SET1, SET2, SET3;

  insymbol(LINK->LINK->LINK);
  P_addset(P_expset(SET, 0L), (int)semicolon);
  statement(P_setunion(SET1, P_addset(SET, (int)endsy), LINK->fsys),
	    LINK->LINK);
  while (P_inset(LINK->LINK->LINK->sy,
		 P_setunion(SET2, P_expset(SET1, 1L << ((long)semicolon)),
			    LINK->LINK->LINK->statbegsys))) {
    if (LINK->LINK->LINK->sy == semicolon)
      insymbol(LINK->LINK->LINK);
    else
      error(ersemi, LINK->LINK->LINK);
    P_addset(P_expset(SET, 0L), (int)semicolon);
    statement(P_setunion(SET3, P_addset(SET, (int)endsy), LINK->fsys),
	      LINK->LINK);
  }
  if (LINK->LINK->LINK->sy == endsy)
    insymbol(LINK->LINK->LINK);
  else
    error(erend, LINK->LINK->LINK);
}  /* compoundstatement */


Local Void ifstatement(LINK)
struct LOC_statement *LINK;
{
  item x;
  long lc1, lc2;
  long SET[(long)thensy / 32 + 2];
  symset SET1;
  long SET2[(long)elsesy / 32 + 2];

  insymbol(LINK->LINK->LINK);
  P_addset(P_expset(SET, 0L), (int)thensy);
  expression(P_setunion(SET1, LINK->fsys, P_addset(SET, (int)dosy)), &x,
	     LINK->LINK);
  if (((1L << ((long)x.typ)) & ((1L << ((long)bools)) | (1L << ((long)notyp)))) == 0)
    error(ertyp, LINK->LINK->LINK);
  lc1 = lc;
  emit0(jmpiz, LINK->LINK->LINK);   /*jmpc*/
  if (LINK->LINK->LINK->sy == thensy)
    insymbol(LINK->LINK->LINK);
  else
    error(erthen, LINK->LINK->LINK);
  statement(P_setunion(SET1, LINK->fsys,
		       P_addset(P_expset(SET2, 0L), (int)elsesy)),
	    LINK->LINK);
  if (LINK->LINK->LINK->sy != elsesy) {
    code[lc1].y = lc;
    return;
  }

  insymbol(LINK->LINK->LINK);
  lc2 = lc;
  emit0(jmp, LINK->LINK->LINK);
  code[lc1].y = lc;

  statement(LINK->fsys, LINK->LINK);
  code[lc2].y = lc;
}  /* ifstatement */

/* Local variables for casestatement: */
struct LOC_casestatement {
  struct LOC_statement *LINK;
  item x;
  long i, j;
  _REC_casetab casetab[casemax];
  long exittab[casemax];
} ;


Local Void caselabel(LINK)
struct LOC_casestatement *LINK;
{
  conrec lab;
  long k;
  symset SET, SET1;

  constant(P_setunion(SET1, LINK->LINK->fsys,
	     P_expset(SET, (1L << ((long)comma)) | (1L << ((long)colon)))),
	   &lab, LINK->LINK->LINK);
  if (lab.tp != LINK->x.typ ||
      lab.tp == enums && lab.UU.U15.ref != LINK->x.ref) {
    error(ertyp, LINK->LINK->LINK->LINK);
    return;
  }
  if (LINK->i == casemax) {
    fatal(13L, LINK->LINK->LINK->LINK);
    return;
  }
  LINK->i++;
  k = 0;
  LINK->casetab[LINK->i - 1].val = lab.UU.i;
  LINK->casetab[LINK->i - 1].lc = lc;
  do {
    k++;
  } while (LINK->casetab[k - 1].val != lab.UU.i);
  if (k < LINK->i)
    error(ercasedup, LINK->LINK->LINK->LINK);
}  /* caselabel */


Local Void onecase(LINK)
struct LOC_casestatement *LINK;
{
  long SET[(long)endsy / 32 + 2];
  symset SET1;

  if (!P_inset(LINK->LINK->LINK->LINK->sy,
	       LINK->LINK->LINK->LINK->constbegsys))
    return;
  caselabel(LINK);
  while (LINK->LINK->LINK->LINK->sy == comma) {
    insymbol(LINK->LINK->LINK->LINK);
    caselabel(LINK);
  }
  if (LINK->LINK->LINK->LINK->sy == colon)
    insymbol(LINK->LINK->LINK->LINK);
  else
    error(ercolon, LINK->LINK->LINK->LINK);

  P_addset(P_expset(SET, 0L), (int)semicolon);
  statement(P_setunion(SET1, P_addset(SET, (int)endsy), LINK->LINK->fsys),
	    LINK->LINK->LINK);
  LINK->j++;
  LINK->exittab[LINK->j - 1] = lc;
  emit0(jmp, LINK->LINK->LINK->LINK);
}  /* onecase */

Local Void casestatement(LINK)
struct LOC_statement *LINK;
{
  struct LOC_casestatement V;
  long k, lc1;
  long SET[(long)ofsy / 32 + 2];
  symset SET1;
  long FORLIM;

  V.LINK = LINK;
  insymbol(LINK->LINK->LINK);
  V.i = 0;
  V.j = 0;
  P_addset(P_expset(SET, 0L), (int)ofsy);
  P_addset(SET, (int)comma);
  expression(P_setunion(SET1, LINK->fsys, P_addset(SET, (int)colon)), &V.x,
	     LINK->LINK);
  if (((1L << ((long)V.x.typ)) &
       ((1L << ((long)ints)) | (1L << ((long)bools)) | (1L << ((long)chars)) |
	(1L << ((long)enums)) | (1L << ((long)notyp)))) == 0) {
    error(ertyp, LINK->LINK->LINK);
    V.x.typ = notyp;
  }
  lc1 = lc;
  emit0(jmp, LINK->LINK->LINK);
  if (LINK->LINK->LINK->sy == ofsy)
    insymbol(LINK->LINK->LINK);
  else
    error(erof, LINK->LINK->LINK);
  onecase(&V);
  while (LINK->LINK->LINK->sy == semicolon) {
    insymbol(LINK->LINK->LINK);
    onecase(&V);
  }
  code[lc1].y = lc;

  FORLIM = V.i;
  for (k = 0; k < FORLIM; k++) {
    emit1typed(ldcon, V.casetab[k].val, V.x.typ, LINK->LINK->LINK);
    emit1typed(case1, V.casetab[k].lc, V.x.typ, LINK->LINK->LINK);
  }
  emit0(case2, LINK->LINK->LINK);
  FORLIM = V.j;
  for (k = 0; k < FORLIM; k++)
    code[V.exittab[k]].y = lc;

  if (LINK->LINK->LINK->sy == endsy)
    insymbol(LINK->LINK->LINK);
  else
    error(erend, LINK->LINK->LINK);
}  /* casestatement */

Local Void repeatstatement(LINK)
struct LOC_statement *LINK;
{
  item x;
  long lc1;
  boolean nestedloops;
  long SET[(long)untilsy / 32 + 2];
  symset SET1, SET2, SET3;

  nestedloops = LINK->LINK->LINK->inaloop;
  LINK->LINK->LINK->inaloop = true;
  lc1 = lc;

  insymbol(LINK->LINK->LINK);
  P_addset(P_expset(SET, 0L), (int)semicolon);
  P_addset(SET, (int)untilsy);
  statement(P_setunion(SET1, P_addset(SET, (int)foreversy), LINK->fsys),
	    LINK->LINK);
  while (P_inset(LINK->LINK->LINK->sy,
		 P_setunion(SET2, P_expset(SET1, 1L << ((long)semicolon)),
			    LINK->LINK->LINK->statbegsys))) {
    if (LINK->LINK->LINK->sy == semicolon)
      insymbol(LINK->LINK->LINK);
    else
      error(ersemi, LINK->LINK->LINK);
    P_addset(P_expset(SET, 0L), (int)semicolon);
    P_addset(SET, (int)untilsy);
    statement(P_setunion(SET3, P_addset(SET, (int)foreversy), LINK->fsys),
	      LINK->LINK);
  }
  if (LINK->LINK->LINK->sy == untilsy) {
    insymbol(LINK->LINK->LINK);
    expression(LINK->fsys, &x, LINK->LINK);
    if (((1L << ((long)x.typ)) &
	 ((1L << ((long)bools)) | (1L << ((long)notyp)))) == 0)
      error(ertyp, LINK->LINK->LINK);
    emit1(jmpiz, lc1, LINK->LINK->LINK);
  } else {
    if (LINK->LINK->LINK->sy == foreversy) {
      emit1(jmp, lc1, LINK->LINK->LINK);
      insymbol(LINK->LINK->LINK);
    } else
      error(eruntil, LINK->LINK->LINK);
  }
  LINK->LINK->LINK->inaloop = nestedloops;
}  /* repeatstatement */

Local Void whilestatement(LINK)
struct LOC_statement *LINK;
{
  item x;
  long lc1, lc2;
  boolean nestedloops;
  long SET[(long)dosy / 32 + 2];
  symset SET1;

  nestedloops = LINK->LINK->LINK->inaloop;
  LINK->LINK->LINK->inaloop = true;
  insymbol(LINK->LINK->LINK);
  lc1 = lc;
  expression(P_setunion(SET1, LINK->fsys,
			P_addset(P_expset(SET, 0L), (int)dosy)), &x,
	     LINK->LINK);
  if (((1L << ((long)x.typ)) & ((1L << ((long)bools)) | (1L << ((long)notyp)))) == 0)
    error(ertyp, LINK->LINK->LINK);
  lc2 = lc;
  emit0(jmpiz, LINK->LINK->LINK);
  if (LINK->LINK->LINK->sy == dosy)
    insymbol(LINK->LINK->LINK);
  else
    error(erdo, LINK->LINK->LINK);
  statement(LINK->fsys, LINK->LINK);
  emit1(jmp, lc1, LINK->LINK->LINK);
  code[lc2].y = lc;
  LINK->LINK->LINK->inaloop = nestedloops;
}  /* whilestatement */

Local Void forstatement(LINK)
struct LOC_statement *LINK;
{
  types cvt;
  item x;
  long i, lc1, lc2, rf;
  boolean nestedloops;
  long SET[(long)tosy / 32 + 2];
  symset SET1;
  long SET2[(long)dosy / 32 + 2];
  symset SET3;

  cvt = notyp;   /* default in case of errors */
  nestedloops = LINK->LINK->LINK->inaloop;
  LINK->LINK->LINK->inaloop = true;
  insymbol(LINK->LINK->LINK);
  if (LINK->LINK->LINK->sy == ident) {
    i = loc(LINK->LINK->LINK->id, LINK->LINK);
    if (i != 0) {
      if ((object)tab[i].obj == variable) {
	cvt = (types)tab[i].typ;
	if (cvt == enums)
	  rf = tab[i].auxref;
	else
	  rf = tab[i].ref;
	if (!tab[i].normal)
	  error(erinx, LINK->LINK->LINK);
	else
	  emit2(ldadr, (long)tab[i].lev, tab[i].taddr, LINK->LINK->LINK);
	if (((1L << ((long)cvt)) & ((1L << ((long)notyp)) |
	       (1L << ((long)ints)) | (1L << ((long)bools)) |
	       (1L << ((long)chars)) | (1L << ((long)enums)))) == 0) {
	  cvt = notyp;
	  error(ertyp, LINK->LINK->LINK);
	}
      }  /* obj was variable */
      else {  /* not variable */
	error(ervar, LINK->LINK->LINK);
	cvt = notyp;
      }
    }
    insymbol(LINK->LINK->LINK);
  }  /* sy was ident */
  else {
    P_addset(P_expset(SET, 0L), (int)becomes);
    P_addset(SET, (int)tosy);
    skip(P_setunion(SET1, P_addset(SET, (int)dosy), LINK->fsys), erident,
	 LINK->LINK);
  }
  if (LINK->LINK->LINK->sy == becomes) {
    insymbol(LINK->LINK->LINK);
    P_addset(P_expset(SET, 0L), (int)tosy);
    expression(P_setunion(SET1, P_addset(SET, (int)dosy), LINK->fsys), &x,
	       LINK->LINK);
    if (x.typ != cvt && cvt != notyp)
      error(ertyp, LINK->LINK->LINK);
    else {
      if (cvt == enums) {
	if (x.ref != rf)
	  error(ertyp, LINK->LINK->LINK);
      }
    }
  } else {
    P_addset(P_expset(SET, 0L), (int)tosy);
    skip(P_setunion(SET1, P_addset(SET, (int)dosy), LINK->fsys), erbecomes,
	 LINK->LINK);
  }
  if (LINK->LINK->LINK->sy == tosy) {
    insymbol(LINK->LINK->LINK);
    expression(P_setunion(SET3,
		 P_setunion(SET1, P_addset(P_expset(SET2, 0L), (int)dosy),
			    LINK->LINK->LINK->statbegsys),
		 LINK->fsys), &x, LINK->LINK);
    if (x.typ != cvt && cvt != notyp)
      error(ertyp, LINK->LINK->LINK);
    else {
      if (cvt == enums) {
	if (x.ref != rf)
	  error(ertyp, LINK->LINK->LINK);
      }
    }
  } else
    skip(P_setunion(SET1, P_addset(P_expset(SET2, 0L), (int)dosy), LINK->fsys),
	 erto, LINK->LINK);
  lc1 = lc;
  emit1typed(for1up, lc1, cvt, LINK->LINK->LINK);
  if (LINK->LINK->LINK->sy == dosy)
    insymbol(LINK->LINK->LINK);
  else
    error(erdo, LINK->LINK->LINK);
  lc2 = lc;

  statement(LINK->fsys, LINK->LINK);
  emit1typed(for2up, lc2, cvt, LINK->LINK->LINK);
  code[lc1].y = lc;

  LINK->LINK->LINK->inaloop = nestedloops;
}  /* forstatement */



Local Void acceptstatement(LINK)
struct LOC_statement *LINK;
{

  /* Ada-like accept statement */
  long i, extra;
  boolean err;
  long SET[(long)dosy / 32 + 2];
  symset SET1;
  long SET2[(long)endsy / 32 + 2];

  if (!LINK->LINK->LINK->inprocessdec || LINK->LINK->codelevel != 2)
    error(eracptinproc, LINK->LINK->LINK);
  extra = 0;
  err = false;
  insymbol(LINK->LINK->LINK);
  if (LINK->LINK->LINK->sy != ident) {
    skip(LINK->fsys, erident, LINK->LINK);
    return;
  }
  i = find(LINK->LINK->LINK->id, LINK->LINK);
  insymbol(LINK->LINK->LINK);
  if (i == 0) {
    err = true;
    skip(P_setunion(SET1, P_addset(P_expset(SET, 0L), (int)dosy), LINK->fsys),
	 erdec, LINK->LINK);
  } else {
    if ((types)tab[i].typ != entrys) {
      err = true;
      skip(P_setunion(SET1, P_addset(P_expset(SET, 0L), (int)dosy),
		      LINK->fsys), ertyp, LINK->LINK);
    } else {  /* is an entry */
      if (tab[i].auxref != 0)
	error(ernestacpt, LINK->LINK->LINK);
      tab[i].auxref = 1;
      if ((object)tab[i].obj == address)
	extra = 4;
      parametercheck(i, LINK->LINK);
    }  /* is an entry */
  }
  if (LINK->LINK->LINK->sy == dosy)
    insymbol(LINK->LINK->LINK);
  else
    error(erdo, LINK->LINK->LINK);
  if (err) {
    P_addset(P_expset(SET2, 0L), (int)semicolon);
    statement(P_setunion(SET1, P_addset(SET2, (int)endsy), LINK->fsys),
	      LINK->LINK);
    return;
  }
  LINK->LINK->level++;
  display[LINK->LINK->level] = tab[i].ref;
  emit2(ldadr, (long)tab[i].lev, tab[i].taddr, LINK->LINK->LINK);
  emit2(acpt1, extra, btab[tab[i].ref - 1].psize, LINK->LINK->LINK);
  P_addset(P_expset(SET2, 0L), (int)semicolon);
  statement(P_setunion(SET1, P_addset(SET2, (int)endsy), LINK->fsys),
	    LINK->LINK);
  LINK->LINK->level--;
  emit2(ldadr, (long)tab[i].lev, tab[i].taddr, LINK->LINK->LINK);
  emit2(acpt2, extra, btab[tab[i].ref - 1].psize, LINK->LINK->LINK);
  tab[i].auxref = 0;

  /* no error */
  /* no error */
  /* sy was ident */
}  /* acceptstatement */


Local Void acceptinselect(k, LINK)
index_ *k;
struct LOC_statement *LINK;
{

  /* Ada-like accept statement in select statement */
  long i, extra;
  index_ h, j;

  boolean err;
  long SET[(long)dosy / 32 + 2];
  symset SET1;
  long SET2[(long)elsesy / 32 + 2];


  if (!LINK->LINK->LINK->inprocessdec || LINK->LINK->codelevel != 2)
    error(eracptinproc, LINK->LINK->LINK);
  extra = 0;
  err = false;

  j = 0;
  insymbol(LINK->LINK->LINK);
  if (LINK->LINK->LINK->sy != ident) {
    skip(LINK->fsys, erident, LINK->LINK);
    *k = lc;   /* do not return with k undefined */
    return;
  }
  i = find(LINK->LINK->LINK->id, LINK->LINK);
  insymbol(LINK->LINK->LINK);
  if (i == 0) {
    err = true;
    skip(P_setunion(SET1, P_addset(P_expset(SET, 0L), (int)dosy), LINK->fsys),
	 erdec, LINK->LINK);
  } else {
    if ((types)tab[i].typ != entrys) {
      err = true;
      skip(P_setunion(SET1, P_addset(P_expset(SET, 0L), (int)dosy),
		      LINK->fsys), ertyp, LINK->LINK);
    } else {  /* is entry */
      if (tab[i].auxref != 0)
	error(ernestacpt, LINK->LINK->LINK);
      tab[i].auxref = 1;
      if ((object)tab[i].obj == address)
	extra = 4;
      parametercheck(i, LINK->LINK);
    }  /* is entry */

  }

  if (LINK->LINK->LINK->sy == dosy)
    insymbol(LINK->LINK->LINK);
  else
    error(erdo, LINK->LINK->LINK);
  if (err) {
    *k = lc;   /* do not return with k undefined */
    P_addset(P_expset(SET2, 0L), (int)semicolon);
    P_addset(SET2, (int)elsesy);
    statement(P_setunion(SET1, P_addset(SET2, (int)endsy), LINK->fsys),
	      LINK->LINK);
    return;
  }
  LINK->LINK->level++;
  display[LINK->LINK->level] = tab[i].ref;
  emit2(ldadr, (long)tab[i].lev, tab[i].taddr, LINK->LINK->LINK);

  emit1typed(ldcon, 0L, ints, LINK->LINK->LINK);   /* data not used in ada */


  emit2(selec1, 3L, extra + 3, LINK->LINK->LINK);
  emit2(selec1, 4L, btab[tab[i].ref - 1].psize, LINK->LINK->LINK);
  h = lc;
  emit2(selec1, 5L, 0L, LINK->LINK->LINK);
  emit1typed(ldcon, 0L, ints, LINK->LINK->LINK);
      /* rep index not used in ada */

  j = lc;
  emit1(jmp, 0L, LINK->LINK->LINK);   /* address supplied by oneselect */
  code[h].y = lc;


  emit2(ldadr, (long)tab[i].lev, tab[i].taddr, LINK->LINK->LINK);
  emit1(acpt1, btab[tab[i].ref - 1].psize, LINK->LINK->LINK);
  P_addset(P_expset(SET2, 0L), (int)semicolon);
  P_addset(SET2, (int)elsesy);
  statement(P_setunion(SET1, P_addset(SET2, (int)endsy), LINK->fsys),
	    LINK->LINK);

  LINK->LINK->level--;

  emit2(ldadr, (long)tab[i].lev, tab[i].taddr, LINK->LINK->LINK);
  emit1(acpt2, btab[tab[i].ref - 1].psize, LINK->LINK->LINK);

  tab[i].auxref = 0;
  *k = j;



  /* no error */
  /* no error */
  /* sy was ident */
}  /* acceptinselect */

/* Local variables for selstatement: */
struct LOC_selstatement {
  struct LOC_statement *LINK;
  index_ ends[casemax];
  char c;
  boolean term, time;
} ;

/* Local variables for oneselect: */
struct LOC_oneselect {
  struct LOC_selstatement *LINK;
  short replc, repcj;
} ;

Local Void repstart(i, cvt, LINK)
long *i;
types *cvt;
struct LOC_oneselect *LINK;
{

  /* leading code for replicate alternative */
  long rf;
  item x;
  long SET[(long)tosy / 32 + 2];
  symset SET1;
  long SET2[(long)replicatesy / 32 + 2];

  *cvt = notyp;   /* default in case of errors */
  insymbol(LINK->LINK->LINK->LINK->LINK);
  if (LINK->LINK->LINK->LINK->LINK->sy == ident) {
    *i = loc(LINK->LINK->LINK->LINK->LINK->id, LINK->LINK->LINK->LINK);
    if (*i == 0)
      *cvt = notyp;
    else {
      if ((object)tab[*i].obj == variable) {
	*cvt = (types)tab[*i].typ;
	if (*cvt == enums)
	  rf = tab[*i].auxref;
	else
	  rf = tab[*i].ref;
	if (!tab[*i].normal)
	  error(erinx, LINK->LINK->LINK->LINK->LINK);
	else
	  emit2(ldadr, (long)tab[*i].lev, tab[*i].taddr,
		LINK->LINK->LINK->LINK->LINK);
	if (((1L << ((long)(*cvt))) & ((1L << ((long)notyp)) |
	       (1L << ((long)ints)) | (1L << ((long)chars)) |
	       (1L << ((long)bools)) | (1L << ((long)enums)))) == 0) {
	  error(ertyp, LINK->LINK->LINK->LINK->LINK);
	  *cvt = notyp;
	}
      }  /* obj was variable */
      else {  /* not variable */
	error(ervar, LINK->LINK->LINK->LINK->LINK);
	*cvt = notyp;
      }
    }
    insymbol(LINK->LINK->LINK->LINK->LINK);
  }  /* if sy = ident */
  else {
    P_addset(P_expset(SET, 0L), (int)becomes);
    P_addset(SET, (int)tosy);
    skip(P_setunion(SET1, P_addset(SET, (int)dosy), LINK->LINK->LINK->fsys),
	 erident, LINK->LINK->LINK->LINK);
  }
  if (LINK->LINK->LINK->LINK->LINK->sy == becomes) {
    insymbol(LINK->LINK->LINK->LINK->LINK);
    P_addset(P_expset(SET, 0L), (int)tosy);
    expression(P_setunion(SET1, P_addset(SET, (int)dosy),
			  LINK->LINK->LINK->fsys), &x,
	       LINK->LINK->LINK->LINK);
    if (x.typ != *cvt && *cvt != notyp)
      error(ertyp, LINK->LINK->LINK->LINK->LINK);
    else {
      if (x.typ == enums) {
	if (x.ref != rf)
	  error(ertyp, LINK->LINK->LINK->LINK->LINK);
      }
    }
  }  /* sy = becomes */
  else {
    P_addset(P_expset(SET, 0L), (int)tosy);
    skip(P_setunion(SET1, P_addset(SET, (int)dosy), LINK->LINK->LINK->fsys),
	 erbecomes, LINK->LINK->LINK->LINK);
  }
  emit0typed(store, *cvt, LINK->LINK->LINK->LINK->LINK);
  LINK->replc = lc;

  emit2typed(ldval, (long)tab[*i].lev, tab[*i].taddr, *cvt,
	     LINK->LINK->LINK->LINK->LINK);
  if (LINK->LINK->LINK->LINK->LINK->sy == tosy)
    insymbol(LINK->LINK->LINK->LINK->LINK);
  else
    error(erto, LINK->LINK->LINK->LINK->LINK);
  P_addset(P_expset(SET2, 0L), (int)whensy);
  P_addset(SET2, (int)replicatesy);
  expression(P_setunion(SET1, P_addset(SET2, (int)dosy),
			LINK->LINK->LINK->fsys), &x, LINK->LINK->LINK->LINK);
  if (x.typ != *cvt && *cvt != notyp)
    error(ertyp, LINK->LINK->LINK->LINK->LINK);
  else {
    if (*cvt == enums) {
      if (x.ref != rf)
	error(ertyp, LINK->LINK->LINK->LINK->LINK);
    }
  }
  emit0typed(relle, *cvt, LINK->LINK->LINK->LINK->LINK);
  LINK->repcj = lc;
  emit0(jmpiz, LINK->LINK->LINK->LINK->LINK);   /* address comes later */
  if (LINK->LINK->LINK->LINK->LINK->sy == replicatesy)
    insymbol(LINK->LINK->LINK->LINK->LINK);
  else
    error(erreplicate, LINK->LINK->LINK->LINK->LINK);
}  /* repstart */

Local Void repend(i, cvt, LINK)
long i;
types cvt;
struct LOC_oneselect *LINK;
{

  /* trailing code for replicate alternative */
  emit2(ldadr, (long)tab[i].lev, tab[i].taddr, LINK->LINK->LINK->LINK->LINK);
  emit1typed(rep2c, (long)LINK->replc, cvt, LINK->LINK->LINK->LINK->LINK);
  code[LINK->repcj].y = lc;

}


Local Void oneselect(LINK)
struct LOC_selstatement *LINK;
{

  /* parse one select alternative */
  struct LOC_oneselect V;
  item x;
  boolean guard, rep;
  long i;
  index_ g, h, k;
  types cvt;
  symset SET, SET1;
  long SET2[(long)elsesy / 32 + 2];
  long SET3[(long)ident / 32 + 2];
  long SET4[(long)elsesy / 32 + 2];



  V.LINK = LINK;
  if (LINK->LINK->LINK->LINK->sy == forsy) {
    rep = true;
    repstart(&i, &cvt, &V);
  } else
    rep = false;
  guard = (LINK->LINK->LINK->LINK->sy == whensy);
  if (guard) {
    insymbol(LINK->LINK->LINK->LINK);
    expression(P_setunion(SET1, LINK->LINK->fsys, P_expset(SET,
			    (1L << ((long)arrow)) | (1L << ((long)becomes)))),
	       &x, LINK->LINK->LINK);
    if (x.typ != bools)
      error(ertyp, LINK->LINK->LINK->LINK);
    if (LINK->LINK->LINK->LINK->sy == arrow)
      insymbol(LINK->LINK->LINK->LINK);
    else
      error(ersym, LINK->LINK->LINK->LINK);
    g = lc;
    emit1(jmpiz, 0L, LINK->LINK->LINK->LINK);
	/* address of next select comes later */
  }  /* guard found */
  if (LINK->LINK->LINK->LINK->sy == forsy) {
    error(ersym, LINK->LINK->LINK->LINK);
    repstart(&i, &cvt, &V);
  }
  if (LINK->LINK->LINK->LINK->sy == (int)acceptsy ||
      LINK->LINK->LINK->LINK->sy == (int)timeoutsy ||
      LINK->LINK->LINK->LINK->sy == (int)ident) {
    if (LINK->LINK->LINK->LINK->sy == ident) {  /* channel alternative */
      channelop(LINK->LINK);
      k = lc;
      emit2(selec1, 5L, 0L, LINK->LINK->LINK->LINK);
      if (rep)
	emit2typed(ldval, (long)tab[i].lev, tab[i].taddr, cvt,
		   LINK->LINK->LINK->LINK);
      else
	emit1typed(ldcon, 0L, ints, LINK->LINK->LINK->LINK);




      h = lc;
      emit1(jmp, 0L, LINK->LINK->LINK->LINK);
      code[k].y = lc;
    }  /* channel alternative */
    else {
      if (LINK->LINK->LINK->LINK->sy == acceptsy) {
	if (rep)
	  error(ersym, LINK->LINK->LINK->LINK);
	acceptinselect(&h, LINK->LINK);
      } else {  /* timeout alternative */
	if (rep)
	  error(ersym, LINK->LINK->LINK->LINK);
	if (LINK->term)
	  error(ertimetermelse, LINK->LINK->LINK->LINK);
	LINK->time = true;
	insymbol(LINK->LINK->LINK->LINK);
	emit1typed(ldcon, 0L, ints, LINK->LINK->LINK->LINK);   /* chanptr */

	emit1typed(ldcon, 0L, ints, LINK->LINK->LINK->LINK);   /* dataptr */


	emit1typed(ldcon, 0L, ints, LINK->LINK->LINK->LINK);   /* trantype */


	P_addset(P_expset(SET2, 0L), (int)semicolon);
	P_addset(SET2, (int)orsy);
	P_addset(SET2, (int)elsesy);
	expression(P_setunion(SET, LINK->LINK->fsys,
			      P_addset(SET2, (int)endsy)), &x,
		   LINK->LINK->LINK);


	if (x.typ != ints)
	  error(ertyp, LINK->LINK->LINK->LINK);
	k = lc;
	emit2(selec1, 5L, 0L, LINK->LINK->LINK->LINK);
	emit1typed(ldcon, 0L, ints, LINK->LINK->LINK->LINK);

	h = lc;
	emit1(jmp, 0L, LINK->LINK->LINK->LINK);   /* address comes later */
	code[k].y = lc;
      }
    }

    if (rep)
      emit2typed(rep1c, (long)tab[i].lev, tab[i].taddr, cvt,
		 LINK->LINK->LINK->LINK);
    while (P_inset(LINK->LINK->LINK->LINK->sy,
		   P_setunion(SET, LINK->LINK->LINK->LINK->statbegsys,
			      (P_addset(P_expset(SET3, 0L), (int)semicolon),
			       P_addset(SET3, (int)ident))))) {
      if (LINK->LINK->LINK->LINK->sy == semicolon)
	insymbol(LINK->LINK->LINK->LINK);
      else
	error(ersemi, LINK->LINK->LINK->LINK);

      P_addset(P_expset(SET4, 0L), (int)semicolon);
      P_addset(SET4, (int)orsy);
      P_addset(SET4, (int)endsy);

      statement(P_setunion(SET1, LINK->LINK->fsys,
			   P_addset(SET4, (int)elsesy)), LINK->LINK->LINK);
    }
    if (LINK->c == casemax)
      fatal(8L, LINK->LINK->LINK->LINK);
    LINK->c++;
    LINK->ends[LINK->c - 1] = lc;
    emit1(jmp, 0L, LINK->LINK->LINK->LINK);
	/* gets select exit address later */
    if (guard)
      code[g].y = lc;
    code[h].y = lc;

    if (rep)
      repend(i, cvt, &V);
    return;
  }  /* channel op alternative */
  if (LINK->LINK->LINK->LINK->sy != termsy) {
    skip(P_expset(SET, 1L << ((long)semicolon)), ersym, LINK->LINK->LINK);
    return;
  }
  if (guard || rep)
    error(ersym, LINK->LINK->LINK->LINK);
  else {
    if (LINK->time)
      error(ertimetermelse, LINK->LINK->LINK->LINK);
  }
  LINK->term = true;
  insymbol(LINK->LINK->LINK->LINK);
  if (LINK->LINK->LINK->LINK->sy == semicolon)
    insymbol(LINK->LINK->LINK->LINK);
  else {
    if (LINK->LINK->LINK->LINK->sy != (int)elsesy &&
	LINK->LINK->LINK->LINK->sy != (int)endsy)
      error(ersym, LINK->LINK->LINK->LINK);

  }

  P_addset(P_expset(SET4, 0L), (int)orsy);
  P_addset(SET4, (int)endsy);

  test(P_addset(SET4, (int)elsesy), P_expset(SET, 0L), ersym,
       LINK->LINK->LINK);



}  /* oneselect */





Local Void selstatement(LINK)
struct LOC_statement *LINK;
{

  /* parser for select statement */
  struct LOC_selstatement V;
  long f, loop;

  boolean priority;
  long SET[(long)endsy / 32 + 2];
  symset SET1;
  long SET2[(long)ident / 32 + 2];
  symset SET3;
  long FORLIM;


  V.LINK = LINK;
  V.term = false;
  V.time = false;
  priority = (LINK->LINK->LINK->sy == prisy);
  if (priority)
    insymbol(LINK->LINK->LINK);
  V.c = 0;
  if (LINK->LINK->LINK->sy == selectsy)
    insymbol(LINK->LINK->LINK);
  else
    error(erselect, LINK->LINK->LINK);

  emit2(selec1, 0L, 0L, LINK->LINK->LINK);   /* sentinel */
  oneselect(&V);
  while (LINK->LINK->LINK->sy == orsy) {
    insymbol(LINK->LINK->LINK);
    oneselect(&V);
  }
  if (V.term)
    f = 1;
  else {
    if (LINK->LINK->LINK->sy == elsesy)
      f = 2;
    else
      f = 0;
  }

  if (priority)
    emit2(selec0, 1L, f, LINK->LINK->LINK);
  else
    emit2(selec0, 0L, f, LINK->LINK->LINK);
  if (LINK->LINK->LINK->sy == elsesy) {
    if (V.term || V.time)
      error(ertimetermelse, LINK->LINK->LINK);
    insymbol(LINK->LINK->LINK);
    P_addset(P_expset(SET, 0L), (int)semicolon);
    P_addset(SET, (int)ident);
    statement(P_setunion(SET1, LINK->fsys, P_addset(SET, (int)endsy)),
	      LINK->LINK);
    while (P_inset(LINK->LINK->LINK->sy,
		   P_setunion(SET1, LINK->LINK->LINK->statbegsys,
			      (P_addset(P_expset(SET2, 0L), (int)semicolon),
			       P_addset(SET2, (int)ident))))) {
      if (LINK->LINK->LINK->sy == semicolon)
	insymbol(LINK->LINK->LINK);
      else
	error(ersemi, LINK->LINK->LINK);
      P_addset(P_expset(SET, 0L), (int)semicolon);
      P_addset(SET, (int)ident);
      statement(P_setunion(SET3, LINK->fsys, P_addset(SET, (int)endsy)),
		LINK->LINK);
    }
    if (LINK->LINK->LINK->sy == semicolon)
      insymbol(LINK->LINK->LINK);
  }  /* else part */

  if (LINK->LINK->LINK->sy == endsy)
    insymbol(LINK->LINK->LINK);
  else
    error(erend, LINK->LINK->LINK);
  FORLIM = V.c;
  for (loop = 0; loop < FORLIM; loop++)
    code[V.ends[loop]].y = lc;

}  /* selstatement */





Local Void requeuestatement(LINK)
struct LOC_statement *LINK;
{
  long i, distref;

  distref = 0;
  if (!LINK->LINK->LINK->inguardedproc || LINK->LINK->level != 3)
    error(eronlyingrdproc, LINK->LINK->LINK);
  insymbol(LINK->LINK->LINK);
  if (LINK->LINK->LINK->sy != ident) {
    error(erident, LINK->LINK->LINK);
    return;
  }
  i = loc(LINK->LINK->LINK->id, LINK->LINK);
  if (i == 0) {  /* identifier not found */
    error(erdec, LINK->LINK->LINK);
    return;
  }
  if ((object)tab[i].obj == variable) {  /* could be capsule name */
    if ((types)tab[i].typ != protvars)
      error(ertyp, LINK->LINK->LINK);
    else {  /* resource name found - is it a local call? */
      if (i != LINK->LINK->LINK->curcaps)
	distref = i;
      insymbol(LINK->LINK->LINK);
      if (LINK->LINK->LINK->sy == period)
	insymbol(LINK->LINK->LINK);
      else
	error(erperiod, LINK->LINK->LINK);
      if (LINK->LINK->LINK->sy != ident)
	error(erident, LINK->LINK->LINK);
      else {  /* find procedure name */
	i = searchblock(btab[tab[i].ref - 1].last, LINK->LINK->LINK->id,
			LINK->LINK);
	if (i == 0)
	  error(erdec, LINK->LINK->LINK);
      }
    }
  }
  if (((1L << tab[i].obj) &
       ((1L << ((long)grdproc)) | (1L << ((long)xgrdproc)))) == 0) {
    error(ermustbeguarded, LINK->LINK->LINK);
    return;
  }
  insymbol(LINK->LINK->LINK);
  if (distref != 0) {  /* requeue to a different resource */
    emit1(prtcnd, tab[LINK->LINK->LINK->curcaps].auxref, LINK->LINK->LINK);
    emit2(ldadr, (long)tab[distref].lev, tab[distref].taddr, LINK->LINK->LINK);
    emit0(enmon, LINK->LINK->LINK);
  }
  call(LINK->fsys, i, LINK->LINK);
  if (distref != 0) {
    emit1(prtcnd, tab[distref].auxref, LINK->LINK->LINK);
    emit2(prtex, 1L, 0L, LINK->LINK->LINK);
  }
  emit0(retproc, LINK->LINK->LINK);

  /* could be dotted or simple notation */
}  /* requeuestatemenT */


Local Void standproc(n, LINK)
long n;
struct LOC_statement *LINK;
{
  long i, sptr;
  item x, v;
  boolean based;
  symset SET, SET1;
  long SET2[(long)percent / 32 + 2];

  /*standproc*/
  switch (n) {

  case 1:
  case 2:
    /* read */
    if (LINK->LINK->LINK->sy == lparent) {
      do {
	insymbol(LINK->LINK->LINK);
	if (LINK->LINK->LINK->sy != ident)
	  error(erident, LINK->LINK->LINK);
	else {
	  i = loc(LINK->LINK->LINK->id, LINK->LINK);
	  insymbol(LINK->LINK->LINK);
	  if (i != 0) {
	    if (((1L << tab[i].obj) &
		 ((1L << ((long)variable)) | (1L << ((long)address)))) == 0)
	      error(ervar, LINK->LINK->LINK);
	    else {
	      x.typ = (types)tab[i].typ;
	      x.ref = tab[i].ref;
	      if ((object)tab[i].obj == address)
		emit1typed(ldcon, tab[i].taddr, adrs, LINK->LINK->LINK);
	      else {
		if (tab[i].normal)
		  emit2(ldadr, (long)tab[i].lev, tab[i].taddr,
			LINK->LINK->LINK);
		else
		  emit2typed(ldval, (long)tab[i].lev, tab[i].taddr, adrs,
			     LINK->LINK->LINK);
	      }
	      if ((unsigned long)LINK->LINK->LINK->sy < 32 &&
		  ((1L << ((long)LINK->LINK->LINK->sy)) &
		   ((1L << ((long)lbrack)) | (1L << ((long)period)))) != 0)
		selector(P_setunion(SET1, LINK->fsys, P_expset(SET,
		      (1L << ((long)comma)) | (1L << ((long)rparent)))), &x,
		  LINK->LINK);
	      if (((1L << ((long)x.typ)) &
		   ((1L << ((long)ints)) | (1L << ((long)reals)) |
		    (1L << ((long)chars)) | (1L << ((long)notyp)))) != 0)
		emit0typed(readip, x.typ, LINK->LINK->LINK);
	      else
		error(ertyp, LINK->LINK->LINK);
	    }
	  }
	}
	test(P_expset(SET, (1L << ((long)comma)) | (1L << ((long)rparent))),
	     LINK->fsys, ersym, LINK->LINK);
      } while (LINK->LINK->LINK->sy == comma);
      if (LINK->LINK->LINK->sy == rparent)
	insymbol(LINK->LINK->LINK);
      else
	error(errparent, LINK->LINK->LINK);
    }
    if (n == 2)
      emit0(rdlin, LINK->LINK->LINK);
    break;

  case 3:
  case 4:
    /* write */
    if (LINK->LINK->LINK->sy == lparent) {
      do {
	insymbol(LINK->LINK->LINK);
	if (LINK->LINK->LINK->sy == string) {
	  sptr = LINK->LINK->LINK->inum;
	  emit1typed(ldcon, LINK->LINK->LINK->sleng, ints, LINK->LINK->LINK);
	  insymbol(LINK->LINK->LINK);
	  if (LINK->LINK->LINK->sy == colon) {
	    insymbol(LINK->LINK->LINK);
	    expression(P_setunion(SET1, LINK->fsys, P_expset(SET,
			   (1L << ((long)comma)) | (1L << ((long)rparent)))),
		       &v, LINK->LINK);
	    if (v.typ != ints)
	      error(ertyp, LINK->LINK->LINK);
	    emit1(wrsfm, sptr, LINK->LINK->LINK);
	  } else
	    emit1(wrstr, sptr, LINK->LINK->LINK);
	}  /* string */
	else {
	  P_addset(P_expset(SET2, 0L), (int)comma);
	  P_addset(SET2, (int)colon);
	  P_addset(SET2, (int)percent);
	  expression(P_setunion(SET, LINK->fsys, P_addset(SET2, (int)rparent)),
		     &x, LINK->LINK);
	  if (((1L << ((long)x.typ)) & (simpletyps | (1L << ((long)semafors))) &
	       (~(1L << ((long)enums)))) == 0) {
	    error(ertyp, LINK->LINK->LINK);
	    x.typ = notyp;
	  }
	  if (x.typ == semafors)
	    emit0typed(repadr, semafors, LINK->LINK->LINK);
	  if (LINK->LINK->LINK->sy == (int)percent ||
	      LINK->LINK->LINK->sy == (int)colon) {
	    if (LINK->LINK->LINK->sy == percent) {
	      if (((1L << ((long)x.typ)) &
		   ((1L << ((long)ints)) | (1L << ((long)bitsets)))) == 0) {
		error(ertyp, LINK->LINK->LINK);
		based = false;
	      } else
		based = true;
	    } else
	      based = false;
	    insymbol(LINK->LINK->LINK);
	    expression(P_setunion(SET1, LINK->fsys, P_expset(SET,
			   (1L << ((long)comma)) | (1L << ((long)colon)) |
			   (1L << ((long)rparent)))), &v, LINK->LINK);
/* p2c: pfccomp.pas, line 5464: 
 * Note: Line breaker spent 0.0 seconds, 5000 tries on line 5361 [251] */
	    if (v.typ != ints)
	      error(ertyp, LINK->LINK->LINK);
	    if (based)
	      emit0typed(wrbas, x.typ, LINK->LINK->LINK);
	    else {  /* formatted output */
	      if (LINK->LINK->LINK->sy == colon) {
		if (x.typ != reals)
		  error(ertyp, LINK->LINK->LINK);
		insymbol(LINK->LINK->LINK);
		expression(P_setunion(SET1, LINK->fsys, P_expset(SET,
		      (1L << ((long)comma)) | (1L << ((long)rparent)))), &v,
		  LINK->LINK);
		if (v.typ != ints)
		  error(ertyp, LINK->LINK->LINK);
		emit0(w2frm, LINK->LINK->LINK);
	      } else
		emit0typed(wrfrm, x.typ, LINK->LINK->LINK);
	    }  /* formatted output */
	  } else
	    emit0typed(wrval, x.typ, LINK->LINK->LINK);
	}
      } while (LINK->LINK->LINK->sy == comma);
      if (LINK->LINK->LINK->sy == rparent)
	insymbol(LINK->LINK->LINK);
      else
	error(errparent, LINK->LINK->LINK);
    }
    if (n == 4)
      emit0(wrlin, LINK->LINK->LINK);
    break;

  case 5:
  case 6:
  case 7:
  case 8:
  case 9:
    /* wait,asignal,delay,resume,initial */
    if (n == 9) {   /* initial */
      if (LINK->LINK->LINK->inprocessdec)
	error(ernotinproc, LINK->LINK->LINK);
    }
    if (LINK->LINK->LINK->sy != lparent)
      error(erlparent, LINK->LINK->LINK);
    else {
      insymbol(LINK->LINK->LINK);
      if (LINK->LINK->LINK->sy != ident)
	error(erident, LINK->LINK->LINK);
      else {
	i = loc(LINK->LINK->LINK->id, LINK->LINK);
	insymbol(LINK->LINK->LINK);
	if (i != 0) {
	  if (((1L << tab[i].obj) &
	       ((1L << ((long)variable)) | (1L << ((long)address)))) == 0)
	    error(ertyp, LINK->LINK->LINK);
	  else {
	    x.typ = (types)tab[i].typ;
	    x.ref = tab[i].ref;
	    if (tab[i].normal)
	      emit2(ldadr, (long)tab[i].lev, tab[i].taddr, LINK->LINK->LINK);
	    else
	      emit2typed(ldval, (long)tab[i].lev, tab[i].taddr, adrs,
			 LINK->LINK->LINK);
	    if ((unsigned long)LINK->LINK->LINK->sy < 32 &&
		((1L << ((long)LINK->LINK->LINK->sy)) &
		 ((1L << ((long)lbrack)) | (1L << ((long)period)))) != 0)
	      selector(P_setunion(SET1, LINK->fsys, P_expset(SET,
			   (1L << ((long)comma)) | (1L << ((long)rparent)))),
		       &x, LINK->LINK);
	    if (x.typ == semafors && (unsigned long)n < 32 &&
		((1L << n) & 0x260) != 0) {
	      if (n == 9) {
		if (LINK->LINK->LINK->sy == comma)
		  insymbol(LINK->LINK->LINK);
		else
		  error(ersym, LINK->LINK->LINK);
		expression(P_setunion(SET1, LINK->fsys,
				      P_expset(SET, 1L << ((long)rparent))),
			   &x, LINK->LINK);
		emit1typed(lobnd, 0L, ints, LINK->LINK->LINK);
		if (((1L << ((long)x.typ)) &
		     ((1L << ((long)ints)) | (1L << ((long)notyp)))) == 0)
		  error(ertyp, LINK->LINK->LINK);
		else
		  emit0(sinit, LINK->LINK->LINK);
	      } else {
		if (n == 5) {
		  if ((object)tab[i].obj == address)
		    emit2(wait, 1L, 0L, LINK->LINK->LINK);
		  else
		    emit0(wait, LINK->LINK->LINK);
		} else
		  emit0(asignal, LINK->LINK->LINK);
	      }
	    } else {
	      if (x.typ == condvars && (unsigned long)n < 32 &&
		  ((1L << n) & 0x180) != 0) {
		if (n == 7)
		  emit0(delay, LINK->LINK->LINK);
		else
		  emit0(resum, LINK->LINK->LINK);
	      } else
		error(ertyp, LINK->LINK->LINK);
	    }
	  }
	}
      }
      if (LINK->LINK->LINK->sy == rparent)
	insymbol(LINK->LINK->LINK);
      else
	error(errparent, LINK->LINK->LINK);
    }
    break;

  case 10:
  case 11:  /* priority, sleep */
    if (LINK->LINK->LINK->sy != lparent)
      error(erlparent, LINK->LINK->LINK);
    else {
      insymbol(LINK->LINK->LINK);
      expression(P_setunion(SET1, LINK->fsys,
			    P_expset(SET, 1L << ((long)rparent))), &x,
		 LINK->LINK);
      if (x.typ != ints)
	error(ertyp, LINK->LINK->LINK);
      else {
	if (n == 10)
	  emit0(pref, LINK->LINK->LINK);
	else
	  emit0(sleap, LINK->LINK->LINK);
      }
      if (LINK->LINK->LINK->sy == rparent)
	insymbol(LINK->LINK->LINK);
      else
	error(errparent, LINK->LINK->LINK);
    }
    break;


  }/*case*/
}


/*---------------------------------------------------------------statement-*/

Local Void statement(fsys_, LINK)
long *fsys_;
struct LOC_block *LINK;
{
  struct LOC_statement V;
  long SET[(long)ident / 32 + 2];
  symset SET1;


  V.LINK = LINK;
  P_setcpy(V.fsys, fsys_);
  if (P_inset(LINK->LINK->sy,
	      P_setunion(SET1, LINK->LINK->statbegsys,
			 P_addset(P_expset(SET, 0L), (int)ident)))) {
    switch (LINK->LINK->sy) {

    case ident:
      V.i = loc(LINK->LINK->id, LINK);
      insymbol(LINK->LINK);
      if (V.i != 0) {
	switch ((object)tab[V.i].obj) {

	case konstant:
	  error(ersym, LINK->LINK);
	  break;

	case type1:
	  if ((types)tab[V.i].typ == procs)
	    error(ervar, LINK->LINK);
	  else
	    error(ersym, LINK->LINK);
	  break;

	case variable:
	case address:
	  if (((1L << tab[V.i].typ) &
	       ((1L << ((long)monvars)) | (1L << ((long)protvars)))) != 0)
	    capscall(V.i, LINK);
	  else {
	    if (contains(1L << ((long)procs), (types)tab[V.i].typ,
			 tab[V.i].ref, LINK)) {
	      if (LINK->LINK->incobegin)
		call(V.fsys, V.i, LINK);
	      else
		entrycall(V.fsys, V.i, LINK);
	    } else
	      assignment((long)tab[V.i].lev, tab[V.i].taddr, &V);
	  }
	  break;

	case prozedure:
	case monproc:
	case xgrdproc:
	case grdproc:
	  if (((1L << tab[V.i].obj) &
	       ((1L << ((long)grdproc)) | (1L << ((long)xgrdproc)))) != 0) {
	    if (LINK->LINK->curcaps != 0 &&
		(types)tab[LINK->LINK->curcaps].typ == protvars)
	      error(ergrdcall, LINK->LINK);
	  }
	  if (tab[V.i].lev != 0)
	    call(V.fsys, V.i, LINK);
	  else
	    standproc(tab[V.i].taddr, &V);
	  break;

	case funktion:
	  if (tab[V.i].ref == display[LINK->level])
	    assignment(tab[V.i].lev + 1L, 0L, &V);
	  else
	    error(ertyp, LINK->LINK);
	  break;
	}/* case tab[i].obj of */
      }
      break;
      /* ident case */

    case beginsy:
      if (!strncmp(LINK->LINK->id, "cobegin   ", sizeof(alfa_))) {
	if (LINK->LINK->wascobegin || LINK->LINK->inaloop)
	  error(ercob, LINK->LINK);
	LINK->LINK->incobegin = true;
	if (LINK->level == 1) {
	  emit0(cobeg, LINK->LINK);
	  LINK->LINK->wascobegin = true;
	} else
	  error(erlev, LINK->LINK);
	compoundstatement(&V);
	emit0(coend, LINK->LINK);
      } else
	compoundstatement(&V);
      break;

    case ifsy:
      ifstatement(&V);
      break;

    case casesy:
      casestatement(&V);
      break;

    case whilesy:
      whilestatement(&V);
      break;

    case repeatsy:
      repeatstatement(&V);
      break;

    case forsy:
      forstatement(&V);
      break;

    case selectsy:
    case prisy:
      selstatement(&V);
      break;


    case nullsy:
      insymbol(LINK->LINK);
      break;

    case acceptsy:
      acceptstatement(&V);
      break;

    case requeuesy:
      requeuestatement(&V);
      break;

    }/* case sy of */
  }
  test(V.fsys, P_expset(SET1, 0L), ersemi, LINK);
}  /* statement */






Local Void testforward(k, LINK)
long k;
struct LOC_block *LINK;
{

  /* test that forward declarations (forward, provides) were resolved */
  boolean noerror;
  tabrec *WITH;

  noerror = true;
  while (k != 0 && noerror) {
    WITH = &tab[k];
    if ((types)WITH->typ == procs) {
      if (!WITH->normal) {
	noerror = false;
	error(erprovdec, LINK->LINK);
      }
    } else {
      if (((1L << WITH->obj) & ((1L << ((long)prozedure)) |
	     (1L << ((long)funktion)) | (1L << ((long)monproc)) |
	     (1L << ((long)grdproc)) | (1L << ((long)xgrdproc)))) != 0) {
	if (!WITH->normal) {
	  noerror = false;
	  error(erfordec, LINK->LINK);
	}
      }
    }
    k = tab[k].link;
  }
}  /* testforward */

/* Local variables for capsuledeclaration: */
struct LOC_capsuledeclaration {
  struct LOC_block *LINK;
  long firstguard, glc1;
} ;

/* Local variables for exportlist: */
struct LOC_exportlist {
  struct LOC_capsuledeclaration *LINK;
} ;

Local Void entermp(LINK)
struct LOC_exportlist *LINK;
{

  /* enter procedure identifier in export table */
  long SET[(long)ident / 32 + 2];

  if (LINK->LINK->LINK->LINK->sy != ident) {
    P_addset(P_expset(SET, 0L), (int)ident);
    P_addset(SET, (int)comma);
    skip(P_addset(SET, (int)semicolon), erident, LINK->LINK->LINK);
  }
  if (LINK->LINK->LINK->LINK->sy != ident)
    return;
  if (LINK->LINK->LINK->LINK->ncapsprocs == maxcapsprocs)
    fatal(9L, LINK->LINK->LINK->LINK);
  LINK->LINK->LINK->LINK->ncapsprocs++;
  memcpy(LINK->LINK->LINK->LINK->capsproctab[LINK->LINK->LINK->LINK->
					     ncapsprocs - 1].name,
	 LINK->LINK->LINK->LINK->id, sizeof(alfa_));
  insymbol(LINK->LINK->LINK->LINK);
}  /* entermp */

Local Void exportlist(LINK)
struct LOC_capsuledeclaration *LINK;
{
  struct LOC_exportlist V;
  long SET[(long)exportsy / 32 + 2];


  V.LINK = LINK;
  insymbol(LINK->LINK->LINK);
  if (LINK->LINK->LINK->sy != ident) {
    P_addset(P_expset(SET, 0L), (int)ident);
    P_addset(SET, (int)comma);
    P_addset(SET, (int)semicolon);
    skip(P_addset(SET, (int)exportsy), erident, LINK->LINK);
  }
  while (LINK->LINK->LINK->sy == ident) {
    entermp(&V);
    while (LINK->LINK->LINK->sy == comma) {
      insymbol(LINK->LINK->LINK);
      entermp(&V);
    }  /* while sy=comma */
    if (LINK->LINK->LINK->sy == semicolon)
      insymbol(LINK->LINK->LINK);
    else
      error(ersemi, LINK->LINK->LINK);
  }  /* while sy = ident */
}  /* exportlist */





Local Void checkdecs(LINK)
struct LOC_capsuledeclaration *LINK;
{

  /* ensure that all exported procedures have been declared */
  boolean ok;
  long i, FORLIM;

  ok = true;
  FORLIM = LINK->LINK->LINK->ncapsprocs;
  for (i = 0; i < FORLIM; i++) {
    if (!LINK->LINK->LINK->capsproctab[i].foundec)
      ok = false;
  }
  if (!ok)
    error(ercapsprocdecs, LINK->LINK->LINK);
}  /* checkdecs */




Local Void guardedprocdec(LINK)
struct LOC_capsuledeclaration *LINK;
{
  long prb, prt, lc1, lc2, lc3, lc4, i;
  item x;
  alfa_ qname;
  long localdx, qref;
  boolean nestedgrd, wasforward;
  tabrec *WITH;
  long SET[(long)whensy / 32 + 2];
  symset SET1, SET2;
  long SET3[(long)beginsy / 32 + 2];
  long SET4[(long)endsy / 32 + 2];
  symset SET5;


  wasforward = false;
  nestedgrd = LINK->LINK->LINK->inguardedproc;
  if ((types)tab[LINK->LINK->LINK->curcaps].typ != protvars)
    error(eronlyinres, LINK->LINK->LINK);
  else {
    if (nestedgrd)
      error(ernotingrdproc, LINK->LINK->LINK);
  }
  LINK->LINK->LINK->inguardedproc = true;
  insymbol(LINK->LINK->LINK);
  if (LINK->LINK->LINK->sy == proceduresy)
    insymbol(LINK->LINK->LINK);
  else
    skip(LINK->LINK->fsys, ersym, LINK->LINK);
  if (LINK->LINK->LINK->sy != ident)
    error(erident, LINK->LINK->LINK);
  else {
    i = searchblock(btab[display[LINK->LINK->level] - 1].last,
		    LINK->LINK->LINK->id, LINK->LINK);
    if (i == 0 || tab[i].normal) {  /* no pending forward declaration */
      if (isexported(LINK->LINK))
	enter_(LINK->LINK->LINK->id, xgrdproc, LINK->LINK);
      else
	enter_(LINK->LINK->LINK->id, grdproc, LINK->LINK);
      prt = t;
      WITH = &tab[prt];
      WITH->typ = (unsigned)notyp;
      WITH->ref = b + 1;
      WITH->normal = true;
      WITH->lev = LINK->LINK->level;
    }  /* no pending forward declaration */
    else {
      insymbol(LINK->LINK->LINK);
      wasforward = true;
      LINK->LINK->level++;
    }
  }  /* sy was id */
  if (!wasforward) {  /* no pending forward declaration */
    internalname(&LINK->LINK->LINK->internalnum, qname, LINK->LINK);
    enter_(qname, variable, LINK->LINK);
    WITH = &tab[t];
    WITH->typ = (unsigned)protq;
    WITH->ref = 0;
    WITH->normal = true;
    WITH->lev = 1;
    alloc((long)intsize, &LINK->LINK->dx, &WITH->taddr, LINK->LINK);
    qref = t;
    insymbol(LINK->LINK->LINK);
    LINK->LINK->level++;
    localdx = actrecsize;
    if (LINK->LINK->level > lmax)
      fatal(5L, LINK->LINK->LINK);
    P_addset(P_expset(SET, 0L), (int)lparent);
    P_addset(SET, (int)semicolon);
    test(P_addset(SET, (int)whensy), LINK->LINK->fsys, ersym, LINK->LINK);
    enterblock(LINK->LINK->LINK);
    display[LINK->LINK->level] = b;
    prb = b;
    tab[prt].ref = prb;
    if (LINK->LINK->LINK->sy == lparent)
      parameterlist(false, &localdx, LINK->LINK);
    align(&localdx, LINK->LINK);
    btab[prb - 1].lastpar = t;
    btab[prb - 1].psize = localdx;
    LINK->LINK->level--;
    if (LINK->LINK->LINK->sy == whensy)
      insymbol(LINK->LINK->LINK);
    else
      error(ersym, LINK->LINK->LINK);
    tab[prt].taddr = lc;
    if (LINK->firstguard == -1) {
      LINK->firstguard = lc;
      tab[LINK->LINK->LINK->curcaps].auxref = LINK->firstguard;
    } else
      code[LINK->glc1].y = lc;
    expression(P_setunion(SET2, LINK->LINK->fsys,
			  P_expset(SET1, 1L << ((long)semicolon))), &x,
	       LINK->LINK);
    lc1 = lc;
    emit0(prtjmp, LINK->LINK->LINK);
    /* process searching for a candidate */
    lc2 = lc;
    emit0(jmpiz, LINK->LINK->LINK);
    /* guard open - load address of queue */
    emit2(ldadr, (long)tab[qref].lev, tab[qref].taddr, LINK->LINK->LINK);
    LINK->glc1 = lc;
    code[lc2].y = lc;
    emit0(jmp, LINK->LINK->LINK);
    /* process calling the procedure */
    code[lc1].y = lc;
    lc3 = lc;
    emit0(jmpiz, LINK->LINK->LINK);
    lc4 = lc;
    emit0(jmp, LINK->LINK->LINK);
    code[lc3].y = lc;
    emit1(prtcnd, LINK->firstguard, LINK->LINK->LINK);
    emit2(ldadr, (long)tab[qref].lev, tab[qref].taddr, LINK->LINK->LINK);
    emit0(prtslp, LINK->LINK->LINK);
    code[lc4].y = lc;
    LINK->LINK->level++;
    if (x.typ != bools)
      error(ertyp, LINK->LINK->LINK);
  }  /* no pending forward declaration */
  else {  /* has been forward declared */
    if (((1L << tab[i].obj) &
	 ((1L << ((long)grdproc)) | (1L << ((long)xgrdproc)))) == 0)
      error(erdup, LINK->LINK->LINK);
    prt = i;
    prb = tab[prt].ref;
    localdx = btab[prb - 1].vsize;
    tab[prt].normal = true;
    display[LINK->LINK->level] = prb;
    code[tab[prt].auxref].y = lc;
  }
  if (LINK->LINK->LINK->sy == semicolon)
    insymbol(LINK->LINK->LINK);
  else
    error(ersemi, LINK->LINK->LINK);
  if (LINK->LINK->LINK->sy == forwardsy) {
    insymbol(LINK->LINK->LINK);
    tab[prt].normal = false;
    tab[prt].auxref = lc;
    emit0(jmp, LINK->LINK->LINK);
  } else {  /* this is not a forward declaration */
    do {
      while (LINK->LINK->LINK->sy == constsy)
	constantdeclaration(LINK->LINK);
      while (LINK->LINK->LINK->sy == typesy)
	typedeclaration(LINK->LINK);
      while (LINK->LINK->LINK->sy == varsy)
	variabledeclaration(&localdx, LINK->LINK);
      while (LINK->LINK->LINK->sy == monitorsy)
	capsuledeclaration(monvars, LINK->LINK);
      while (LINK->LINK->LINK->sy == resourcesy)
	capsuledeclaration(protvars, LINK->LINK);
      align(&localdx, LINK->LINK);
      while (LINK->LINK->LINK->sy == (int)functionsy ||
	     LINK->LINK->LINK->sy == (int)proceduresy)
	procdeclaration(LINK->LINK);
      while (LINK->LINK->LINK->sy == processsy)
	processdeclaration(LINK->LINK);
      while (LINK->LINK->LINK->sy == guardedsy)
	guardedprocdec(LINK);
      test(LINK->LINK->LINK->blockbegsys, LINK->LINK->LINK->statbegsys, ersym,
	   LINK->LINK);
    } while (P_inset(LINK->LINK->LINK->sy,
		     P_setdiff(SET1, LINK->LINK->LINK->blockbegsys,
			       P_addset(P_expset(SET3, 0L), (int)beginsy))));
    testforward(btab[prb - 1].last, LINK->LINK);
    insymbol(LINK->LINK->LINK);
    P_addset(P_expset(SET4, 0L), (int)semicolon);
    statement(P_setunion(SET1, P_addset(SET4, (int)endsy), LINK->LINK->fsys),
	      LINK->LINK);
    while (P_inset(LINK->LINK->LINK->sy,
		   P_setunion(SET2, P_expset(SET1, 1L << ((long)semicolon)),
			      LINK->LINK->LINK->statbegsys))) {
      if (LINK->LINK->LINK->sy == semicolon)
	insymbol(LINK->LINK->LINK);
      else
	error(ersemi, LINK->LINK->LINK);
      P_addset(P_expset(SET4, 0L), (int)semicolon);
      statement(P_setunion(SET5, P_addset(SET4, (int)endsy), LINK->LINK->fsys),
		LINK->LINK);
    }
    emit0(retproc, LINK->LINK->LINK);
    if (LINK->LINK->LINK->sy == endsy)
      insymbol(LINK->LINK->LINK);
    else
      error(erend, LINK->LINK->LINK);
  }  /* this is not a forward declaration */
  btab[prb - 1].vsize = localdx;
  LINK->LINK->level--;
  if (LINK->LINK->LINK->sy == semicolon)
    insymbol(LINK->LINK->LINK);
  else
    error(ersemi, LINK->LINK->LINK);
  LINK->LINK->LINK->inguardedproc = nestedgrd;
}  /* guardedprocdeC */





Local Void capsuledeclaration(form, LINK)
types form;
struct LOC_block *LINK;
{

  /* process declaration of encapsulating objects:
     monitors or resources */
  struct LOC_capsuledeclaration V;
  long lc2, prt, prb;
  tabrec *WITH;
  long SET[(long)beginsy / 32 + 2];
  symset SET1;
  long SET2[(long)endsy / 32 + 2];



  V.LINK = LINK;
  if (LINK->level != 1)
    error(erlev, LINK->LINK);
  initmons(LINK->LINK);
  insymbol(LINK->LINK);
  if (LINK->LINK->sy != ident)
    error(erident, LINK->LINK);
  else {
    entervariable(LINK);
    enterblock(LINK->LINK);
    prt = t;
    prb = b;
    LINK->LINK->curcaps = prt;
    WITH = &tab[t];
    WITH->typ = (unsigned)form;
    WITH->ref = b;
    WITH->normal = true;
    WITH->lev = LINK->level;
    if (form == monvars)
      alloc((long)monvarsize, &LINK->dx, &WITH->taddr, LINK);
    else
      alloc((long)protvarsize, &LINK->dx, &WITH->taddr, LINK);
  }  /* sy was ident */
  if (LINK->LINK->sy == semicolon)
    insymbol(LINK->LINK);
  else
    error(ersemi, LINK->LINK);
  if (LINK->level == lmax)
    fatal(5L, LINK->LINK);
  LINK->level++;
  LINK->codelevel = LINK->level;
  display[LINK->level] = b;
  if (LINK->LINK->sy != exportsy)
    error(erexport, LINK->LINK);
  while (LINK->LINK->sy == exportsy)
    exportlist(&V);
  V.firstguard = -1;
  do {
    while (LINK->LINK->sy == constsy)
      constantdeclaration(LINK);
    while (LINK->LINK->sy == typesy)
      typedeclaration(LINK);
    while (LINK->LINK->sy == varsy)
      variabledeclaration(&LINK->dx, LINK);
    while (LINK->LINK->sy == monitorsy)   /* for error recovery only */
      capsuledeclaration(monvars, LINK);
    while (LINK->LINK->sy == (int)functionsy ||
	   LINK->LINK->sy == (int)proceduresy)
      procdeclaration(LINK);
    while (LINK->LINK->sy == processsy)   /* for error recovery only */
      processdeclaration(LINK);
    while (LINK->LINK->sy == guardedsy)
      guardedprocdec(&V);
  } while (P_inset(LINK->LINK->sy, P_setdiff(SET1, LINK->LINK->blockbegsys,
		     P_addset(P_expset(SET, 0L), (int)beginsy))));
  checkdecs(&V);
  if (V.firstguard != -1)
    code[V.glc1].y = lc;
  else
    tab[LINK->LINK->curcaps].auxref = lc;
  emit0(prtsel, LINK->LINK);
  lc2 = lc;   /* start of capsule body code */
  testforward(btab[prb - 1].last, LINK);
  if (LINK->LINK->sy == beginsy) {
    P_addset(P_expset(SET2, 0L), (int)semicolon);
    statement(P_setunion(SET1, P_addset(SET2, (int)endsy), LINK->fsys), LINK);
  } else {
    if (LINK->LINK->sy == endsy)
      insymbol(LINK->LINK);
    else
      error(erend, LINK->LINK);
  }
  if (lc2 != lc) {
    if (LINK->LINK->montab.n == maxmons)
      fatal(14L, LINK->LINK);
    else {
      LINK->LINK->montab.n++;
      LINK->LINK->montab.startadds[LINK->LINK->montab.n - 1] = lc2;
    }
    emit0(mretn, LINK->LINK);
  }
  testsemicolon(LINK);
  LINK->level--;
  LINK->codelevel = LINK->level;
  LINK->LINK->curcaps = 0;
}  /* capsuledeclaratioN */


Local Void entrydecs(LINK)
struct LOC_block *LINK;
{

  /* parse process entry declarations */
  long prdx;
  tabrec *WITH;

  while (LINK->LINK->sy == entrysy) {
    insymbol(LINK->LINK);
    if (LINK->LINK->sy != ident) {
      error(erident, LINK->LINK);
      continue;
    }  /* sy was ident */
    entervariable(LINK);
    enterblock(LINK->LINK);
    WITH = &tab[t];   /* with tab[t] */
    WITH->typ = (unsigned)entrys;
    WITH->ref = b;
    WITH->lev = LINK->level;
    WITH->normal = true;
    getmapping(LINK->LINK->constbegsys, LINK);
    if ((object)WITH->obj == address)
      enterint(t, (long)entrysize, &LINK->dx, &WITH->taddr, LINK);
    else
      alloc((long)entrysize, &LINK->dx, &WITH->taddr, LINK);
    prdx = LINK->dx;
    if (LINK->LINK->sy == lparent) {
      LINK->level++;
      display[LINK->level] = b;
      parameterlist(true, &LINK->dx, LINK);
      LINK->level--;
      align(&LINK->dx, LINK);
    }
    btab[b - 1].lastpar = t;
    btab[b - 1].psize = LINK->dx - prdx;
    if (LINK->LINK->sy == semicolon)
      insymbol(LINK->LINK);
    else
      error(ersemi, LINK->LINK);
  }  /* while sy = entrysy */
}  /* entrydecs */

Local Void entrymap(t, LINK)
long t;
struct LOC_block *LINK;
{
  long index;
  boolean found;

  while (t != 0) {
    if ((object)tab[t].obj == address && (types)tab[t].typ == entrys) {
      index = 1;
      found = false;
      do {
	if (intab[index - 1].tabref == t)
	  found = true;
	else
	  index++;
      } while (!found);
      emit1(enmap, index - 1, LINK->LINK);
    }
    t = tab[t].link;
  }  /* while */
}  /* entrymap */








/*--------------------------------------------------------------------*/


Local Void block(fsys_, lobj, prt, level_, LINK)
long *fsys_;
object lobj;
long prt, level_;
struct LOC_pfcfront *LINK;
{
  struct LOC_block V;
  long prb, ttt, x;   /* data allocation index */
  long SET[(long)providessy / 32 + 2];
  symset SET1, SET2;
  tabrec *WITH;
  long SET3[(long)beginsy / 32 + 2];
  long FORLIM;
  long SET4[(long)endsy / 32 + 2];
  symset SET5;





  V.LINK = LINK;
  P_setcpy(V.fsys, fsys_);
  V.level = level_;
  V.codelevel = V.level;
  if (tab[prt].normal) {  /* was not forward declared */
    V.dx = actrecsize;
    if (V.level > lmax)
      fatal(5L, LINK);
    P_addset(P_expset(SET, 0L), (int)lparent);
    P_addset(SET, (int)colon);
    P_addset(SET, (int)semicolon);
    test(P_addset(SET, (int)providessy), V.fsys, ersym, &V);
    enterblock(LINK);
    display[V.level] = b;
    prb = b;
    if (V.level == 1)
      tab[prt].typ = (unsigned)notyp;
    tab[prt].ref = prb;
    if (LINK->sy == lparent && V.level > 1)
      parameterlist(false, &V.dx, &V);
    align(&V.dx, &V);
    btab[prb - 1].lastpar = t;
    btab[prb - 1].psize = V.dx;
    if (lobj == funktion) {  /* function */
      if (LINK->sy == colon) {  /* get function type */
	insymbol(LINK);
	if (LINK->sy == ident) {
	  x = loc(LINK->id, &V);
	  insymbol(LINK);
	  if (x != 0) {
	    if ((object)tab[x].obj != type1)
	      error(ertyp, LINK);
	    else {
	      if (((1L << tab[x].typ) & (stantyps | (1L << ((long)enums)))) !=
		  0) {
		tab[prt].typ = (unsigned)((types)tab[x].typ);
		if ((types)tab[x].typ == enums)
		  tab[prt].auxref = tab[x].auxref;
	      } else
		error(ertyp, LINK);
	    }
	  }
	} else
	  skip(P_setunion(SET2, P_expset(SET1, 1L << ((long)semicolon)),
			  V.fsys), erident, &V);
      }  /* get function type */
      else
	error(ercolon, LINK);
    }  /* function */
  }  /* not forward declared */
  else {  /* was forward declared */
    prb = tab[prt].ref;
    V.dx = btab[prb - 1].vsize;
    display[V.level] = prb;
    if ((types)tab[prt].typ == procs) {
      parametercheck(prt, &V);
      if (LINK->sy == semicolon)
	insymbol(LINK);
      else
	error(ersemi, LINK);
      entrycheck(prt, &V);
    }
  }  /* was forward decalred */
  if (LINK->sy == providessy) {
    insymbol(LINK);
    tab[prt].normal = false;
    entrydecs(&V);
    btab[tab[prt].ref - 1].vsize = V.dx;
    if (LINK->sy == endsy)
      insymbol(LINK);
    else
      error(erend, LINK);
  } else {  /* not providessy */
    if (LINK->sy == semicolon)
      insymbol(LINK);
    if (LINK->sy == forwardsy) {  /* forward declaration */
      insymbol(LINK);
      if (V.level == 1)
	error(ersym, LINK);
      if (!tab[prt].normal)
	error(ersym, LINK);
      tab[prt].normal = false;
      btab[tab[prt].ref - 1].vsize = btab[tab[prt].ref - 1].psize;
    }  /* forward declaration */
    else {  /* not forwardsy */
      if (LINK->sy == entrysy)
	entrydecs(&V);
      tab[prt].normal = true;
      if (V.level == 1) {
	enter_("any       ", variable, &V);
	WITH = &tab[t];
	WITH->typ = (unsigned)synchros;
	WITH->normal = true;
	alloc((long)synchrosize, &V.dx, &WITH->taddr, &V);   /* with */
      }  /* if  level=1 */
      do {
	while (LINK->sy == constsy)
	  constantdeclaration(&V);
	while (LINK->sy == typesy)
	  typedeclaration(&V);
	while (LINK->sy == varsy)
	  variabledeclaration(&V.dx, &V);
	while (LINK->sy == monitorsy)
	  capsuledeclaration(monvars, &V);
	while (LINK->sy == resourcesy)
	  capsuledeclaration(protvars, &V);
	align(&V.dx, &V);
	while (LINK->sy == (int)guardedsy || LINK->sy == (int)functionsy ||
	       LINK->sy == (int)proceduresy) {
	  if (LINK->sy == guardedsy) {
	    error(eronlyinres, LINK);
	    insymbol(LINK);
	  }
	  procdeclaration(&V);
	}
	while (LINK->sy == processsy)
	  processdeclaration(&V);
	btab[prb - 1].vsize = V.dx;
	test(LINK->blockbegsys, LINK->statbegsys, ersym, &V);
      } while (P_inset(LINK->sy, P_setdiff(SET1, LINK->blockbegsys,
			 P_addset(P_expset(SET3, 0L), (int)beginsy))));

      tab[prt].taddr = lc;

      if (V.level == 1) {
	FORLIM = LINK->montab.n;
	for (ttt = 0; ttt < FORLIM; ttt++)
	  emit1(mexec, LINK->montab.startadds[ttt], LINK);
      }
      if ((types)tab[prt].typ == procs)
	entrymap(btab[tab[prt].ref - 1].last, &V);
      testforward(btab[prb - 1].last, &V);
      insymbol(LINK);
      P_addset(P_expset(SET4, 0L), (int)semicolon);
      statement(P_setunion(SET1, P_addset(SET4, (int)endsy), V.fsys), &V);
      while (P_inset(LINK->sy,
		     P_setunion(SET2, P_expset(SET1, 1L << ((long)semicolon)),
				LINK->statbegsys))) {
	if (LINK->sy == semicolon)
	  insymbol(LINK);
	else
	  error(ersemi, LINK);
	P_addset(P_expset(SET4, 0L), (int)semicolon);
	statement(P_setunion(SET5, P_addset(SET4, (int)endsy), V.fsys), &V);
      }
      if (LINK->sy == endsy)
	insymbol(LINK);
      else
	error(erend, LINK);
    }  /* not forward */
  }  /* not providessy */
  test(P_setunion(SET2, V.fsys, P_expset(SET1, 1L << ((long)period))),
       P_expset(SET5, 0L), ersym, &V);
}  /* blocK */


/* @(#)pfcfront.i5.2 12/1/92 */

Static Void pfcfront(success_)
boolean *success_;
{

  /* "Universal" Pascal-FC compiler front end */
  struct LOC_pfcfront V;
  long labelnum;
  FILE *TEMP;
  symset SET;
  btabrec *WITH;




  V.success = success_;
  if (setjmp(V._JL99))
    goto _L99;
  printf("\n\n");
  TEMP = stdout;
/* p2c: pfccomp.pas, line 5315:
 * Note: Taking address of stdout; consider setting VarFiles = 0 [144] */
  headermsg(&TEMP, &V);
  putchar('\n');


  if (progfile != NULL)
    progfile = freopen(progfilename, "r", progfile);
  else
    progfile = fopen(progfilename, "r");
  if (progfile == NULL)
    _EscIO(FileNotFound);
  if (listfile != NULL) {



    /* the compiler listing is sent to listfile */


    listfile = freopen("listfile", "w", listfile);
  } else
    listfile = fopen("listfile", "w");
  if (listfile == NULL)
    _EscIO(FileNotFound);
  headermsg(&listfile, &V);
  fprintf(listfile, "Compiler listing\n\n");


  initkeytab(&V);

  V.sps['+'] = plus;
  V.sps['-'] = minus;
  V.sps['/'] = rdiv;
  V.sps['('] = lparent;
  V.sps[')'] = rparent;
  V.sps['='] = eql;
  V.sps[','] = comma;
  V.sps['['] = lbrack;
  V.sps[']'] = rbrack;
  V.sps['"'] = neq;
  V.sps['&'] = andsy;
  V.sps[';'] = semicolon;
  V.sps['*'] = times;
  V.sps['!'] = shriek;
  V.sps['?'] = query;
  V.sps['%'] = percent;

  P_addsetr(P_expset(V.legalchars, 0L), 'A', 'Z');
  P_addsetr(V.legalchars, 'a', 'z');
  P_addsetr(V.legalchars, '0', '9');
  P_addset(V.legalchars, ':');
  P_addset(V.legalchars, '<');
  P_addset(V.legalchars, '>');
  P_addset(V.legalchars, '.');
  P_addset(V.legalchars, '(');
  P_addset(V.legalchars, '\'');
  P_addset(V.legalchars, '{');
  P_addset(V.legalchars, '=');
  P_addset(V.legalchars, '+');
  P_addset(V.legalchars, '-');
  P_addset(V.legalchars, '*');
  P_addset(V.legalchars, '/');
  P_addset(V.legalchars, ')');
  P_addset(V.legalchars, '}');
  P_addset(V.legalchars, ',');
  P_addset(V.legalchars, '[');
  P_addset(V.legalchars, ']');
  P_addset(V.legalchars, ';');
  P_addset(V.legalchars, '?');
  P_addset(V.legalchars, '!');
  P_addset(V.legalchars, '%');
  P_addset(P_expset(V.constbegsys, 0L), (int)plus);
  P_addset(V.constbegsys, (int)minus);
  P_addset(V.constbegsys, (int)intcon);
  P_addset(V.constbegsys, (int)realcon);
  P_addset(V.constbegsys, (int)charcon);
  P_addset(V.constbegsys, (int)ident);
  P_addset(P_expset(V.typebegsys, 0L), (int)ident);
  P_addset(V.typebegsys, (int)arraysy);
  P_addset(V.typebegsys, (int)recordsy);
  P_addset(V.typebegsys, (int)channelsy);
  P_addset(V.typebegsys, (int)lparent);
  P_addset(P_expset(V.blockbegsys, 0L), (int)constsy);
  P_addset(V.blockbegsys, (int)typesy);
  P_addset(V.blockbegsys, (int)varsy);
  P_addset(V.blockbegsys, (int)monitorsy);
  P_addset(V.blockbegsys, (int)proceduresy);
  P_addset(V.blockbegsys, (int)functionsy);
  P_addset(V.blockbegsys, (int)processsy);
  P_addset(V.blockbegsys, (int)beginsy);
  P_addset(V.blockbegsys, (int)resourcesy);
  P_addset(V.blockbegsys, (int)guardedsy);
  P_addset(P_expset(V.facbegsys, 0L), (int)intcon);
  P_addset(V.facbegsys, (int)realcon);
  P_addset(V.facbegsys, (int)charcon);
  P_addset(V.facbegsys, (int)ident);
  P_addset(V.facbegsys, (int)lparent);
  P_addset(V.facbegsys, (int)notsy);
  P_addset(V.facbegsys, (int)lbrack);
  P_addset(P_expset(V.statbegsys, 0L), (int)beginsy);
  P_addset(V.statbegsys, (int)ifsy);
  P_addset(V.statbegsys, (int)casesy);
  P_addset(V.statbegsys, (int)whilesy);
  P_addset(V.statbegsys, (int)repeatsy);
  P_addset(V.statbegsys, (int)forsy);
  P_addset(V.statbegsys, (int)selectsy);
  P_addset(V.statbegsys, (int)prisy);
  P_addset(V.statbegsys, (int)nullsy);
  P_addset(V.statbegsys, (int)acceptsy);
  P_addset(V.statbegsys, (int)requeuesy);
  stantyps = (1L << ((long)notyp)) | (1L << ((long)ints)) |
      (1L << ((long)reals)) | (1L << ((long)bools)) | (1L << ((long)chars));
  simpletyps = stantyps | (1L << ((long)enums)) | (1L << ((long)bitsets));
  ipctyps = (1L << ((long)semafors)) | (1L << ((long)condvars)) |
	    (1L << ((long)channels)) | (1L << ((long)entrys));

  lc = 0;
  V.ll = 0;
  V.cc = 0;
  V.ch = ' ';
  V.linenum = 0;
  V.lineold = 0;
  V.linenew = 0;
  V.errpos = 0;
  P_expset(V.errs, 0L);
  insymbol(&V);
  t = -1;
  a = 0;
  b = 1;
  sx = 0;
  V.chan = 0;
  r = 0;
  display[0] = 1;
  V.skipflag = false;
  V.montab.n = 0;
  initmons(&V);
  int_ = 0;
  V.et = 0;
  V.incobegin = false;
  V.wascobegin = false;
  V.inprocessdec = false;
  V.inaloop = false;
  labelnum = 0;
  V.internalnum = 0;

  if (V.sy != programsy)
    error(erprogram, &V);
  else {
    insymbol(&V);
    if (V.sy != ident)
      error(erident, &V);
    else {
      memcpy(progname, V.id, sizeof(alfa_));
      insymbol(&V);
    }
  }
  printf("Compiling %.*s ...\n", alng, progname);


  enter("          ", variable, notyp, 0L, &V);   /*sentinel*/
  enter("maxint    ", konstant, ints, (long)intmax, &V);
  enter("false     ", konstant, bools, (long)fals, &V);
  enter("true      ", konstant, bools, (long)tru, &V);
  enter("char      ", type1, chars, (long)charsize, &V);
  enter("boolean   ", type1, bools, (long)boolsize, &V);
  enter("integer   ", type1, ints, (long)intsize, &V);
  enter("real      ", type1, reals, (long)realsize, &V);
  enter("semaphore ", type1, semafors, (long)semasize, &V);
  enter("condition ", type1, condvars, (long)condvarsize, &V);
  enter("synchronou", type1, synchros, (long)synchrosize, &V);
  enter("bitset    ", type1, bitsets, (long)bitsetsize, &V);

  enter("abs       ", funktion, notyp, 0L, &V);
  enter("sqr       ", funktion, notyp, 2L, &V);
  enter("odd       ", funktion, bools, 4L, &V);
  enter("chr       ", funktion, chars, 5L, &V);
  enter("ord       ", funktion, ints, 6L, &V);
  enter("succ      ", funktion, notyp, 7L, &V);
  enter("pred      ", funktion, notyp, 8L, &V);
  enter("round     ", funktion, ints, 9L, &V);
  enter("trunc     ", funktion, ints, 10L, &V);
  enter("sin       ", funktion, reals, 11L, &V);
  enter("cos       ", funktion, reals, 12L, &V);
  enter("exp       ", funktion, reals, 13L, &V);
  enter("ln        ", funktion, reals, 14L, &V);
  enter("sqrt      ", funktion, reals, 15L, &V);
  enter("arctan    ", funktion, reals, 16L, &V);
  enter("eof       ", funktion, bools, 17L, &V);
  enter("eoln      ", funktion, bools, 18L, &V);
  enter("random    ", funktion, ints, 19L, &V);
  enter("empty     ", funktion, bools, 20L, &V);
  enter("bits      ", funktion, bitsets, 21L, &V);
  enter("int       ", funktion, ints, 24L, &V);
  enter("clock     ", funktion, ints, 25L, &V);
  enter("read      ", prozedure, notyp, 1L, &V);
  enter("readln    ", prozedure, notyp, 2L, &V);
  enter("write     ", prozedure, notyp, 3L, &V);
  enter("writeln   ", prozedure, notyp, 4L, &V);
  enter("wait      ", prozedure, notyp, 5L, &V);
  enter("signal    ", prozedure, notyp, 6L, &V);
  enter("delay     ", prozedure, notyp, 7L, &V);
  enter("resume    ", prozedure, notyp, 8L, &V);
  enter("initial   ", prozedure, notyp, 9L, &V);
  enter("priority  ", prozedure, notyp, 10L, &V);
  enter("sleep     ", prozedure, notyp, 11L, &V);

  enter("_main     ", prozedure, notyp, 0L, &V);

  useridstart = t;

  WITH = btab;
  WITH->last = t;
  WITH->lastpar = 1;
  WITH->psize = 0;
  WITH->vsize = 0;
  block(P_setunion(SET, V.blockbegsys, V.statbegsys), prozedure, t, 1L, &V);
  if (V.sy != period)
    error(erperiod, &V);
  emit0(stop, &V);
  if (*V.errs == 0L) {
    *V.success = true;
    printf("Compilation complete\n");
  } else {
    *V.success = false;
    errormsg(&V);
  }
_L99:
  putchar('\n');
}  /* pfcfront */

#undef nkw


/* @(#)listings.i4.4 11/8/91 */

Static Void putsuff(anytype)
types anytype;
{

  /* write suffix in "assembly" listing */
  if (((1L << ((long)anytype)) & (stantyps | (1L << ((long)bitsets)) |
	 (1L << ((long)adrs)) | (1L << ((long)enums)))) == 0) {
    fprintf(listfile, "    ");
    return;
  }
  switch (anytype) {

  case notyp:
    fprintf(listfile, "    ");
    break;

  case ints:
    fprintf(listfile, ".i  ");
    break;

  case bools:
    fprintf(listfile, ".b  ");
    break;

  case chars:
    fprintf(listfile, ".c  ");
    break;

  case reals:
    fprintf(listfile, ".r  ");
    break;

  case adrs:
    fprintf(listfile, ".adr");
    break;

  case enums:
    fprintf(listfile, ".enm");
    break;

  case bitsets:
    fprintf(listfile, ".bs ");
    break;

  }/* case */
}  /* putsuff */


Static Void putop(fop, tofile)
opcode fop;
FILE **tofile;
{

  /* write op-code to standard output */
  switch (fop) {

  case ldadr:
    fprintf(*tofile, "ldadr");
    break;

  case ldval:
    fprintf(*tofile, "ldval");
    break;

  case ldind:
    fprintf(*tofile, "ldind");
    break;

  case updis:
    fprintf(*tofile, "updis");
    break;

  case cobeg:
    fprintf(*tofile, "cobeg");
    break;

  case coend:
    fprintf(*tofile, "coend");
    break;

  case wait:
    fprintf(*tofile, "swait");
    break;

  case asignal:
    fprintf(*tofile, "signl");
    break;

  case stfun:
    fprintf(*tofile, "stfun");
    break;

  case ixrec:
    fprintf(*tofile, "ixrec");
    break;

  case jmp:
    fprintf(*tofile, "jmpuc");
    break;

  case jmpiz:
    fprintf(*tofile, "jmpiz");
    break;

  case for1up:
    fprintf(*tofile, "for1u");
    break;

  case for2up:
    fprintf(*tofile, "for2u");
    break;

  case mrkstk:
    fprintf(*tofile, "mkstk");
    break;

  case callsub:
    fprintf(*tofile, "calls");
    break;

  case ixary:
    fprintf(*tofile, "ixary");
    break;

  case ldblk:
    fprintf(*tofile, "ldblk");
    break;

  case cpblk:
    fprintf(*tofile, "cpblk");
    break;

  case ldcon:
    fprintf(*tofile, "ldcon");
    break;

  case ifloat:
    fprintf(*tofile, "float");
    break;

  case readip:
    fprintf(*tofile, "rdinp");
    break;

  case wrstr:
    fprintf(*tofile, "wrstr");
    break;

  case wrval:
    fprintf(*tofile, "wrval");
    break;

  case wrbas:
    fprintf(*tofile, "wrbas");
    break;

  case stop:
    fprintf(*tofile, "stopx");
    break;

  case retproc:
    fprintf(*tofile, "rproc");
    break;

  case retfun:
    fprintf(*tofile, "rfunc");
    break;

  case repadr:
    fprintf(*tofile, "rpadr");
    break;

  case notop:
    fprintf(*tofile, "notop");
    break;

  case negate:
    fprintf(*tofile, "negat");
    break;

  case store:
    fprintf(*tofile, "store");
    break;

  case relequ:
    fprintf(*tofile, "releq");
    break;

  case relneq:
    fprintf(*tofile, "relne");
    break;

  case rellt:
    fprintf(*tofile, "rellt");
    break;

  case relle:
    fprintf(*tofile, "relle");
    break;

  case relgt:
    fprintf(*tofile, "relgt");
    break;

  case relge:
    fprintf(*tofile, "relge");
    break;

  case orop:
    fprintf(*tofile, "iorop");
    break;

  case add:
    fprintf(*tofile, "addop");
    break;

  case sub:
    fprintf(*tofile, "subop");
    break;

  case andop:
    fprintf(*tofile, "andop");
    break;

  case mul:
    fprintf(*tofile, "mulop");
    break;

  case divop:
    fprintf(*tofile, "divop");
    break;

  case modop:
    fprintf(*tofile, "modop");
    break;

  case rdlin:
    fprintf(*tofile, "rdlin");
    break;

  case wrlin:
    fprintf(*tofile, "wrlin");
    break;

  case selec0:
    fprintf(*tofile, "sel0 ");
    break;

  case chanwr:
    fprintf(*tofile, "chnwr");
    break;

  case chanrd:
    fprintf(*tofile, "chnrd");
    break;

  case delay:
    fprintf(*tofile, "delay");
    break;

  case resum:
    fprintf(*tofile, "resum");
    break;

  case enmon:
    fprintf(*tofile, "enmon");
    break;

  case exmon:
    fprintf(*tofile, "exmon");
    break;

  case mexec:
    fprintf(*tofile, "mexec");
    break;

  case mretn:
    fprintf(*tofile, "mretn");
    break;

  case lobnd:
    fprintf(*tofile, "lobnd");
    break;

  case hibnd:
    fprintf(*tofile, "hibnd");
    break;

  case pref:
    fprintf(*tofile, "prefr");
    break;

  case sleap:
    fprintf(*tofile, "sleep");
    break;

  case procv:
    fprintf(*tofile, "procv");
    break;

  case ecall:
    fprintf(*tofile, "ecall");
    break;

  case acpt1:
    fprintf(*tofile, "acpt1");
    break;

  case acpt2:
    fprintf(*tofile, "acpt2");
    break;

  case rep1c:
    fprintf(*tofile, "rep1c");
    break;

  case rep2c:
    fprintf(*tofile, "rep2c");
    break;

  case btest:
    fprintf(*tofile, "btest");
    break;

  case enmap:
    fprintf(*tofile, "enmap");
    break;

  case wrfrm:
    fprintf(*tofile, "wrfrm");
    break;

  case w2frm:
    fprintf(*tofile, "w2frm");
    break;

  case wrsfm:
    fprintf(*tofile, "wrsfm");
    break;

  case power2:
    fprintf(*tofile, "powr2");
    break;

  case slabl:
    fprintf(*tofile, "slabl");
    break;

  case blokk:
    fprintf(*tofile, "block");
    break;

  case param:
    fprintf(*tofile, "param");
    break;

  case case1:
    fprintf(*tofile, "case1");
    break;

  case case2:
    fprintf(*tofile, "case2");
    break;

  case selec1:
    fprintf(*tofile, "sel1 ");
    break;

  case sinit:
    fprintf(*tofile, "sinit");
    break;

  case prtex:
    fprintf(*tofile, "prxit");
    break;

  case prtjmp:
    fprintf(*tofile, "prjmp");
    break;

  case prtsel:
    fprintf(*tofile, "prsel");
    break;

  case prtslp:
    fprintf(*tofile, "prslp");
    break;

  case prtcnd:
    fprintf(*tofile, "prcnd");
    break;
  }/* case */
}  /* putop */


Static Void writetype(anytype)
types anytype;
{
  switch (anytype) {

  case notyp:
    fprintf(listfile, "notyp       ");
    break;

  case bitsets:
    fprintf(listfile, "bitset      ");
    break;

  case ints:
    fprintf(listfile, "integer     ");
    break;

  case reals:
    fprintf(listfile, "real        ");
    break;

  case bools:
    fprintf(listfile, "boolean     ");
    break;

  case chars:
    fprintf(listfile, "char        ");
    break;

  case arrays:
    fprintf(listfile, "array       ");
    break;

  case records:
    fprintf(listfile, "record      ");
    break;

  case semafors:
    fprintf(listfile, "semaphore   ");
    break;

  case channels:
    fprintf(listfile, "channel     ");
    break;

  case monvars:
    fprintf(listfile, "monvar      ");
    break;

  case protvars:
    fprintf(listfile, "resource    ");
    break;

  case protq:
    fprintf(listfile, "protq       ");
    break;

  case condvars:
    fprintf(listfile, "condition   ");
    break;

  case synchros:
    fprintf(listfile, "synch       ");
    break;

  case adrs:
    fprintf(listfile, "address     ");
    break;

  case procs:
    fprintf(listfile, "process     ");
    break;

  case entrys:
    fprintf(listfile, "entry       ");
    break;

  case enums:
    fprintf(listfile, "enum type   ");

    break;
  }/* case */
}  /* writetype */



Static Void writeobj(anyobj)
object anyobj;
{
  switch (anyobj) {

  case konstant:
    fprintf(listfile, "constant    ");
    break;

  case variable:
    fprintf(listfile, "variable    ");
    break;

  case type1:
    fprintf(listfile, "type id     ");
    break;

  case prozedure:
    fprintf(listfile, "procedure   ");
    break;

  case funktion:
    fprintf(listfile, "function    ");
    break;

  case monproc:
    fprintf(listfile, "monproc     ");
    break;

  case address:
    fprintf(listfile, "address     ");
    break;

  case grdproc:
    fprintf(listfile, "grdproc     ");
    break;

  case xgrdproc:
    fprintf(listfile, "xgrdproc    ");
    break;
  }/* case */
}  /* writeobj */


/* Local variables for puttab: */
struct LOC_puttab {
  long index;
} ;








Local Void putfulltab(LINK)
struct LOC_puttab *LINK;
{

  /* output full symbol table */
  tabrec *WITH;

  LINK->index = useridstart;
  fprintf(listfile, "\n\nSymbol table\n\n");
  fprintf(listfile,
    "    name       link      object       type         ref      nrm  lev  adr  aux\n\n");
  while (LINK->index <= t) {
    fprintf(listfile, "%3ld ", LINK->index);
    WITH = &tab[LINK->index];   /* with */
    fprintf(listfile, "%.*s", alng, WITH->name);
    fprintf(listfile, "%5ld     ", WITH->link);
    writeobj((object)WITH->obj);
    writetype((types)WITH->typ);
    fprintf(listfile, "%5ld     ", WITH->ref);
    fprintf(listfile, "%5s", WITH->normal ? "TRUE" : "FALSE");
    fprintf(listfile, "%5d", WITH->lev);
    fprintf(listfile, "%5ld%5ld\n", WITH->taddr, WITH->auxref);
    LINK->index++;
  }
}  /* putfull tab */





Local Void putcode(LINK)
struct LOC_puttab *LINK;
{

  /* output pcode to listfile */
  short local, FORLIM;
  order *WITH;

  fprintf(listfile, "\nGenerated P-code\n\n");
  FORLIM = lc;
  for (local = 0; local < FORLIM; local++) {
    WITH = &code[local];
    fprintf(listfile, "%5d     ", local);
    putop((opcode)WITH->f, &listfile);
    putsuff((types)WITH->instyp);
    fprintf(listfile, "%5d%10ld          ;%ld\n",
	    SEXT(WITH->x, 4), WITH->y, WITH->line);
  }
}  /* putcode */



Static Void puttab()
{

  /* send symbol table to listfile */
  struct LOC_puttab V;


  V.index = 1;
  putfulltab(&V);
  putcode(&V);
}  /* puttaB */


#define ni              " not implemented"


/* implementation-checking procedure */


/* @(#)impcheck.i4.1 10/24/89 */

Static Void impcheck(success)
boolean *success;
{

  /* check generated code ofr use of features not in the
     implementation */
  long index, FORLIM;
  tabrec *WITH;


  putc('\n', listfile);
  FORLIM = t;
  for (index = useridstart; index <= FORLIM; index++) {
    WITH = &tab[index];
    if ((object)WITH->obj == address) {
      if (!impmapping) {
	fprintf(listfile, "e - %.*s address mapping%s\n",
		alng, WITH->name, ni);
	*success = false;
      }
    } else {
      if ((types)WITH->typ == reals) {
	if (!impreals) {
	  fprintf(listfile, "e - %.*s reals%s\n", alng, WITH->name, ni);
	  *success = false;
	}
      }
    }
  }
  if (r != 0) {
    if (!impreals)
      fprintf(listfile, "e - real literals used in program\n");
  }
}  /* impchecK */

#undef ni


/* Local variables for putcode_: */
struct LOC_putcode_ {
  long cindex;
} ;




Local Void gen(fobj, xobj, yobj, LINK)
long fobj, xobj, yobj;
struct LOC_putcode_ *LINK;
{
  objcoderec *WITH;
  objorder *WITH1;

  WITH = &GETBINFILEBUF(objfile, objcoderec);
  WITH1 = &WITH->gencode[LINK->cindex];
/* p2c: pfccomp.pas, line 5777:
 * Note: Discovered too late that objfile should be buffered [143] */
  WITH1->f = fobj;
  WITH1->x = xobj;
  WITH1->y = yobj;
  WITH1->l = code[LINK->cindex].line;
}  /* gen */

Local Void putcode_()
{

  /* outputs the objectcode array */
  struct LOC_putcode_ V;
  long FORLIM;
  order *WITH;





  FORLIM = lc;
  for (V.cindex = 0; V.cindex < FORLIM; V.cindex++) {   /* case */
    WITH = &code[V.cindex];
    switch ((opcode)WITH->f) {

    case ldadr:
      gen(0L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case ldval:
      gen(1L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case ldind:
      gen(2L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case updis:
      gen(3L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case cobeg:
      gen(4L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case coend:
      gen(5L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case wait:
      gen(6L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case asignal:
      gen(7L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case stfun:
      gen(8L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case ixrec:
      gen(9L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case jmp:
      gen(10L, 0L, WITH->y, &V);
      break;

    case jmpiz:
      gen(11L, 0L, WITH->y, &V);
      break;

    case case1:
      gen(12L, 0L, WITH->y, &V);
      break;

    case case2:
      gen(13L, 0L, 0L, &V);
      break;

    case for1up:
      gen(14L, 0L, WITH->y, &V);
      break;

    case for2up:
      gen(15L, 0L, WITH->y, &V);
      break;

    case mrkstk:
      gen(18L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case callsub:
      gen(19L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case ixary:
      gen(21L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case ldblk:
      gen(22L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case cpblk:
      gen(23L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case ldcon:
      if ((types)WITH->instyp == reals)
	gen(25L, 0L, WITH->y, &V);
      else
	gen(24L, 0L, WITH->y, &V);
      break;

    case ifloat:
      gen(26L, 0L, WITH->y, &V);
      break;

    case readip:
      switch ((types)WITH->instyp) {

      case notyp:
      case ints:
	gen(27L, 0L, 1L, &V);
	break;

      case reals:
	gen(27L, 0L, 4L, &V);
	break;

      case chars:
	gen(27L, 0L, 3L, &V);
	break;
      }
      break;

    case wrstr:
      gen(28L, 0L, WITH->y, &V);
      break;

    case wrsfm:
      gen(28L, 1L, WITH->y, &V);
      break;

    case wrval:
      switch ((types)WITH->instyp) {

      case notyp:
      case ints:
      case semafors:
	gen(29L, 0L, 1L, &V);
	break;

      case bools:
	gen(29L, 0L, 2L, &V);
	break;

      case chars:
	gen(29L, 0L, 3L, &V);
	break;

      case reals:
	gen(29L, 0L, 4L, &V);
	break;

      case bitsets:
	gen(29L, 0L, 5L, &V);
	break;
      }
      break;

    case wrfrm:
      switch ((types)WITH->instyp) {

      case notyp:
      case ints:
      case semafors:
	gen(30L, 0L, 1L, &V);
	break;

      case bools:
	gen(30L, 0L, 2L, &V);
	break;

      case chars:
	gen(30L, 0L, 3L, &V);
	break;

      case reals:
	gen(30L, 0L, 4L, &V);
	break;

      case bitsets:
	gen(30L, 0L, 5L, &V);
	break;
      }
      break;

    case w2frm:
      gen(37L, 0L, 0L, &V);
      break;

    case wrbas:
      if ((types)WITH->instyp == ints)
	gen(107L, 0L, 1L, &V);
      else
	gen(107L, 0L, 5L, &V);
      break;

    case stop:
      gen(31L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case retproc:
      gen(32L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case retfun:
      gen(33L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case repadr:
      gen(34L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case notop:
      gen(35L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case negate:
      gen(36L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case store:
      gen(38L, 0L, 0L, &V);
      break;

    case relequ:
      switch ((types)WITH->instyp) {

      case notyp:
      case ints:
      case bools:
      case chars:
      case enums:
	gen(45L, 0L, 0L, &V);
	break;

      case reals:
	gen(39L, 0L, 0L, &V);
	break;

      case bitsets:
	gen(112L, 0L, 0L, &V);
	break;
      }
      break;

    case relneq:
      switch ((types)WITH->instyp) {

      case notyp:
      case ints:
      case bools:
      case chars:
      case enums:
	gen(46L, 0L, 0L, &V);
	break;

      case reals:
	gen(40L, 0L, 0L, &V);
	break;

      case bitsets:
	gen(113L, 0L, 0L, &V);
	break;
      }
      break;

    case rellt:
      switch ((types)WITH->instyp) {

      case notyp:
      case ints:
      case bools:
      case chars:
      case enums:
	gen(47L, 0L, 0L, &V);
	break;

      case reals:
	gen(41L, 0L, 0L, &V);
	break;

      case bitsets:
	gen(114L, 0L, 0L, &V);
	break;
      }
      break;

    case relle:
      switch ((types)WITH->instyp) {

      case notyp:
      case ints:
      case bools:
      case chars:
      case enums:
	gen(48L, 0L, 0L, &V);
	break;

      case reals:
	gen(42L, 0L, 0L, &V);
	break;

      case bitsets:
	gen(115L, 0L, 0L, &V);
	break;
      }
      break;

    case relgt:
      switch ((types)WITH->instyp) {

      case notyp:
      case ints:
      case bools:
      case chars:
      case enums:
	gen(49L, 0L, 0L, &V);
	break;

      case reals:
	gen(43L, 0L, 0L, &V);
	break;

      case bitsets:
	gen(116L, 0L, 0L, &V);
	break;
      }
      break;

    case relge:
      switch ((types)WITH->instyp) {

      case notyp:
      case ints:
      case bools:
      case chars:
      case enums:
	gen(50L, 0L, 0L, &V);
	break;

      case reals:
	gen(44L, 0L, 0L, &V);
	break;

      case bitsets:
	gen(117L, 0L, 0L, &V);
	break;
      }
      break;

    case orop:
      if ((types)WITH->instyp == bools)
	gen(51L, 0L, 0L, &V);
      else
	gen(118L, 0L, 0L, &V);
      break;

    case add:
      if ((types)WITH->instyp == ints)
	gen(52L, 0L, 0L, &V);
      else
	gen(54L, 0L, 0L, &V);
      break;

    case sub:
      if ((types)WITH->instyp == ints)
	gen(53L, 0L, 0L, &V);
      else {
	if ((types)WITH->instyp == reals)
	  gen(55L, 0L, 0L, &V);
	else
	  gen(119L, 0L, 0L, &V);
      }
      break;

    case andop:
      if ((types)WITH->instyp == bools)
	gen(56L, 0L, 0L, &V);
      else
	gen(120L, 0L, 0L, &V);
      break;

    case mul:
      if ((types)WITH->instyp == ints)
	gen(57L, 0L, 0L, &V);
      else
	gen(60L, 0L, 0L, &V);
      break;

    case divop:
      if ((types)WITH->instyp == ints)
	gen(58L, 0L, 0L, &V);
      else
	gen(61L, 0L, 0L, &V);
      break;

    case modop:
      gen(59L, 0L, 0L, &V);
      break;

    case rdlin:
      gen(62L, 0L, 0L, &V);
      break;

    case wrlin:
      gen(63L, 0L, 0L, &V);
      break;

    case selec0:
      gen(64L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case selec1:
      switch (SEXT(WITH->x, 4)) {

      case 0:
	gen(24L, 0L, -1L, &V);
	break;

      case 3:
      case 4:
      case 5:
	gen(24L, 0L, WITH->y, &V);
	break;
      }
      break;

    case chanwr:
      if (((1L << WITH->instyp) & ((1L << ((long)ints)) | (1L << ((long)bools)) |
	     (1L << ((long)chars)) | (1L << ((long)reals)) |
	     (1L << ((long)enums)) | (1L << ((long)bitsets)))) != 0)
	gen(65L, 0L, WITH->y, &V);
      else
	gen(65L, 1L, WITH->y, &V);
      break;

    case chanrd:
      gen(66L, 0L, WITH->y, &V);
      break;

    case delay:
      gen(67L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case resum:
      gen(68L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case enmon:
      gen(69L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case exmon:
      gen(70L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case mexec:
      gen(71L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case mretn:
      gen(72L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case lobnd:
      gen(74L, 0L, WITH->y, &V);
      break;

    case hibnd:
      gen(75L, 0L, WITH->y, &V);
      break;

    case slabl:
    case blokk:
    case param:
      gen(78L, 0L, 0L, &V);
      break;

    case pref:
      gen(96L, 0L, 0L, &V);
      printf("w - priorities not implemented\n");
      break;

    case sleap:
      gen(97L, 0L, 0L, &V);
      break;

    case procv:
      gen(98L, 0L, 0L, &V);
      break;

    case ecall:
      gen(99L, 0L, WITH->y, &V);
      break;

    case acpt1:
      gen(100L, 0L, WITH->y, &V);
      break;

    case acpt2:
      gen(101L, 0L, WITH->y, &V);
      break;

    case rep1c:
      gen(102L, (long)SEXT(WITH->x, 4), WITH->y, &V);
      break;

    case rep2c:
      gen(103L, 0L, WITH->y, &V);
      break;

    case power2:
      gen(104L, 0L, 0L, &V);
      break;

    case btest:
      gen(105L, 0L, 0L, &V);
      break;

    case enmap:
      gen(106L, 0L, WITH->y, &V);
      break;

    case sinit:
      gen(121L, 0L, 0L, &V);
      break;

    case prtjmp:
      gen(129L, 0L, WITH->y, &V);
      break;

    case prtsel:
      gen(130L, 0L, 0L, &V);
      break;

    case prtslp:
      gen(131L, 0L, 0L, &V);
      break;

    case prtex:
      gen(132L, (long)SEXT(WITH->x, 4), 0L, &V);
      break;

    case prtcnd:
      gen(133L, 0L, WITH->y, &V);
      break;
    }
  }
  GETBINFILEBUF(objfile, objcoderec).ngencode = lc - 1;
}  /* putcode */


Local Void puttabs()
{

  /* output tables, etc, to objfile */
  memcpy(GETBINFILEBUF(objfile, objcoderec).fname, filename, sizeof(fnametype));
  memcpy(GETBINFILEBUF(objfile, objcoderec).prgname, progname, sizeof(alfa_));
  memcpy(GETBINFILEBUF(objfile, objcoderec).gentab, tab, sizeof(tabarray));
  GETBINFILEBUF(objfile, objcoderec).ngentab = t;
  memcpy(GETBINFILEBUF(objfile, objcoderec).genatab, atab, sizeof(atabarray));
  GETBINFILEBUF(objfile, objcoderec).ngenatab = a;
  memcpy(GETBINFILEBUF(objfile, objcoderec).genbtab, btab, sizeof(btabarray));
  GETBINFILEBUF(objfile, objcoderec).ngenbtab = b;
  memcpy(GETBINFILEBUF(objfile, objcoderec).genstab, stab, sizeof(stabarray));
  memcpy(GETBINFILEBUF(objfile, objcoderec).genrconst, rconst, sizeof(realarray));
  GETBINFILEBUF(objfile, objcoderec).ngenstab = sx;
  GETBINFILEBUF(objfile, objcoderec).useridstart = useridstart;
}  /* puttabs */


/* intermediate code translator procedure */

Static Void ict(success)
boolean *success;
{


  /* Pascal-FC intermediate code translator for Unix systems */
  /* implementation checks to go here */
  if (!*success)
    return;
  if (objfile->file != NULL)
    objfile->file = freopen("objfile", "wb", objfile->file);
  else
    objfile->file = fopen("objfile", "wb");
  if (objfile->file == NULL)
    _EscIO(FileNotFound);
  SETUPBINFILEBUF(objfile, objcoderec);
  putcode_();
  puttabs();
  PUTBINFILE(objfile, objcoderec);
}  /* ict */




Static Void errorbanner()
{
  printf("*********************************\n");
  printf("Compilation errors - see listfile\n");
  printf("*********************************\n");
}



main(argc, argv)
int argc;
Char *argv[];
{
  PASCAL_MAIN(argc, argv);
  if (argc == 2)
	progfilename = argv[1];
  else {
	fprintf(stderr, "usage: %s progfilename\n", argv[0]);
	exit(1);
  }
  objfile->file = NULL;
  listfile = NULL;
  progfile = NULL;
  pfcfront(&success);
  impcheck(&success);
  if (success)
    ict(&success);
  puttab();
  if (!success)
    errorbanner();
  if (progfile != NULL)
    fclose(progfile);
  if (listfile != NULL)
    fclose(listfile);
  if (objfile != NULL)
    fclose(objfile->file);
  exit(EXIT_SUCCESS);
}




/* End. */
