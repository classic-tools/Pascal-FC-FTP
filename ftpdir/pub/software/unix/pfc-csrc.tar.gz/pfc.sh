#!/bin/sh

: set the shell variable p to the directory
p=
if test -f objfile
	then rm objfile
fi

case $# in
	1)	
		if test -f $1 
			then 
				$p/Linuxpfcunix $1
			else echo pfc: file $1 not found
		fi
		if test -f objfile
			then $p/Linuxintunix
		fi ;;
	2)	case $1 in
			-uf)	
					if test -f $2 
						then 
						$p/Linuxpfcunix $2
					else 
						echo pfc: file $2 not found
					fi
					if test -f objfile
						then 
									$p/Linuxufintunix
					fi;;
			*)
					echo $1:  flag unkown

		esac ;;
	*)	echo Usage: pfc [implementation] file
esac
