

                          Pascal-FC for Windows 2000


          The software and documentation are supplied subject  to  the
          following conditions:

          1.   The software and documentation are supplied without any
               form  of  warranty  whatsoever,  and the authors cannot
               accept any liability arising from  its  use  under  any
               circumstances.

          2.   The software has been compiled using compilers obtained
               under  an Educational Licence.  It must only be used in
               educational  institutions,  and  must  under  no   cir-
               cumstances be used for financial gain.

          3.   The software and documentation may be freely copied.

          4.   We ask that you cite our work in any publications aris-
               ing out of the use of Pascal-FC.
                                 Directory Structure

          This release of the Pascal-FC system includes a  SETUP  pro-
          gram  that  is designed to transfer files from the distribu-
          tion floppy to a hard  disc  (see  Chapter  1  of  the  User
          Guide). If you have obtained the distribution by FTP or from
          the World-Wide Web, don't run SETUP but simply create a dir-
          ectory C;\PASFC and unzip the distribution zip file there. A
          directory  structure  is set up  which, by default,  has its
          root at C;\PASFC. The following diagram illustrates the str-
          ucture.



                                     PASFC
                                       |
                                       |
                           ___________________________
                           |           |             |
                           |           |             |
                          BIN         DOC           EX
                                                     |
                                                     |
                                     ________________________________
                                     |     |    |    |    |    |    |
                                    MUTEX SEMS MONS RES CHANS ADA PHILOS



          The directory "bin" contains the executable versions of  the
          compiler  and  interpreters,  together with the improved pfc
	  command.   					  --------
	 

          The pfc command is a shell script, and the  paths  p  and  q
          should be edited by the installer as appropriate.

               The directory "ex"  has  a  number  of  subdirectories:
          each  one  of  these contains a number of ".pfc" files which
          are Pascal-FC source programs.

               The directory "doc" contains two  documents:   "lrm.ps"
          is the Language Reference Manual, and "sun_ug.ps is the User
          Guide for Sun Systems.  Both are in Postscript  format,  and
          have their tables of contents printed at the end.

               The  distribution  has an  additional  subdirectory  to 
	  PASFC:   SRC.   This contains the Pascal source code for the
          compiler and interpreters.

	  
	  PROBLEM:    
	  --------

	       A common problem reported for Windows 2000 platforms is
	  a  run-time  error when trying to run the interpreter (pint):

		*						*
	  		run-time error R6009
			-not enough space for environment
		*						*


	  SOLUTION:
	  ---------

	       The interpreter during its operation creates environment
	  variables   thus  leading  to  an  overflow  and  not  enough
	  environment  space.  To  work-around   this   problem   start 
	  'nulling'   environment   variables   and  then  invoke   the 
	  interpreter  until  you  get  a  prompt  for  an  OBJFILE and 
   	  PMDFILE. To do that under Windows 2000:


		1. Type  set  [ENTER]  on  the command prompt to
		   get a  list  of  all  environment  variables.

		2. To  'null'  a  variable  type  set var_name=;
		   or set var_name=

		3. Type  pint  to  check  for a  run-time error.

		4. Repeat  the  steps  above  until  you  get  a
		   prompt   for   an    OBJFILE   and   PMDFILE.

	       Optionally,  after  you  successfully  perform the steps 
	  above you can  save  your  environment variable  setting in a
	  batch file and execute it before trying to invoke the
	  interpreter.

	       If  you   encounter  any  problems follow the analytical
	  steps   described  in   the  Win2000SetUp  file  in  the  pfc 
	  directory.









