/* Output from p2c, the Pascal-to-C translator */
/* From input file "ufpint.pas" */


/* @(#)pint.p5.3 12/3/92 */



#include <p2c/p2c.h>
/* p2c: ufpint.pas, line 4: 
 * Note: Unexpected name "objfile" in program header [262] */
/* p2c: ufpint.pas, line 4: 
 * Note: Unexpected name "pmdfile" in program header [262] */

/* Hack for non-char I/O. */
#define GETBINFILEBUF(f,type)    (*(((f)->__CAT__(f,_BFLAGS) == 1 &&   \
 			       (((f)->__CAT__(f,_BFLAGS) = 2),   \
 				fread(&((f)->__CAT__(f,_BUFFER)),  \
 				      sizeof(type),1,(f)->file))),\
 			      &((f)->__CAT__(f,_BUFFER))))
#define SETUPBINFILEBUF(f,type)   ((f)->__CAT__(f,_BFLAGS) = 0)
#define RESETBINFILEBUF(f,type)   ((f)->__CAT__(f,_BFLAGS) = 1)
#define BUFBINFILEEOF(f)	   ((f)->__CAT__(f,_BFLAGS) != 2 && P_eof((f)->file))


/* Pascal-FC interpreter */




/* implementation-independent constants */
/* @(#)globcons.i4.1 10/24/89 */

#define alng            10   /* length of identifiers */

#define xmax            LONG_MAX

#define omax            200   /* largest op-code for p-machine */
#define funmax          omax   /* highest function number */


/* implementation-dependent constants */
/* impcons.i */
/* BM 1 version */


#define target          "UNIX"

#define maxmons         10   /* maximum monitor in a program */
#define maxcapsprocs    10   /* maximum exported procedures from a monitor */
#define intermax        10   /* max no. of mapped ipc primitives */
#define tmax            150   /* max size of symbol table */
#define bmax            50   /* max size of block table */
#define amax            20   /* max size of array table */
#define casemax         20   /* max number of case labels or selects */
#define chanmax         20   /* maximum size of channel table - gld */
#define cmax            2000   /* max size of p-code array */
#define lmax            7   /* max depth of block nesting */
#define smax            1500   /* max size of string table */
#define rmax            50   /* real constant table limit */
#define etmax           20   /* enumeration type upper bounds table */

#define llng            121   /* max source input line length */
#define tabstop         3   /* for 1 implementation - gld */
#define tabchar         9

#define fals            0
#define tru             1
#define charl           0   /* first legal ascii character */
#define charh           127   /* last legal ascii character */

#define intmax          32767   /* maximum integer on target */
#define intmsb          16   /* most sig. bit in target integer */

#define realmax         1e38
/* maximum real number on target
                                                                           or host, whichever is smaller */
#define minreal         1e-37   /* smallest real (for division) */

#define emax            38   /* maximum real exponent on target */
#define emin            (-emax)

#define bsmsb           7   /* most sig. bit in target bitset */

#define impfiles        false
#define impmapping      false
#define imptiming       false
#define impreals        true

#define monvarsize      2
#define protvarsize     3
#define chansize        3
#define entrysize       3   /* space for a process entry point */
#define sfsize          6   /* size of "frame" in a select statement */


#define bitsetsize      1
#define intsize         1
#define boolsize        1
#define charsize        1
#define semasize        1
#define condvarsize     1
#define synchrosize     0
#define procsize        1
#define enumsize        1
#define realsize        1


#define objalign        1

#define pushdown        false

/* interpreter-specific constants */

#define stepmax         8

/* NOTE - make (stmax - (stkincr * pmax)) >= stkincr */

#define stmax           5000
#define stkincr         200
#define pmax            20
#define msb             7


#define actrecsize      5   /* size of subprogram "housekeeping" block */






/* @(#)globtypes.i4.7 11/8/91 */


typedef enum {
  ldadr, ldval, ldind, updis, cobeg, coend, wait, asignal, stfun, ixrec, jmp,
  jmpiz, for1up, for2up, mrkstk, callsub, ixary, ldblk, cpblk, ldcon, ifloat,
  readip, wrstr, wrval, stop, retproc, retfun, repadr, notop, negate, store,
  relequ, relneq, rellt, relle, relgt, relge, orop, add, sub, andop, mul,
  divop, modop, rdlin, wrlin, selec0, chanwr, chanrd, delay, resum, enmon,
  exmon, mexec, mretn, lobnd, hibnd, pref, sleap, procv, ecall, acpt1, acpt2,
  rep1c, rep2c, btest, enmap, wrfrm, w2frm, wrsfm, wrbas, power2, slabl,
  blokk, param, case1, case2, selec1, sinit, prtex, prtjmp, prtsel, prtslp,
  prtcnd
} opcode;
/* p2c: ufpint.pas, line 123:
 * Note: Line breaker spent 0.0 seconds, 5000 tries on line 136 [251] */

typedef long index_;

typedef Char alfa_[alng];
typedef enum {
  konstant, variable, type1, prozedure, funktion, monproc, address, grdproc,
  xgrdproc
} object;



typedef enum {
  notyp, ints, reals, bools, chars, arrays, records, semafors, channels,
  monvars, condvars, synchros, adrs, procs, entrys, enums, bitsets, protvars,
  protq
} types;

typedef long typset;


typedef Char fnametype[30];

typedef struct order {
  unsigned f : 7;
/* p2c: ufpint.pas, line 143:
 * Note: Field width for F assumes enum opcode has 84 elements [105] */
  Signed int x : 4;
  long y;
  unsigned instyp : 5;
/* p2c: ufpint.pas, line 146:
 * Note: Field width for INSTYP assumes enum types has 19 elements [105] */
  long line;
} order;

typedef order orderarray[cmax + 1];

typedef struct objorder {
  uchar f;
  Signed int x : 4;
  long y, l;
} objorder;

typedef objorder objorderarray[cmax + 1];

typedef struct tabrec {
  alfa_ name;
  index_ link;
  unsigned obj : 4;
/* p2c: ufpint.pas, line 164:
 * Note: Field width for OBJ assumes enum object has 9 elements [105] */
  unsigned typ : 5;
/* p2c: ufpint.pas, line 165:
 * Note: Field width for TYP assumes enum types has 19 elements [105] */
  index_ ref;
  unsigned normal : 1, lev : 3;
  long taddr;
  index_ auxref;
} tabrec;

typedef tabrec tabarray[tmax + 1];

typedef struct atabrec {
  unsigned inxtyp : 5, eltyp : 5;
/* p2c: ufpint.pas, line 176:
 * Note: Field width for INXTYP assumes enum types has 19 elements [105] */
  index_ inxref, elref, low, high, elsize, size;
} atabrec;

typedef atabrec atabarray[amax];

typedef struct btabrec {
  index_ last, lastpar, psize, vsize;
  uchar tabptr;
} btabrec;

typedef btabrec btabarray[bmax];

typedef Char stabarray[smax + 1];
typedef double realarray[rmax];

typedef struct intabrec {
  unsigned tp : 5;
/* p2c: ufpint.pas, line 193:
 * Note: Field width for TP assumes enum types has 19 elements [105] */
  unsigned lv : 3;
  long rf, vector, off, tabref;
} intabrec;

typedef intabrec intabarray[intermax];


/* unixtypes.i */

/* Pascal-FC "universal" compiler system */
/* implementation-dependent type declaration for Unix */


typedef struct objcoderec {
  fnametype fname;
  alfa_ prgname;
  objorderarray gencode;
  unsigned ngencode : 11;

  tabarray gentab;
  uchar ngentab;

  atabarray genatab;
  unsigned ngenatab : 5;

  btabarray genbtab;
  unsigned ngenbtab : 6;

  stabarray genstab;
  unsigned ngenstab : 11;
  realarray genrconst;

  uchar useridstart;


} objcoderec;


typedef char ptype;

typedef long powerset;


typedef struct qnode {
  ptype proc;
  struct qnode *next;
} qnode;

typedef struct stackrec {
  types tp;
  union {
    long i;
    powerset bs;
    double r;
  } UU;
} stackrec;











typedef struct _REC_ptab {
  long t, b, pc, stackbase, stacksize;
  long display[lmax];
  long suspend, chans, repindex;
  boolean onselect, active, termstate;
  long curmon, wakeup, wakestart;
  boolean clearresource;


  uchar varptr;
} _REC_ptab;

typedef struct _REC_proclist {
  ptype proc, link;
} _REC_proclist;

typedef struct {
    FILE *file;
    int objfile_BFLAGS ;   			   objcoderec objfile_BUFFER  ;
    char  name[120 ];
} _OBJFILE;

Static _OBJFILE xobjfile, *objfile = &xobjfile;

Static FILE *pmdfile;
Static typset stantyps;
Static Char ch;

Static double seedx;
Static objorder ir;
Static enum {
  run, fin, divchk, inxchk, charchk, stkchk, redchk, deadlock, channerror,
  guardchk, queuechk, procnchk, statchk, nexistchk, namechk, casechk, bndchk,
  instchk, inpchk, setchk, ovchk, seminitchk
} ps;

Static long lncnt, chrcnt, h1, h2, h3, h4;
Static boolean foundcall;   /* used in select (code 64) */

Static stackrec s[stmax];
Static _REC_ptab ptab[pmax + 1];
Static ptype npr, procmax, curpr;
Static long stepcount;
Static boolean concflag;
Static long statcounter;
Static long sysclock;

Static long now, last;

Static long statmax = 200000L;   /* maximum statements before "livelock */


Static struct {
  _REC_proclist proclist[pmax];
  char free;
} procqueue;

Static struct {
  qnode *first;
  long time;
} eventqueue;






Static boolean itob(i)
long i;
{
  if (i == tru)
    return true;
  else
    return false;
}


Static long btoi(b)
boolean b;
{
  if (b)
    return tru;
  else
    return fals;
}


Static Void printname(name, tofile)
Char *name;
FILE **tofile;
{
  long index;
  boolean endfound;

  index = 1;
  endfound = (name[index - 1] == ' ');
  while (!endfound) {
    putc(name[index - 1], *tofile);
    index++;
    if (index <= alng)
      endfound = (name[index - 1] == ' ');
    else
      endfound = true;
  }
}  /* printname */


/* Local variables for nameobj: */
struct LOC_nameobj {
  long target_;
  types *tp;
  FILE **tofile;
  long offset;
  index_ rf;
} ;

/* Local variables for unselector: */
struct LOC_unselector {
  struct LOC_nameobj *LINK;
} ;

Local Void arraysub(rf, tp, LINK)
index_ *rf;
types *tp;
struct LOC_unselector *LINK;
{
  long sub_;
  atabrec *WITH;

  putc('[', *LINK->LINK->tofile);
  WITH = &GETBINFILEBUF(objfile, objcoderec).genatab[*rf - 1];
/* p2c: ufpint.pas, line 386:
 * Note: Discovered too late that objfile should be buffered [143] */
  sub_ = LINK->LINK->offset / WITH->elsize + WITH->low;
  LINK->LINK->offset %= WITH->elsize;
/* p2c: ufpint.pas, line 389:
 * Note: Using % for possibly-negative arguments [317] */
  switch ((types)WITH->inxtyp) {

  case ints:
  case enums:
    fprintf(*LINK->LINK->tofile, "%ld", sub_);
    break;

  case chars:
    fprintf(*LINK->LINK->tofile, "'%c'", (Char)sub_);
    break;

  case bools:
    fputs(itob(sub_) ? " TRUE" : "FALSE", *LINK->LINK->tofile);
    break;
  }
  putc(']', *LINK->LINK->tofile);
  *tp = (types)WITH->eltyp;
  *rf = WITH->elref;
}  /* arraysub */


Local Void recfield(rf, tp, LINK)
index_ *rf;
types *tp;
struct LOC_unselector *LINK;
{
  long tptr;
  objcoderec *WITH;


  putc('.', *LINK->LINK->tofile);
  WITH = &GETBINFILEBUF(objfile, objcoderec);
  tptr = WITH->genbtab[*rf - 1].last;
  while (WITH->gentab[tptr].taddr > LINK->LINK->offset)
    tptr = WITH->gentab[tptr].link;
  printname(WITH->gentab[tptr].name, LINK->LINK->tofile);
  *rf = WITH->gentab[tptr].ref;
  *tp = (types)WITH->gentab[tptr].typ;
  LINK->LINK->offset -= WITH->gentab[tptr].taddr;   /* with */
}  /* recfield */




Local Void unselector(rf, tp, LINK)
index_ *rf;
types *tp;
struct LOC_nameobj *LINK;
{

  /* output array subscripts or record fields */
  struct LOC_unselector V;




  V.LINK = LINK;
  do {
    if (*tp == arrays)
      arraysub(rf, tp, &V);
    else
      recfield(rf, tp, &V);
  } while (((1L << ((long)(*tp))) &
	    ((1L << ((long)arrays)) | (1L << ((long)records)))) != 0);
      /* unselector */
}


Local Void followlinks(target_, tptr, offset, LINK)
long target_, *tptr, *offset;
struct LOC_nameobj *LINK;
{
  long dx;
  objcoderec *WITH;

  WITH = &GETBINFILEBUF(objfile, objcoderec);   /* with */
  while ((object)WITH->gentab[*tptr].obj != variable)
    *tptr = WITH->gentab[*tptr].link;
  dx = WITH->gentab[*tptr].taddr;
  while (dx > target_) {
    *tptr = WITH->gentab[*tptr].link;
    if ((object)WITH->gentab[*tptr].obj == variable)
      dx = WITH->gentab[*tptr].taddr;
  }  /* while */
  *offset = target_ - dx;
}  /* followlkins */

Local Void monitortyp(target_, tptr, offset, LINK)
long target_, *tptr, *offset;
struct LOC_nameobj *LINK;
{

  /* name monitor boundary queue, h-p queue
            or any variable declared in a monitor */
  objcoderec *WITH;

  WITH = &GETBINFILEBUF(objfile, objcoderec);
  printname(WITH->gentab[*tptr].name, LINK->tofile);
  if (*offset == 0) {   /* with */
    if ((types)WITH->gentab[*tptr].typ == monvars)
      fprintf(*LINK->tofile, " (monitor boundary queue)");
    else
      fprintf(*LINK->tofile, " (resource boundary queue)");
    return;
  }
  if (*offset == 1) {  /* h-p queue */
    printname(WITH->gentab[*tptr].name, LINK->tofile);
    fprintf(*LINK->tofile, " (monitor high-priority queue)");
    return;
  }
  putc('.', *LINK->tofile);
  *tptr = WITH->genbtab[WITH->gentab[*tptr].ref - 1].last;
  followlinks(target_, tptr, offset, LINK);
  if ((types)WITH->gentab[*tptr].typ == protq)
    printname(WITH->gentab[*tptr - 1].name, LINK->tofile);
  else
    printname(WITH->gentab[*tptr].name, LINK->tofile);
  LINK->rf = WITH->gentab[*tptr].ref;
  *LINK->tp = (types)WITH->gentab[*tptr].typ;

  /* declared variable */
}  /* monitortyp */

Local Void entryname(bref, LINK)
long bref;
struct LOC_nameobj *LINK;
{
  long tptr;
  objcoderec *WITH;


  putc('.', *LINK->tofile);
  LINK->target_ = (LINK->target_ - ptab[1].stackbase) % stkincr;
  WITH = &GETBINFILEBUF(objfile, objcoderec);
/* p2c: ufpint.pas, line 501:
 * Note: Using % for possibly-negative arguments [317] */
  tptr = WITH->genbtab[bref - 1].last;
  followlinks(LINK->target_, &tptr, &LINK->offset, LINK);
  printname(WITH->gentab[tptr].name, LINK->tofile);   /* with */
}  /* entryname */


Static Void nameobj(target__, tp_, tofile_)
long target__;
types *tp_;
FILE **tofile_;
{
  struct LOC_nameobj V;
  long tptr, procptr, prtarget;
  objcoderec *WITH;



  V.target_ = target__;
  V.tp = tp_;
  V.tofile = tofile_;
  if (V.target_ > ptab[0].stacksize) {
    procptr = (V.target_ - ptab[1].b) / stkincr + 1;
    prtarget = ptab[procptr].varptr;
  } else
    prtarget = V.target_;
  WITH = &GETBINFILEBUF(objfile, objcoderec);   /* with */
  tptr = WITH->genbtab[1].last;
  followlinks(prtarget, &tptr, &V.offset, &V);
  V.rf = WITH->gentab[tptr].ref;
  *V.tp = (types)WITH->gentab[tptr].typ;
  if (((1L << ((long)(*V.tp))) &
       ((1L << ((long)monvars)) | (1L << ((long)protvars)))) != 0)
    monitortyp(V.target_, &tptr, &V.offset, &V);
  else
    printname(WITH->gentab[tptr].name, V.tofile);
  if (((1L << ((long)(*V.tp))) &
       ((1L << ((long)arrays)) | (1L << ((long)records)))) != 0)
    unselector(&V.rf, V.tp, &V);
  if (V.target_ > ptab[0].stacksize) {
    entryname(V.rf, &V);
    *V.tp = entrys;
  }
}  /* nameobJ */



Static double xrandom(x)
double x;
{
  return ((double)rand() / (double)RAND_MAX);
}

Static long seed(x)
long x;
{
  long Result;

  Result = 0;
  srand((unsigned int)x);
  return Result;
}


Static long wallclock()
{
  return ((long)time(0L));
}






Static Void getcode()
{

  /* get code from objfile */
  if (objfile->file != NULL)
    objfile->file = freopen("objfile", "rb", objfile->file);
  else
    objfile->file = fopen("objfile", "rb");
  if (objfile->file == NULL)
    _EscIO(FileNotFound);
  RESETBINFILEBUF(objfile, objcoderec);

}  /* getcode */


Static Void putversion(tofile)
FILE **tofile;
{
  fprintf(*tofile, "- Interpreter Version P5.3");

  fprintf(*tofile, "uf");


  fprintf(*tofile, " - ");

}  /* putversion */









Static Void headermsg(tp, tofile)
types tp;
FILE **tofile;
{
  _REC_ptab *WITH;

  WITH = &ptab[curpr];
  fprintf(*tofile, "Abnormal halt ");
  if (WITH->active) {
    if (curpr == 0)
      fprintf(*tofile, "in main program ");
    else {
      fprintf(*tofile, "in process ");
      nameobj((long)WITH->varptr, &tp, tofile);
    }
    fprintf(*tofile, " with pc = %ld\n", WITH->pc);
  } else {
    fprintf(*tofile, "on termination of process ");
    nameobj((long)WITH->varptr, &tp, tofile);
    putc('\n', *tofile);
  }
  fprintf(*tofile, "Reason:   ");

  switch (ps) {

  case deadlock:
    fprintf(*tofile, "deadlock\n");
    break;

  case divchk:
    fprintf(*tofile, "division by 0\n");
    break;

  case inxchk:
    fprintf(*tofile, "invalid index \n");
    break;

  case charchk:
    fprintf(*tofile, "illegal or uninitialised character\n");
    break;

  case stkchk:
    fprintf(*tofile, "storage overflow\n");
    break;

  case redchk:
    fprintf(*tofile, "reading past end of file\n");
    break;

  case channerror:
    fprintf(*tofile, "channel error\n");
    break;

  case guardchk:
    fprintf(*tofile, "closed guards\n");
    break;

  case procnchk:
    fprintf(*tofile, "more than %ld processes\n", (long)pmax);
    break;

  case statchk:
    fprintf(*tofile, "statement limit of %ld reached (possible livelock)\n",
	    statmax);
    break;

  case nexistchk:
    fprintf(*tofile,
	    "attempt to call entry of non-existent/terminated process\n");
    break;

  case namechk:
    fprintf(*tofile, "attempt to make entry on process without unique name\n");
    break;

  case casechk:
    fprintf(*tofile, "label of %ld not found in case\n",
	    s[ptab[curpr].t - 1].UU.i);
    break;

  case bndchk:
    fprintf(*tofile, "ordinal value out of range\n");
    break;

  case instchk:
    fprintf(*tofile, "multiple activation of a process\n");
    break;

  case inpchk:
    fprintf(*tofile, "error in numeric input\n");
    break;

  case setchk:
    fprintf(*tofile, "bitset value out of bounds\n");
    break;

  case ovchk:
    fprintf(*tofile, "arithmetic overflow\n");
    break;

  case seminitchk:
    fprintf(*tofile, "attempt to initialise semaphore from process\n");
    break;
  }/* case */

  fprintf(*tofile, "\n\n");
}  /* headermsg */


Static Void printyp(tp, tofile)
types tp;
FILE **tofile;
{
  switch (tp) {

  case semafors:
    fprintf(*tofile, " (semaphore)\n");
    break;

  case condvars:
    fprintf(*tofile, " (condition)\n");
    break;

  case monvars:
  case protvars:
    putc('\n', *tofile);
    break;

  case channels:
    fprintf(*tofile, " (channel)\n");
    break;

  case entrys:
    fprintf(*tofile, " (entry)\n");
    break;

  case procs:
    /* blank case */
    break;

  case protq:
    fprintf(*tofile, " (procedure guard)\n");
    break;
  }
}  /* printyp */



Static Void oneproc(nproc)
long nproc;
{


  /* give pmd report on one process */
  types tp;
  long loop, frameptr, chanptr;
  _REC_ptab *WITH;
  long FORLIM;


  fprintf(pmdfile, "----------\n");

  WITH = &ptab[nproc];   /* with */

  if (nproc == 0) {
    fprintf(pmdfile, "Main program\n");

  } else {
    fprintf(pmdfile, "Process ");
    nameobj((long)WITH->varptr, &tp, &pmdfile);
    putc('\n', pmdfile);

  }


  fprintf(pmdfile, "\nStatus:  ");

  if (WITH->active) {
    fprintf(pmdfile, "active\n");
    fprintf(pmdfile, "pc = %ld\n", WITH->pc);

  } else {
    if (nproc == 0) {
      fprintf(pmdfile, "awaiting process termination\n");

    } else
      fprintf(pmdfile, "terminated\n");

  }


  if (WITH->termstate || WITH->suspend != 0) {
    fprintf(pmdfile, "\nProcess suspended on:\n\n");

    if (WITH->suspend > 0) {
      nameobj(WITH->suspend, &tp, &pmdfile);

      printyp(tp, &pmdfile);
    } else {
      frameptr = WITH->chans;
      FORLIM = labs(WITH->suspend);
      for (loop = 1; loop <= FORLIM; loop++) {
	chanptr = s[frameptr - 1].UU.i;
	if (chanptr != 0) {   /* 0 means timeout */
	  nameobj(chanptr, &tp, &pmdfile);

	  printyp(tp, &pmdfile);
	} else
	  fprintf(pmdfile, "timeout alternative\n");


	frameptr += sfsize;
      }
    }

    if (WITH->termstate) {
      fprintf(pmdfile, "terminate alternative\n");

    }

  }

  fprintf(pmdfile, "\n\n");





}  /* oneproc */



Static Void globals()
{


  /* print global variables */
  long h1;
  boolean noglobals;
  objcoderec *WITH;
  tabrec *WITH1;

  noglobals = true;

  fprintf(pmdfile, "\n==========\n");
  fprintf(pmdfile, "Global variables\n\n");
  WITH = &GETBINFILEBUF(objfile, objcoderec);   /* with objfile^ */

  h1 = WITH->genbtab[1].last;
  while (WITH->gentab[h1].link != 0) {
    WITH1 = &WITH->gentab[h1];
    if ((object)WITH1->obj == variable) {
      if (((1L << WITH1->typ) & (stantyps | (1L << ((long)semafors)) |
				 (1L << ((long)enums)))) != 0) {
	noglobals = false;
	switch ((types)WITH1->typ) {

	case ints:
	case semafors:
	case enums:
	  fprintf(pmdfile, "%.*s = %12ld\n",
		  alng, WITH1->name, s[WITH1->taddr - 1].UU.i);
	  break;


	case reals:
	  fprintf(pmdfile, "%.*s = % .5E\n",
		  alng, WITH1->name, s[WITH1->taddr - 1].UU.r);
	  break;


	case bools:
	  fprintf(pmdfile, "%.*s = %s\n",
		  alng, WITH1->name,
		  itob(s[WITH1->taddr - 1].UU.i) ? " TRUE" : "FALSE");
	  break;


	case chars:
	  fprintf(pmdfile, "%.*s = %c\n",
		  alng, WITH1->name, (Char)(s[WITH1->taddr - 1].UU.i & 63));
	  break;


	}/* case */
      }  /* if */
    }
    h1 = WITH1->link;   /* with gentab */
  }
  if (noglobals) {
    fprintf(pmdfile, "(None)\n");

  }

}  /* globals */





Static Void expmd()
{

  /* print post-mortem dump on execution-time error */
  long h1;
  types tp;
  FILE *TEMP;
  long FORLIM;






  if (pmdfile != NULL)
    pmdfile = freopen("pmdfile", "w", pmdfile);
  else
    pmdfile = fopen("pmdfile", "w");
  if (pmdfile == NULL)
    _EscIO(FileNotFound);
  fprintf(pmdfile, "Pascal-FC post-mortem report on ");
  printname(GETBINFILEBUF(objfile, objcoderec).prgname, &pmdfile);
  putc('\n', pmdfile);
  putversion(&pmdfile);
  putc('\n', pmdfile);
  headermsg(tp, &pmdfile);
  TEMP = stdout;
/* p2c: ufpint.pas, line 873:
 * Note: Taking address of stdout; consider setting VarFiles = 0 [144] */
  headermsg(tp, &TEMP);
  printf("\nSee pmdfile for post-mortem report\n");
  FORLIM = procmax;
  for (h1 = 0; h1 <= FORLIM; h1++)
    oneproc(h1);

  if (curpr != 0 || ps != stkchk)
    globals();

}  /* expmd */



/* real-time clock management module */


extern Void sleep PP((long n));

Static Void initclock()
{
  sysclock = 0;
  last = time(0L);
}  /* initclock */


Static Void checkclock()
{
  now = -time(0L);
  if (now != last) {
    last = now;
    sysclock++;
  }
}  /* checkclock */


Static Void doze(n)
long n;
{
  while (eventqueue.time > sysclock)
    checkclock();
}  /* doze */


/* Local variables for runprog: */
struct LOC_runprog {
  jmp_buf _JL98;
} ;

Local Void alarmclock PP((struct LOC_runprog *LINK));


Local Void getqueuenode(pnum, ptr, LINK)
ptype pnum;
qnode **ptr;
struct LOC_runprog *LINK;
{

  /* place pnum in a dynamic queue node */
  qnode *WITH;

  *ptr = (qnode *)Malloc(sizeof(qnode));
  WITH = *ptr;
  WITH->proc = pnum;
  WITH->next = NULL;
}  /* getqueuenode */



Local Void joineventq(waketime, LINK)
long waketime;
struct LOC_runprog *LINK;
{

  /* join queue of processes which have executed a "sleep" */
  qnode *thisnode, *frontpointer, *backpointer;
  boolean foundplace;
  _REC_ptab *WITH;

  WITH = &ptab[curpr];
  WITH->wakeup = waketime;
  if (WITH->wakestart == 0)
    WITH->wakestart = WITH->pc;
  stepcount = 0;
  getqueuenode(curpr, &thisnode, LINK);
  frontpointer = eventqueue.first;
  if (frontpointer != NULL) {
    backpointer = NULL;
    foundplace = false;
    while (!foundplace && frontpointer != NULL) {
      if (ptab[frontpointer->proc].wakeup > waketime)
	foundplace = true;
      else {
	backpointer = frontpointer;
	frontpointer = backpointer->next;
      }
    }
    thisnode->next = frontpointer;
    if (backpointer != NULL)
      backpointer->next = thisnode;
  }  /* if first <> nil */
  if (frontpointer == eventqueue.first) {   /* with eventqueue */
    eventqueue.first = thisnode;
    eventqueue.time = waketime;
  }
}  /* joineventq */


Local Void leventqueue(pnum, LINK)
ptype pnum;
struct LOC_runprog *LINK;
{

  /* process pnum is taken from event queue */
  /* (a rendezvous has occurred before a timeout alternative expires) */
  qnode *frontpointer, *backpointer;
  boolean found;

  frontpointer = eventqueue.first;
  backpointer = NULL;
  found = false;
  while (!found && frontpointer != NULL) {
    if (frontpointer->proc == pnum)
      found = true;
    else {
      backpointer = frontpointer;
      frontpointer = frontpointer->next;
    }
  }
  if (!found) {   /* with eventqueue */
    return;
  }  /* if found */
  if (backpointer == NULL) {
    eventqueue.first = frontpointer->next;
    if (eventqueue.first != NULL)
      eventqueue.time = ptab[eventqueue.first->proc].wakeup;
    else
      eventqueue.time = 0;
  } else
    backpointer->next = frontpointer->next;
  Free(frontpointer);
}  /* leventqueue */

Local Void chooseproc(LINK)
struct LOC_runprog *LINK;
{

  /* modified to permit a terminate option on select - gld */
  long d, procindex;
  boolean foundproc, procwaiting;
  _REC_ptab *WITH;

  foundproc = false;
  do {
    procwaiting = false;
    d = procmax + 1;

    procindex = 1;

    while (!foundproc && d >= 0) {   /* with */
      WITH = &ptab[procindex];
      foundproc = (WITH->active && WITH->suspend == 0 && WITH->wakeup == 0 &&
		   !WITH->termstate);
      if (foundproc) {
	break;
      }  /* if not foundproc */
      if (WITH->active && !WITH->termstate)
	procwaiting = true;
      d--;
      procindex = (procindex + 1) % (procmax + 1);
/* p2c: ufpint.pas, line 1060:
 * Note: Using % for possibly-negative arguments [317] */
    }
    if (!foundproc) {
      if (procwaiting) {
	if (eventqueue.first != NULL) {
	  doze(eventqueue.time - sysclock);
	  alarmclock(LINK);
	} else {
	  ps = deadlock;
	  longjmp(LINK->_JL98, 1);
	}
      } else
	ptab[0].active = true;
    } else {
      curpr = procindex;
      stepcount = (long)(xrandom(seedx) * stepmax);
    }
  } while (!(foundproc || ps != run));   /* chooseproc */
}



Local Void clearchans(pnum, h, LINK)
long pnum, h;
struct LOC_runprog *LINK;
{

  /* clear all channels on which the process sleeps */
  long loop, nchans, frameptr, chanptr;
  _REC_ptab *WITH;

  WITH = &ptab[pnum];
  nchans = labs(WITH->suspend);
  frameptr = WITH->chans;
  for (loop = 1; loop <= nchans; loop++) {
    chanptr = s[frameptr - 1].UU.i;
    if (chanptr != 0) {   /* timeout if 0 */
      s[chanptr - 1].UU.i = 0;
      if (chanptr == h) {
	if (WITH->onselect) {
	  WITH->repindex = s[frameptr + 4].UU.i;
	  WITH->onselect = false;
	}
      }
    }
    frameptr += sfsize;
  }
  WITH->chans = 0;
  WITH->suspend = 0;
  WITH->termstate = false;   /* with */
}  /* clearchans */



Local Void wakenon(h, LINK)
long h;
struct LOC_runprog *LINK;
{

  /* awakens the process asleep on this channel */
  /* also used to wake a process asleep on several entries
     in a select statement, where it cannot be in a queue */
  long procn;
  _REC_ptab *WITH;

  procn = s[h + 1].UU.i;
  WITH = &ptab[procn];
  clearchans(procn, h, LINK);
  leventqueue((int)procn, LINK);
  WITH->wakeup = 0;
  WITH->pc = s[h].UU.i;   /* with ptab[procn] */


}  /* wakenon */


Local Void initqueue(LINK)
struct LOC_runprog *LINK;
{

  /* initialise process queue */
  char index;

  procqueue.free = 1;
  for (index = 1; index < pmax; index++)
    procqueue.proclist[index - 1].link = index + 1;
  procqueue.proclist[pmax - 1].link = 0;   /* with */
}  /* initqueue */


Local Void getnode(node, LINK)
ptype *node;
struct LOC_runprog *LINK;
{

  /* get a node from the free list for process queues */
  /* the link is set to zero */
  if (procqueue.free == 0) {
    ps = queuechk;
    return;
  }
  *node = procqueue.free;
  procqueue.free = procqueue.proclist[*node - 1].link;
  procqueue.proclist[*node - 1].link = 0;
}  /* getnode */


Local Void disposenode(node, LINK)
ptype node;
struct LOC_runprog *LINK;
{

  /* return monitor queue node to free list */
  procqueue.proclist[node - 1].link = procqueue.free;
  procqueue.free = node;
}  /* disposenode */


Local Void joinqueue(add_, LINK)
long add_;
struct LOC_runprog *LINK;
{

  /* join a process queue */
  /* add is the stack address of the condvar or monvar */
  ptype newnode, temp;

  ptab[curpr].suspend = add_;
  stepcount = 0;
  getnode(&newnode, LINK);
  procqueue.proclist[newnode - 1].proc = curpr;
  if (s[add_ - 1].UU.i < 1) {
    s[add_ - 1].UU.i = newnode;
    return;
  }
  temp = s[add_ - 1].UU.i;
  while (procqueue.proclist[temp - 1].link != 0)
    temp = procqueue.proclist[temp - 1].link;
  procqueue.proclist[temp - 1].link = newnode;
}  /* joinqueue */






Local Void alarmclock(LINK)
struct LOC_runprog *LINK;
{

  /* wake processes on event queue */
  long now;
  qnode *frontpointer, *backpointer;
  boolean finished;
  _REC_ptab *WITH;

  now = eventqueue.time;
  finished = false;
  frontpointer = eventqueue.first;
  while (frontpointer != NULL && !finished) {
    WITH = &ptab[frontpointer->proc];
    clearchans((long)frontpointer->proc, 0L, LINK);
    WITH->wakeup = 0;
    WITH->pc = WITH->wakestart;
    WITH->wakestart = 0;
    backpointer = frontpointer;
    frontpointer = frontpointer->next;
    Free(backpointer);
    if (frontpointer != NULL)
      finished = (ptab[frontpointer->proc].wakeup != now);
  }  /* while */
  eventqueue.first = frontpointer;
  if (frontpointer == NULL)   /* with eventqueue */
    eventqueue.time = 0;
  else
    eventqueue.time = ptab[frontpointer->proc].wakeup;
}  /* alarmclock */



Local Void procwake(add_, LINK)
long add_;
struct LOC_runprog *LINK;
{

  /* wakes the first process in a monitor queue */
  /* add is the stack address of the condvar or monvar */
  ptype pr, node;

  if (s[add_ - 1].UU.i <= 0)
    return;
  node = s[add_ - 1].UU.i;
  pr = procqueue.proclist[node - 1].proc;
  s[add_ - 1].UU.i = procqueue.proclist[node - 1].link;
  disposenode(node, LINK);

  ptab[pr].suspend = 0;
}  /* procwake */


Local Void releasemon(curmon, LINK)
long curmon;
struct LOC_runprog *LINK;
{

  /* release mutual exclusion on a monitor */
  if (s[curmon].UU.i > 0) {
    procwake(curmon + 1, LINK);
    return;
  }
  if (s[curmon - 1].UU.i <= 0) {
    s[curmon - 1].UU.i = 0;
    return;
  }
  procwake(curmon, LINK);
  if (s[curmon - 1].UU.i == 0)
    s[curmon - 1].UU.i = -1;
}  /* releasemon */


Local Void skipblanks(LINK)
struct LOC_runprog *LINK;
{
  while ((!P_eof(stdin)) & (P_peek(stdin) == ' '))
    getc(stdin);
}  /* skipblanks */



Local Void readunsignedint(inum, numerror, LINK)
long *inum;
boolean *numerror;
struct LOC_runprog *LINK;
{
  long digit;

  *inum = 0;
  *numerror = false;
  do {
    if (*inum > intmax / 10)
      *numerror = true;
    else {
      *inum *= 10;
      digit = P_peek(stdin) - '0';
      if (digit > intmax - *inum)
	*numerror = true;
      else
	*inum += digit;
    }
    getc(stdin);
  } while (isdigit(P_peek(stdin)));
  if (*numerror)
    *inum = 0;
}  /* readunsignedint */



Local Void readbasedint(inum, numerror, LINK)
long *inum;
boolean *numerror;
struct LOC_runprog *LINK;
{

  /* on entry inum has been set by unsignedint */
  long digit, base;
  boolean negative;

  getc(stdin);
  if ((unsigned long)(*inum) < 32 && ((1L << (*inum)) & 0x10104L) != 0)
    base = *inum;
  else {
    base = 16;
    *numerror = true;
  }
  *inum = 0;
  negative = false;
  do {
    if (negative)
      *numerror = true;
    else {
      if (*inum > intmax / base) {
	if (*inum <= intmax / (base / 2))
	  negative = true;
	else
	  *numerror = true;
	*inum %= intmax / base + 1;
/* p2c: ufpint.pas, line 1369:
 * Note: Using % for possibly-negative arguments [317] */
      }
      *inum *= base;
      if (isdigit(P_peek(stdin)))
	digit = P_peek(stdin) - '0';
      else {
	if (isupper(P_peek(stdin)))
	  digit = P_peek(stdin) + 10 - 'A';
	else {
	  if (islower(P_peek(stdin)))
	    digit = P_peek(stdin) + 10 - 'a';
	  else
	    *numerror = true;
	}
      }
      if (digit >= base)
	*numerror = true;
      else
	*inum += digit;
    }
    getc(stdin);
  } while (isalnum(P_peek(stdin)));
  if (negative) {
    if (*inum == 0)
      *numerror = true;
    else
      *inum += -LONG_MAX - 1;
  }
  if (*numerror)
    *inum = 0;
}  /* readbasedint */


Local Void findstart(sign, LINK)
long *sign;
struct LOC_runprog *LINK;
{

  /* find start of integer or real */
  skipblanks(LINK);
  if (P_eof(stdin)) {
    ps = redchk;
    return;
  }
  *sign = 1;
  if (P_peek(stdin) == '+') {
    getc(stdin);
    return;
  }
  if (P_peek(stdin) == '-') {
    getc(stdin);
    *sign = -1;
  }
}  /* findstart */




Local Void readint(inum, LINK)
long *inum;
struct LOC_runprog *LINK;
{
  long sign;
  boolean numerror;

  findstart(&sign, LINK);
  if (P_eof(stdin))
    return;
  if (isdigit(P_peek(stdin))) {
    readunsignedint(inum, &numerror, LINK);
    *inum *= sign;
    if (P_peek(stdin) == '#')
      readbasedint(inum, &numerror, LINK);
  } else
    numerror = true;
  if (numerror)
    ps = inpchk;
}  /* readint */



Local Void readscale(e, numerror, LINK)
long *e;
boolean *numerror;
struct LOC_runprog *LINK;
{
  long s, sign, digit;

  getc(stdin);
  sign = 1;
  s = 0;
  if (P_peek(stdin) == '+')
    getc(stdin);
  else {
    if (P_peek(stdin) == '-') {
      getc(stdin);
      sign = -1;
    }
  }
  if (!isdigit(P_peek(stdin)))
    *numerror = true;
  else {
    do {
      if (s > intmax / 10)
	*numerror = true;
      else {
	s *= 10;
	digit = P_peek(stdin) - '0';
	if (digit > intmax - s)
	  *numerror = true;
	else
	  s += digit;
      }
      getc(stdin);
    } while (isdigit(P_peek(stdin)));
  }
  if (*numerror)
    *e = 0;
  else
    *e += s * sign;
}  /* readscale */


Local Void adjustscale(rnum, k, e, numerror, LINK)
double *rnum;
long k, e;
boolean *numerror;
struct LOC_runprog *LINK;
{
  long s;
  double d, t;

  if (k + e > emax) {
    *numerror = true;
    return;
  }
  while (e < emin) {
    *rnum /= 10.0;
    e++;
  }
  s = labs(e);
  t = 1.0;
  d = 10.0;
  do {
    while (!(s & 1)) {
      s /= 2;
      d *= d;
    }
    s--;
    t = d * t;
  } while (s != 0);
  if (e < 0) {
    *rnum /= t;
    return;
  }
  if (*rnum > realmax / t)
    *numerror = true;
  else
    *rnum *= t;
}  /* adjustscale */


Local Void readreal(rnum, LINK)
double *rnum;
struct LOC_runprog *LINK;
{
  long k, e, sign, digit;
  boolean numerror;

  numerror = false;
  findstart(&sign, LINK);
  if (!P_eof(stdin)) {
    if (isdigit(P_peek(stdin))) {
      while (P_peek(stdin) == '0')
	getc(stdin);
      *rnum = 0.0;
      k = 0;
      e = 0;
      while (isdigit(P_peek(stdin))) {
	if (*rnum > realmax / 10.0)
	  e++;
	else {
	  k++;
	  *rnum *= 10.0;
	  digit = P_peek(stdin) - '0';
	  if (digit <= realmax - *rnum)
	    *rnum += digit;
	}
	getc(stdin);
      }
      if (P_peek(stdin) == '.') {  /* fractional part */
	getc(stdin);
	do {
	  if (isdigit(P_peek(stdin))) {
	    if (*rnum <= realmax / 10.0) {
	      e--;
	      *rnum = 10.0 * *rnum;
	      digit = P_peek(stdin) - '0';
	      if (digit <= realmax - *rnum)
		*rnum += digit;
	    }
	    getc(stdin);
	  } else
	    numerror = true;
	} while (isdigit(P_peek(stdin)));
	if (P_peek(stdin) == 'E' || P_peek(stdin) == 'e')
	  readscale(&e, &numerror, LINK);
	if (e != 0)
	  adjustscale(rnum, k, e, &numerror, LINK);
      }  /* fractional part */
      else {
	if (P_peek(stdin) == 'E' || P_peek(stdin) == 'e') {
	  readscale(&e, &numerror, LINK);
	  if (e != 0)
	    adjustscale(rnum, k, e, &numerror, LINK);
	} else {
	  if (e != 0)
	    numerror = true;
	}
      }
      *rnum *= sign;
    } else
      numerror = true;
  }
  if (numerror)
    ps = inpchk;
}  /* readreal */





Static Void runprog()
{

  /* execute program once */
  struct LOC_runprog V;
  _REC_ptab *WITH;
  long FORLIM, TEMP;
  double TEMP1;
  _REC_ptab *WITH1;
  objcoderec *WITH2;







  if (setjmp(V._JL98))
    goto _L98;
  stantyps = (1L << ((long)ints)) | (1L << ((long)reals)) |
	     (1L << ((long)chars)) | (1L << ((long)bools));
  printf("\nProgram %.*s...  execution begins ...\n\n\n",
	 alng, GETBINFILEBUF(objfile, objcoderec).prgname);
  initqueue(&V);
  s[0].UU.i = 0;
  s[1].UU.i = 0;
  s[2].UU.i = -1;
  s[3].UU.i = GETBINFILEBUF(objfile, objcoderec).genbtab[0].last;
  WITH = ptab;
  WITH->stackbase = 0;
  WITH->b = 0;
  WITH->suspend = 0;
  WITH->display[0] = 0;
  WITH->pc = GETBINFILEBUF(objfile, objcoderec).gentab[s[3].UU.i].taddr;
  WITH->active = true;
  WITH->termstate = false;
  WITH->stacksize = stmax - pmax * stkincr;
  WITH->curmon = 0;
  WITH->wakeup = 0;
  WITH->wakestart = 0;
  WITH->onselect = false;
  WITH->t = GETBINFILEBUF(objfile, objcoderec).genbtab[1].vsize - 1;
  if (WITH->t > WITH->stacksize) {
    ps = stkchk;
    goto _L98;
  }
  FORLIM = WITH->t;
  for (h1 = 5; h1 <= FORLIM; h1++)
    s[h1 - 1].UU.i = 0;
  for (curpr = 1; curpr <= pmax; curpr++) {
    WITH = &ptab[curpr];
    WITH->active = false;
    WITH->termstate = false;
    WITH->display[0] = 0;
    WITH->pc = 0;
    WITH->suspend = 0;
    WITH->curmon = 0;
    WITH->wakeup = 0;
    WITH->wakestart = 0;
    WITH->stackbase = ptab[curpr - 1].stacksize + 1;
    WITH->b = WITH->stackbase;
    WITH->stacksize = WITH->stackbase + stkincr - 1;
    WITH->t = WITH->b - 1;
    WITH->onselect = false;
    WITH->clearresource = true;
  }
  npr = 0;
  procmax = 0;
  curpr = 0;
  stepcount = 0;
  ps = run;
  lncnt = 0;
  chrcnt = 0;
  concflag = false;
  statcounter = 0;
  initclock();

  eventqueue.first = NULL;
  eventqueue.time = -1;


  do {
    if (ptab[0].active && ptab[0].suspend == 0 && ptab[0].wakeup == 0)
      curpr = 0;
    else {
      if (stepcount == 0)
	chooseproc(&V);
      else
	stepcount--;
    }

    WITH = &ptab[curpr];
    ir = GETBINFILEBUF(objfile, objcoderec).gencode[WITH->pc];

    WITH->pc++;

    if (concflag)
      curpr = npr;

    WITH = &ptab[curpr];

    switch (ir.f) {   /*case*/

    case 0:
      /*load address*/
      WITH->t++;
      if (WITH->t > WITH->stacksize)
	ps = stkchk;
      else
	s[WITH->t - 1].UU.i = WITH->display[SEXT(ir.x, 4) - 1] + ir.y;
      break;

    case 1:
      /*load value*/
      WITH->t++;
      if (WITH->t > WITH->stacksize) {
	ps = stkchk;

      } else {
	s[WITH->t - 1] = s[WITH->display[SEXT(ir.x, 4) - 1] + ir.y - 1];

      }
      break;

    case 2:
      /*load indirect*/
      WITH->t++;
      if (WITH->t > WITH->stacksize)
	ps = stkchk;
      else
	s[WITH->t - 1] = s[s[WITH->display[SEXT(ir.x, 4) - 1] + ir.y - 1].UU.i - 1];
      break;

    case 3:
      /*update display*/
      h1 = ir.y;
      h2 = SEXT(ir.x, 4);
      h3 = WITH->b;
      do {
	WITH->display[h1 - 1] = h3;
	h1--;
	h3 = s[h3 + 1].UU.i;
      } while (h1 != h2);
      break;

    case 4:
      break;
      /*cobegin*/

    case 5:
      procmax = npr;
      ptab[0].active = false;
      stepcount = 0;
      break;
      /*coend*/


    case 6:
      /*wait*/
      h1 = s[WITH->t - 1].UU.i;
      WITH->t--;

      if (s[h1 - 1].UU.i > 0) {
	s[h1 - 1].UU.i--;

      } else {
	WITH->suspend = h1;
	stepcount = 0;
      }
      break;

    case 7:
      /*asignal*/
      h1 = s[WITH->t - 1].UU.i;
      WITH->t--;
      h2 = pmax + 1;
      h3 = (long)(xrandom(seedx) * h2);
      while (h2 >= 0 && ptab[h3].suspend != h1) {
	h3 = (h3 + 1) % (pmax + 1);
/* p2c: ufpint.pas, line 1736:
 * Note: Using % for possibly-negative arguments [317] */
	h2--;
      }

      if (h2 < 0)
	s[h1 - 1].UU.i++;
      else {
	ptab[h3].suspend = 0;

      }
      break;

    case 8:
      switch (ir.y) {

      case 0:
	s[WITH->t - 1].UU.i = labs(s[WITH->t - 1].UU.i);
	break;

      case 1:
	s[WITH->t - 1].UU.r = fabs(s[WITH->t - 1].UU.r);
	break;

      case 2:   /* integer sqr */
	if (intmax / labs(s[WITH->t - 1].UU.i) < labs(s[WITH->t - 1].UU.i))
	  ps = ovchk;
	else {
	  TEMP = s[WITH->t - 1].UU.i;
	  s[WITH->t - 1].UU.i = TEMP * TEMP;
	}
	break;

      case 3:   /* real sqr */
	if (realmax / fabs(s[WITH->t - 1].UU.r) < fabs(s[WITH->t - 1].UU.r))
	  ps = ovchk;
	else {
	  TEMP1 = s[WITH->t - 1].UU.r;
	  s[WITH->t - 1].UU.r = TEMP1 * TEMP1;
	}
	break;

      case 4:
	s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.i & 1);
	break;

      case 5:
	if ((unsigned long)s[WITH->t - 1].UU.i > charh)
	  ps = charchk;
	break;

      case 6:
	/* blank case */
	break;

      case 7:   /* succ */
	s[WITH->t - 1].UU.i++;
	break;

      case 8:   /* pred */
	s[WITH->t - 1].UU.i--;
	break;

      case 9:   /* round */
	if (fabs(s[WITH->t - 1].UU.r) >= intmax + 0.5)
	  ps = ovchk;
	else
	  s[WITH->t - 1].UU.i = (long)floor(s[WITH->t - 1].UU.r + 0.5);
	break;

      case 10:   /* trunc */
	if (fabs(s[WITH->t - 1].UU.r) >= intmax + 1.0)
	  ps = ovchk;
	else
	  s[WITH->t - 1].UU.i = (long)s[WITH->t - 1].UU.r;
	break;

      case 11:
	s[WITH->t - 1].UU.r = sin(s[WITH->t - 1].UU.r);
	break;

      case 12:
	s[WITH->t - 1].UU.r = cos(s[WITH->t - 1].UU.r);
	break;

      case 13:
	s[WITH->t - 1].UU.r = exp(s[WITH->t - 1].UU.r);
	break;

      case 14:   /* ln */
	if (s[WITH->t - 1].UU.r <= 0.0)
	  ps = ovchk;
	else
	  s[WITH->t - 1].UU.r = log(s[WITH->t - 1].UU.r);
	break;

      case 15:   /* sqrt */
	if (s[WITH->t - 1].UU.r < 0.0)
	  ps = ovchk;
	else
	  s[WITH->t - 1].UU.r = sqrt(s[WITH->t - 1].UU.r);
	break;

      case 16:
	s[WITH->t - 1].UU.r = atan(s[WITH->t - 1].UU.r);
	break;

      case 17:
	WITH->t++;
	if (WITH->t > WITH->stacksize)
	  ps = stkchk;
	else
	  s[WITH->t - 1].UU.i = btoi(P_eof(stdin));
	break;

      case 18:
	WITH->t++;
	if (WITH->t > WITH->stacksize)
	  ps = stkchk;
	else
	  s[WITH->t - 1].UU.i = btoi(P_eoln(stdin));
	break;

      case 19:
	h1 = labs(s[WITH->t - 1].UU.i) + 1;
	s[WITH->t - 1].UU.i = (long)(xrandom(seedx) * h1);
	break;

      case 20:   /* empty */
	h1 = s[WITH->t - 1].UU.i;
	if (s[h1 - 1].UU.i == 0)
	  s[WITH->t - 1].UU.i = 1;
	else
	  s[WITH->t - 1].UU.i = 0;
	break;
	/* f21 */

      case 21:   /* bits */
	h1 = s[WITH->t - 1].UU.i;
	s[WITH->t - 1].UU.bs = 0;
	h3 = 0;
	if (h1 < 0) {
	  if (bsmsb < intmsb) {
	    ps = setchk;
	    h1 = 0;
	  } else {
	    s[WITH->t - 1].UU.bs = 1L << bsmsb;
	    h1 += LONG_MAX + 1;
	    h3 = 1;
	  }
	}
	FORLIM = bsmsb - h3;
	for (h2 = 0; h2 <= FORLIM; h2++) {
	  if ((h1 & 1) == 1)
	    s[WITH->t - 1].UU.bs = ((long)s[WITH->t - 1].UU.bs) | (1L << ((int)h2));
	  h1 /= 2;
	}
	if (h1 != 0)
	  ps = setchk;
	break;
	/* f21 */

      case 24:   /* int - bitset to integer */
	h1 = 0;
	if (bsmsb == intmsb) {
	  if ((unsigned long)intmsb < 32 &&
	      ((1L << intmsb) & s[WITH->t - 1].UU.bs) != 0)
	    h1 = 1;
	}
	h2 = 0;   /* running total */
	h3 = 1;   /* place value */
	FORLIM = bsmsb - h1;
	for (h4 = 0; h4 <= FORLIM; h4++) {
	  if ((unsigned long)h4 < 32 &&
	      ((1L << h4) & s[WITH->t - 1].UU.bs) != 0)
	    h2 += h3;
	  h3 *= 2;
	}
	if (h1 != 0)
	  s[WITH->t - 1].UU.i = h2 - LONG_MAX - 1;
	else
	  s[WITH->t - 1].UU.i = h2;
	break;

      case 25:   /* clock */
	WITH->t++;
	if (WITH->t > WITH->stacksize)
	  ps = stkchk;
	else
	  s[WITH->t - 1].UU.i = sysclock;
	break;
	/* f25 */

      }
      break;

    case 9:
      s[WITH->t - 1].UU.i += ir.y;
      break;

    case 10:
      WITH->pc = ir.y;
      break;

    /*jump*/
    case 11:
      /*conditional jump*/
      if (s[WITH->t - 1].UU.i == fals)
	WITH->pc = ir.y;
      WITH->t--;
      break;

    case 12:   /* case1 */
      if (s[WITH->t - 1].UU.i == s[WITH->t - 2].UU.i) {
	WITH->t -= 2;
	WITH->pc = ir.y;
      } else
	WITH->t--;
      break;

    case 13:   /* case 2 */
      ps = casechk;
      break;

    case 14:
      /*for1up*/
      h1 = s[WITH->t - 2].UU.i;
      if (h1 <= s[WITH->t - 1].UU.i)
	s[s[WITH->t - 3].UU.i - 1].UU.i = h1;
      else {
	WITH->t -= 3;
	WITH->pc = ir.y;
      }
      break;

    case 15:
      /*for2up*/
      h2 = s[WITH->t - 3].UU.i;
      h1 = s[h2 - 1].UU.i + 1;
      if (h1 <= s[WITH->t - 1].UU.i) {
	s[h2 - 1].UU.i = h1;
	WITH->pc = ir.y;
      } else
	WITH->t -= 3;
      break;

    case 18:
      if (SEXT(ir.x, 4) == 1) {  /* process */
	if (npr == pmax) {
	  ps = procnchk;
	  goto _L98;
	}
	npr++;
	concflag = true;
	curpr = npr;
      }
      h1 = GETBINFILEBUF(objfile, objcoderec).genbtab[GETBINFILEBUF(objfile, objcoderec).
						gentab[ir.y].ref - 1].vsize;
      WITH1 = &ptab[curpr];
      if (WITH1->t + h1 > WITH1->stacksize)   /* with */
	ps = stkchk;
      else {
	WITH1->t += 5;
	s[WITH1->t - 2].UU.i = h1 - 1;
	s[WITH1->t - 1].UU.i = ir.y;
      }
      break;

    case 19:
      h1 = WITH->t - ir.y;
      h2 = s[h1 + 3].UU.i;   /*h2 points to tab*/
      h3 = GETBINFILEBUF(objfile, objcoderec).gentab[h2].lev;
      WITH->display[h3] = h1;
      h4 = s[h1 + 2].UU.i + h1;
      s[h1].UU.i = WITH->pc;
      s[h1 + 1].UU.i = WITH->display[h3 - 1];
      if (SEXT(ir.x, 4) == 1) {  /* process */
	WITH->active = true;
	s[h1 + 2].UU.i = ptab[0].b;
	concflag = false;
      } else
	s[h1 + 2].UU.i = WITH->b;
      FORLIM = h4;
      for (h3 = WITH->t + 1; h3 <= FORLIM; h3++)
	s[h3 - 1].UU.i = 0;
      WITH->b = h1;
      WITH->t = h4;
      WITH->pc = GETBINFILEBUF(objfile, objcoderec).gentab[h2].taddr;
      break;

    case 21:
      WITH2 = &GETBINFILEBUF(objfile, objcoderec);
      /*index*/
      h1 = ir.y;
      /*h1 points to genatab*/
      h2 = WITH2->genatab[h1 - 1].low;
      h3 = s[WITH->t - 1].UU.i;
      if (h3 < h2)
	ps = inxchk;
      else {
	if (h3 > WITH2->genatab[h1 - 1].high)
	  ps = inxchk;
	else {
	  WITH->t--;
	  s[WITH->t - 1].UU.i += (h3 - h2) * WITH2->genatab[h1 - 1].elsize;
	}
      }
      break;

    case 22:
      /*load block*/
      h1 = s[WITH->t - 1].UU.i;
      WITH->t--;
      h2 = ir.y + WITH->t;
      if (h2 > WITH->stacksize)
	ps = stkchk;
      else {
	while (WITH->t < h2) {
	  WITH->t++;
	  s[WITH->t - 1] = s[h1 - 1];
	  h1++;
	}
      }
      break;

    case 23:
      /*copy block*/
      h1 = s[WITH->t - 2].UU.i;
      h2 = s[WITH->t - 1].UU.i;
      h3 = h1 + ir.y;
      while (h1 < h3) {
	s[h1 - 1] = s[h2 - 1];
	h1++;
	h2++;
      }
      WITH->t -= 2;
      break;

    case 24:
      /*literal*/
      WITH->t++;
      if (WITH->t > WITH->stacksize)
	ps = stkchk;
      else
	s[WITH->t - 1].UU.i = ir.y;
      break;

    case 25:
      WITH->t++;
      if (WITH->t > WITH->stacksize)
	ps = stkchk;
      else
	s[WITH->t - 1].UU.r = GETBINFILEBUF(objfile, objcoderec).genrconst[ir.y - 1];
      break;

    case 26:  /* float */
      h1 = WITH->t - ir.y;
      s[h1 - 1].UU.r = s[h1 - 1].UU.i;
      break;





    case 27:
      /*read*/
      if (P_eof(stdin))
	ps = redchk;
      else {
	switch (ir.y) {

	case 1:   /* integer */
	  readint(&s[s[WITH->t - 1].UU.i - 1].UU.i, &V);
	  break;

	case 3:   /* char */
	  if (P_eof(stdin))
	    ps = redchk;
	  else {
	    ch = getchar();
	    if (ch == '\n')
	      ch = ' ';
	    s[s[WITH->t - 1].UU.i - 1].UU.i = ch;
	  }
	  break;

	case 4:   /* real */
	  readreal(&s[s[WITH->t - 1].UU.i - 1].UU.r, &V);
	  break;
	}
      }
      WITH->t--;
      break;

    case 28:
      /*write string*/
      if (SEXT(ir.x, 4) == 1) {
	h3 = s[WITH->t - 1].UU.i;
	WITH->t--;
      } else
	h3 = 0;
      h1 = s[WITH->t - 1].UU.i;
      h2 = ir.y;
      WITH->t--;
      chrcnt += h1 + h3;
      while (h3 > h1) {
	putchar(' ');
	h3--;
      }
      do {
	putchar(GETBINFILEBUF(objfile, objcoderec).genstab[h2]);
	h1--;
	h2++;
      } while (h1 != 0);
      break;

    case 29:
      switch (ir.y) {

      case 1:   /* ints */
	printf("%12ld", s[WITH->t - 1].UU.i);
	break;

      case 2:   /* bools */
	fputs(itob(s[WITH->t - 1].UU.i) ? " TRUE" : "FALSE", stdout);
	break;

      case 3:   /* chars */
	if ((unsigned long)s[WITH->t - 1].UU.i > charh)
	  ps = charchk;
	else
	  putchar((Char)s[WITH->t - 1].UU.i);
	break;

      case 4:   /* reals */
	printf("% .5E", s[WITH->t - 1].UU.r);
	break;

      case 5:   /* bitsets */
	for (h1 = bsmsb; h1 >= 0; h1--) {
	  if ((unsigned long)h1 < 32 &&
	      ((1L << h1) & s[WITH->t - 1].UU.bs) != 0)
	    putchar('1');
	  else
	    putchar('0');
	}
	break;
      }/* case */
      WITH->t--;
      break;
      /* s9 */

    case 30:  /* write formatted */
      h3 = s[WITH->t - 1].UU.i;   /* field width */
      WITH->t--;
      switch (ir.y) {

      case 1:   /* ints */
	printf("%*ld", (int)h3, s[WITH->t - 1].UU.i);
	break;

      case 2:   /* bools */
	printf("%*s", (int)h3, itob(s[WITH->t - 1].UU.i) ? "TRUE" : "FALSE");
	break;

      case 3:
	if ((unsigned long)s[WITH->t - 1].UU.i > charh)
	  ps = charchk;
	else
	  printf("%*c", (int)h3, (Char)s[WITH->t - 1].UU.i);
	break;

      case 4:
	printf("% .*E", P_max((int)h3 - 7, 1), s[WITH->t - 1].UU.r);
	break;

      case 5:
	while (h3 > bsmsb + 1) {
	  putchar(' ');
	  h3--;
	}
	for (h1 = bsmsb; h1 >= 0; h1--) {
	  if ((unsigned long)h1 < 32 &&
	      ((1L << h1) & s[WITH->t - 1].UU.bs) != 0)
	    putchar('1');
	  else
	    putchar('0');
	}
	break;
      }/* case */
      WITH->t--;
      break;
      /* 30 */

    case 31:
      ps = fin;
      break;

    case 32:
      WITH->t = WITH->b - 1;
      WITH->pc = s[WITH->b].UU.i;
      if (WITH->pc != 0)
	WITH->b = s[WITH->b + 2].UU.i;
      else {
	npr--;
	WITH->active = false;
	stepcount = 0;
	ptab[0].active = (npr == 0);

      }
      break;

    case 33:
      /* exit function */
      WITH->t = WITH->b;
      WITH->pc = s[WITH->b].UU.i;
      WITH->b = s[WITH->b + 2].UU.i;
      break;

    case 34:
      s[WITH->t - 1] = s[s[WITH->t - 1].UU.i - 1];
      break;



    case 35:
      s[WITH->t - 1].UU.i = btoi(!itob(s[WITH->t - 1].UU.i));
      break;

    case 36:
      s[WITH->t - 1].UU.i = -s[WITH->t - 1].UU.i;
      break;

    case 37:  /* formatted reals output */
      h3 = s[WITH->t - 2].UU.i;
      h4 = s[WITH->t - 1].UU.i;
      printf("%*.*f", (int)h3, (int)h4, s[WITH->t - 3].UU.r);
      WITH->t -= 3;
      break;

    case 38:
      /*store*/
      s[s[WITH->t - 2].UU.i - 1] = s[WITH->t - 1];
      WITH->t -= 2;

      break;


    case 39:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.r == s[WITH->t].UU.r);
      break;

    case 40:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.r != s[WITH->t].UU.r);
      break;

    case 41:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.r < s[WITH->t].UU.r);
      break;

    case 42:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.r <= s[WITH->t].UU.r);
      break;

    case 43:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.r > s[WITH->t].UU.r);
      break;

    case 44:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.r >= s[WITH->t].UU.r);
      break;


    case 45:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.i == s[WITH->t].UU.i);
      break;

    case 46:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.i != s[WITH->t].UU.i);
      break;

    case 47:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.i < s[WITH->t].UU.i);
      break;

    case 48:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.i <= s[WITH->t].UU.i);
      break;

    case 49:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.i > s[WITH->t].UU.i);
      break;

    case 50:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.i >= s[WITH->t].UU.i);
      break;

    case 51:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(itob(s[WITH->t - 1].UU.i) | itob(s[WITH->t].UU.i));
      break;

    case 52:
      WITH->t--;
      if (s[WITH->t - 1].UU.i > 0 && s[WITH->t].UU.i > 0 ||
	  s[WITH->t - 1].UU.i < 0 && s[WITH->t].UU.i < 0) {
	if (LONG_MAX - labs(s[WITH->t - 1].UU.i) < labs(s[WITH->t].UU.i))
	  ps = ovchk;
      }
      if (ps != ovchk)
	s[WITH->t - 1].UU.i += s[WITH->t].UU.i;
      break;

    case 53:
      WITH->t--;
      if (s[WITH->t - 1].UU.i < 0 && s[WITH->t].UU.i > 0 ||
	  s[WITH->t - 1].UU.i > 0 && s[WITH->t].UU.i < 0) {
	if (LONG_MAX - labs(s[WITH->t - 1].UU.i) < labs(s[WITH->t].UU.i))
	  ps = ovchk;
      }
      if (ps != ovchk)
	s[WITH->t - 1].UU.i -= s[WITH->t].UU.i;
      break;

    case 54:
      WITH->t--;
      if (s[WITH->t - 1].UU.r > 0.0 && s[WITH->t].UU.r > 0.0 ||
	  s[WITH->t - 1].UU.r < 0.0 && s[WITH->t].UU.r < 0.0) {
	if (realmax - fabs(s[WITH->t - 1].UU.r) < fabs(s[WITH->t].UU.r))
	  ps = ovchk;
      }
      if (ps != ovchk)
	s[WITH->t - 1].UU.r += s[WITH->t].UU.r;
      break;

    case 55:
      WITH->t--;
      if (s[WITH->t - 1].UU.r > 0.0 && s[WITH->t].UU.r < 0.0 ||
	  s[WITH->t - 1].UU.r < 0.0 && s[WITH->t].UU.r > 0.0) {
	if (realmax - fabs(s[WITH->t - 1].UU.r) < fabs(s[WITH->t].UU.r))
	  ps = ovchk;
      }
      if (ps != ovchk)
	s[WITH->t - 1].UU.r -= s[WITH->t].UU.r;
      break;

    case 56:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(itob(s[WITH->t - 1].UU.i) & itob(s[WITH->t].UU.i));
      break;

    case 57:
      WITH->t--;
      if (s[WITH->t - 1].UU.i != 0) {
	if (LONG_MAX / labs(s[WITH->t - 1].UU.i) < labs(s[WITH->t].UU.i))
	  ps = ovchk;
      }
      if (ps != ovchk)
	s[WITH->t - 1].UU.i *= s[WITH->t].UU.i;
      break;

    case 58:
      WITH->t--;
      if (s[WITH->t].UU.i == 0)
	ps = divchk;
      else
	s[WITH->t - 1].UU.i /= s[WITH->t].UU.i;
      break;

    case 59:
      WITH->t--;
      if (s[WITH->t].UU.i == 0)
	ps = divchk;
      else {
	s[WITH->t - 1].UU.i %= s[WITH->t].UU.i;
/* p2c: ufpint.pas, line 2342:
 * Note: Using % for possibly-negative arguments [317] */
      }
      break;

    case 60:
      WITH->t--;
      if (fabs(s[WITH->t - 1].UU.r) > 1.0 && fabs(s[WITH->t].UU.r) > 1.0) {
	if (realmax / fabs(s[WITH->t - 1].UU.r) < fabs(s[WITH->t].UU.r))
	  ps = ovchk;
      }
      if (ps != ovchk)
	s[WITH->t - 1].UU.r *= s[WITH->t].UU.r;
      break;

    case 61:
      WITH->t--;
      if (s[WITH->t].UU.r < minreal)
	ps = divchk;
      else
	s[WITH->t - 1].UU.r /= s[WITH->t].UU.r;
      break;


    case 62:
      if (P_eof(stdin))
	ps = redchk;
      else {
	scanf("%*[^\n]");
	getchar();
      }
      break;

    case 63:
      putchar('\n');
      chrcnt = 0;
      break;

    case 64:
      h1 = WITH->t;
      h2 = 0;
      while (s[h1 - 1].UU.i != -1) {
	h1 -= sfsize;
	h2++;
      }  /* h2 is now the number of open guards */
      if (h2 == 0) {
	if (ir.y == 0)
	  ps = guardchk;   /* closed guards and no else/terminate */
	else {
	  if (ir.y == 1)
	    WITH->termstate = true;
	}
      } else {  /* channels/entries to check */
	if (SEXT(ir.x, 4) == 0)   /* priority select */
	  h3 = (long)(xrandom(seedx) * h2);   /* arbitrary choice */
	else
	  h3 = h2 - 1;
	h4 = WITH->t - sfsize - h3 * sfsize + 1;
	    /* h4 points to bottom of "frame" */
	h1 = 1;
	foundcall = false;
	while (!foundcall && h1 <= h2) {
	  if (s[h4 - 1].UU.i == 0) {  /* timeout alternative */
	    if (s[h4 + 2].UU.i < 0)
	      s[h4 + 2].UU.i = sysclock;
	    else
	      s[h4 + 2].UU.i += sysclock;
	    if (WITH->wakeup == 0 || s[h4 + 2].UU.i < WITH->wakeup) {
	      WITH->wakeup = s[h4 + 2].UU.i;
	      WITH->wakestart = s[h4 + 3].UU.i;
	    }
	    h3 = (h3 + 1) % h2;
/* p2c: ufpint.pas, line 2414:
 * Note: Using % for possibly-negative arguments [317] */
	    h4 = WITH->t - sfsize - h3 * sfsize + 1;
	    h1++;
	    continue;
	  }
	  if (s[s[h4 - 1].UU.i - 1].UU.i != 0) {
	    foundcall = true;
	    break;
	  }
	  h3 = (h3 + 1) % h2;
/* p2c: ufpint.pas, line 2423:
 * Note: Using % for possibly-negative arguments [317] */
	  h4 = WITH->t - sfsize - h3 * sfsize + 1;
	  h1++;
	}  /* while not foundcall ... */
	if (!foundcall) {   /* no channel/entry has a call */
	  if (ir.y != 2)   /* ie, if no else part */
	  {  /* sleep on all channels */
	    if (ir.y == 1)
	      WITH->termstate = true;
	    h1 = WITH->t - sfsize + (1 - h2) * sfsize + 1;
	    WITH->chans = h1;
	    FORLIM = h2;
	    for (h3 = 1; h3 <= FORLIM; h3++) {
	      h4 = s[h1 - 1].UU.i;   /* h4 points to channel/entry */
	      if (h4 != 0) {   /* 0 means timeout */
		if (s[h1 + 1].UU.i == 2)   /* entry sleep */
		  s[h4 - 1].UU.i = -s[h1].UU.i;   /* query sleep */
		else {
		  if (s[h1 + 1].UU.i == 0)
		    s[h4 - 1].UU.i = h1 + 1;
		  else {
		    if (s[h1 + 1].UU.i == 1)
		      s[h4 - 1] = s[h1];   /* shriek sleep */
		    else
		      s[h4 - 1].UU.i = -1;
		  }
		}
		s[h4] = s[h1 + 3];   /* wake address */
		s[h4 + 1].UU.i = curpr;
	      }  /* if h4 <> 0 */
	      h1 += sfsize;
	    }  /* for loop */
	    stepcount = 0;
	    WITH->suspend = -h2;
	    WITH->onselect = true;
	    if (WITH->wakeup != 0)
	      joineventq(WITH->wakeup, &V);
	  }  /* sleep on open-guard channels/entries */
	}  /* no call */
	else {  /* someone is waiting */
	  WITH->wakeup = 0;
	  WITH->wakestart = 0;
	  h1 = s[h4 - 1].UU.i;   /* h1 points to channel/entry */
	  if ((unsigned long)s[h4 + 1].UU.i < 32 &&
	      ((1L << s[h4 + 1].UU.i) & 0x7) != 0)
	  {  /* channel rendezvous */
	    if (s[h1 - 1].UU.i < 0 && s[h4 + 1].UU.i == 2 ||
		s[h1 - 1].UU.i > 0 && s[h4 + 1].UU.i < 2)
	      ps = channerror;
	    else {  /* rendezvous */
	      s[h1 - 1].UU.i = labs(s[h1 - 1].UU.i);
	      if (s[h4 + 1].UU.i == 0)
		s[s[h1 - 1].UU.i - 1] = s[h4];
	      else {  /* block copy */
		h3 = 0;
		while (h3 < s[h4 + 2].UU.i) {
		  if (s[h4 + 1].UU.i == 1)
		    s[s[h1 - 1].UU.i + h3 - 1] = s[s[h4].UU.i + h3 - 1];
		  else
		    s[s[h4].UU.i + h3 - 1] = s[s[h1 - 1].UU.i + h3 - 1];
		  h3++;
		}  /* while */
	      }  /* block copy */
	      WITH->pc = s[h4 + 3].UU.i;
	      WITH->repindex = s[h4 + 4].UU.i;   /* recover repindex */
	      /* wake the other process */
	      wakenon(h1, &V);
	    }  /* rendezvous */
	  }  /* channel rendezvous */
	  else
	    WITH->pc = s[h4 + 3].UU.i;   /* entry */
	}  /* someone was waiting */
      }  /* calls to check */
      WITH->t += -h2 * sfsize - 1;
      break;
      /* case 64 */

    case 65:   /* channel write - gld */
      h1 = s[WITH->t - 2].UU.i;   /* h1 now points to channel */
      h2 = s[h1 - 1].UU.i;   /* h2 now has value in channel[1] */
      h3 = s[WITH->t - 1].UU.i;   /* base address of source (for ir.x=1) */
      if (h2 > 0)
	ps = channerror;   /* another writer on this channel */
      else {
	if (h2 == 0) {  /* first */
	  if (SEXT(ir.x, 4) == 0)
	    s[h1 - 1].UU.i = WITH->t;
	  else
	    s[h1 - 1].UU.i = h3;
	  s[h1].UU.i = WITH->pc;
	  s[h1 + 1].UU.i = curpr;
	  WITH->chans = WITH->t - 1;
	  WITH->suspend = -1;
	  stepcount = 0;
	}  /* first */
	else {  /* second */
	  h2 = labs(h2);   /* readers leave negated address */
	  if (SEXT(ir.x, 4) == 0)
	    s[h2 - 1] = s[WITH->t - 1];
	  else {
	    h4 = 0;   /* loop control for block copy */
	    while (h4 < ir.y) {
	      s[h2 + h4 - 1] = s[h3 + h4 - 1];
	      h4++;
	    }  /* while */
	  }  /* ir.x was 1 */
	  wakenon(h1, &V);
	}  /* second */
      }
      WITH->t -= 2;
      break;
      /* case 65 */

    case 66:   /*  channel read - gld */
      h1 = s[WITH->t - 2].UU.i;
      h2 = s[h1 - 1].UU.i;
      h3 = s[WITH->t - 1].UU.i;
      if (h2 < 0)
	ps = channerror;
      else {
	if (h2 == 0) {  /* first */
	  s[h1 - 1].UU.i = -h3;
	  s[h1].UU.i = WITH->pc;
	  s[h1 + 1].UU.i = curpr;
	  WITH->chans = WITH->t - 1;
	  WITH->suspend = -1;
	  stepcount = 0;
	}  /* first */
	else {  /* second */
	  h2 = labs(h2);
	  h4 = 0;
	  while (h4 < ir.y) {
	    s[h3 + h4 - 1] = s[h2 + h4 - 1];
	    h4++;
	  }
	  wakenon(h1, &V);
	}
      }
      WITH->t -= 2;
      break;
      /* case 66 */

    case 67:  /* delay */
      h1 = s[WITH->t - 1].UU.i;
      WITH->t--;
      joinqueue(h1, &V);
      if (WITH->curmon != 0)
	releasemon(WITH->curmon, &V);
      break;
      /* case 67 */


    case 68:  /* resume */
      h1 = s[WITH->t - 1].UU.i;
      WITH->t--;
      if (s[h1 - 1].UU.i > 0) {
	procwake(h1, &V);
	if (WITH->curmon != 0)
	  joinqueue(WITH->curmon + 1, &V);
      }
      break;
      /* case 68 */

    case 69:  /* enter monitor */
      h1 = s[WITH->t - 1].UU.i;   /* address of new monitor variable */
      s[WITH->t - 1].UU.i = WITH->curmon;   /* save old monitor variable */
      WITH->curmon = h1;
      if (s[WITH->curmon - 1].UU.i == 0) {
	s[WITH->curmon - 1].UU.i = -1;

      } else
	joinqueue(WITH->curmon, &V);

      break;
      /* case 69 */

    case 70:  /* exit monitor */
      releasemon(WITH->curmon, &V);
      WITH->curmon = s[WITH->t - 1].UU.i;
      WITH->t--;
      break;
      /* case 70 */

    case 71:  /* execute monitor body code */
      WITH->t++;
      s[WITH->t - 1].UU.i = WITH->pc;
      WITH->pc = ir.y;
      break;
      /* case 70 */

    case 72:  /* return from monitor body code */
      WITH->pc = s[WITH->t - 1].UU.i;
      WITH->t--;
      break;
      /* case 72 */

    case 74:   /* check lower bound */
      if (s[WITH->t - 1].UU.i < ir.y)
	ps = bndchk;
      break;

    case 75:   /* check upper bound */
      if (s[WITH->t - 1].UU.i > ir.y)
	ps = bndchk;
      break;

    case 78:   /* no operation */
      break;

    case 96:   /* pref */
      break;

    case 97:  /* sleep */
      h1 = s[WITH->t - 1].UU.i;
      WITH->t--;
      if (h1 <= 0)
	stepcount = 0;
      else
	joineventq(h1 + sysclock, &V);
      break;
      /* case 97 */

    case 98:  /* set process var on process start-up */
      h1 = s[WITH->t - 1].UU.i;
      WITH->varptr = h1;
      if (s[h1 - 1].UU.i == 0)
	s[h1 - 1].UU.i = curpr;
      else
	ps = instchk;
      WITH->t--;
      break;

    case 99:  /* ecall */
      h1 = WITH->t - ir.y;
      WITH->t = h1 - 2;
      h2 = s[s[h1 - 2].UU.i - 1].UU.i;   /* h2 has process number */
      if (h2 > 0) {
	if (!ptab[h2].active)
	  ps = nexistchk;
	else {
	  h3 = ptab[h2].stackbase + s[h1 - 1].UU.i;   /* h3 points to entry */
	  if (s[h3 - 1].UU.i <= 0) {  /* empty queue on entry */
	    if (s[h3 - 1].UU.i < 0) {  /* other process has arrived */
	      FORLIM = ir.y;
	      for (h4 = 1; h4 <= FORLIM; h4++)
		s[h3 + h4 + entrysize - 2] = s[h1 + h4 - 1];
	      wakenon(h3, &V);
	    }
	    s[h3].UU.i = WITH->pc;
	    s[h3 + 1].UU.i = curpr;
	  }
	  joinqueue(h3, &V);
	  s[WITH->t].UU.i = h3;
	  WITH->chans = WITH->t + 1;
	  WITH->suspend = -1;
	}
      } else {
	if (h2 == 0)
	  ps = nexistchk;
	else
	  ps = namechk;
      }
      break;

    case 100:  /* acpt1 */
      h1 = s[WITH->t - 1].UU.i;   /* h1 points to entry */
      WITH->t--;
      if (s[h1 - 1].UU.i == 0) {  /* no calls - sleep */
	s[h1 - 1].UU.i = -1;
	s[h1].UU.i = WITH->pc;
	s[h1 + 1].UU.i = curpr;
	WITH->suspend = -1;
	WITH->chans = WITH->t + 1;
	stepcount = 0;
      } else {  /* another process has arrived */
	h2 = s[h1 + 1].UU.i;   /* hs has proc number */
	h3 = ptab[h2].t + 3;   /* h3 points to first parameter */
	FORLIM = ir.y;
	for (h4 = 0; h4 < FORLIM; h4++) {
	  s[h1 + h4 + entrysize - 1] = s[h3 + h4 - 1];

	}

      }
      break;

    case 101:  /* acpt2 */
      h1 = s[WITH->t - 1].UU.i;   /* h1 points to entry */
      WITH->t--;
      procwake(h1, &V);

      if (s[h1 - 1].UU.i != 0) {  /* queue non-empty */
	h2 = procqueue.proclist[s[h1 - 1].UU.i - 1].proc;
	    /* h2 has proc id */
	s[h1].UU.i = ptab[h2].pc;
	s[h1 + 1].UU.i = h2;
      }
      break;


    case 102:   /* rep1c */
      s[WITH->display[SEXT(ir.x, 4) - 1] + ir.y - 1].UU.i = WITH->repindex;
      break;

    case 103:   /* rep2c */
      /* replicate tail code */
      h1 = s[WITH->t - 1].UU.i;
      WITH->t--;
      s[h1 - 1].UU.i++;
      WITH->pc = ir.y;
      break;

    case 104:   /* powr2 */
      h1 = s[WITH->t - 1].UU.i;
      if ((unsigned long)h1 >= 32 ||
	  ((1L << h1) & ((1L << (bsmsb + 1)) - (1L << 0))) == 0)
	ps = setchk;
      else
	s[WITH->t - 1].UU.bs = 1L << ((int)h1);
      break;

      /* 104 */

    case 105:   /* btest */
      WITH->t--;
      h1 = s[WITH->t - 1].UU.i;
      if ((unsigned long)h1 >= 32 ||
	  ((1L << h1) & ((1L << (bsmsb + 1)) - (1L << 0))) == 0)
	ps = setchk;
      else
	s[WITH->t - 1].UU.i = btoi((unsigned long)h1 < 32 &&
				   ((1L << h1) & s[WITH->t].UU.bs) != 0);
      break;
      /* 105 */

    case 107:   /* write based */
      h3 = s[WITH->t - 1].UU.i;
      h1 = s[WITH->t - 2].UU.i;
      WITH->t -= 2;
      if (h3 == 8) {
	printf("%11ld", h1);


      } else {
	printf("%8ld", h1);


      }


      break;
      /* 107 */


    case 112:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.bs == s[WITH->t].UU.bs);
      break;
      /* 112 */

    case 113:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.bs != s[WITH->t].UU.bs);
      break;
      /* 113 */

    case 114:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.bs < s[WITH->t].UU.bs);
      break;
      /* 114 */

    case 115:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi((s[WITH->t - 1].UU.bs & (~s[WITH->t].UU.bs)) == 0);
      break;

      /* 115 */


    case 116:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi(s[WITH->t - 1].UU.bs > s[WITH->t].UU.bs);
      break;
      /* 116 */

    case 117:
      WITH->t--;
      s[WITH->t - 1].UU.i = btoi((s[WITH->t].UU.bs & (~s[WITH->t - 1].UU.bs)) == 0);
      break;
      /* 117 */

    case 118:
      WITH->t--;
      s[WITH->t - 1].UU.bs |= s[WITH->t].UU.bs;
      break;
      /* 118 */

    case 119:
      WITH->t--;
      s[WITH->t - 1].UU.bs &= ~s[WITH->t].UU.bs;
      break;
      /* 119 */

    case 120:
      WITH->t--;
      s[WITH->t - 1].UU.bs &= s[WITH->t].UU.bs;
      break;
      /* 120 */

    case 121:   /* sinit */
      if (curpr != 0)
	ps = seminitchk;
      else {
	s[s[WITH->t - 2].UU.i - 1] = s[WITH->t - 1];
	WITH->t -= 2;
      }
      break;

    case 129:  /* prtjmp */
      if (s[WITH->curmon + 1].UU.i == 0)
	WITH->pc = ir.y;
      break;

    case 130:  /* prtsel */
      h1 = WITH->t;
      h2 = 0;
      foundcall = false;
      while (s[h1 - 1].UU.i != -1) {
	h1--;
	h2++;
      }  /* h2 is now the number of open guards */
      if (h2 != 0) {  /* barriers to check */
	h3 = (long)(xrandom(seedx) * h2);   /* arbitrary choice */
	h4 = 0;   /* count of barriers tested */
	while (!foundcall && h4 < h2) {
	  if (s[s[h1 + h3].UU.i - 1].UU.i != 0)
	    foundcall = true;
	  else {
	    h3 = (h3 + 1) % h2;
/* p2c: ufpint.pas, line 2867:
 * Note: Using % for possibly-negative arguments [317] */
	    h4++;
	  }
	}
      }  /* barriers to check */
      if (!foundcall)
	releasemon(WITH->curmon, &V);
      else {
	h3 = s[h1 + h3].UU.i;
	procwake(h3, &V);
      }
      WITH->t = h1 - 1;
      s[WITH->curmon + 1].UU.i = 0;
      WITH->pc = s[WITH->t - 1].UU.i;
      WITH->t--;
      break;

    case 131:  /* prtslp */
      h1 = s[WITH->t - 1].UU.i;
      WITH->t--;
      joinqueue(h1, &V);
      break;

    case 132:  /* prtex */
      if (SEXT(ir.x, 4) == 0)
	WITH->clearresource = true;
      else
	WITH->clearresource = false;
      WITH->curmon = s[WITH->t - 1].UU.i;
      WITH->t--;
      break;

    case 133:   /* prtcnd */
      if (WITH->clearresource) {
	s[WITH->curmon + 1].UU.i = 1;
	WITH->t++;
	s[WITH->t - 1].UU.i = WITH->pc;
	WITH->t++;
	s[WITH->t - 1].UU.i = -1;
	WITH->pc = ir.y;
      }

      break;
    }
    checkclock();

    if (eventqueue.first != NULL) {
      if (eventqueue.time <= sysclock)
	alarmclock(&V);
    }
    statcounter++;
    if (statcounter >= statmax)
      ps = statchk;
  } while (ps == run);

_L98:
  putchar('\n');
  if (ps != fin) {

    expmd();
  } else
    printf("\nProgram terminated normally\n");

_L97:
  putchar('\n');



}  /* runprog */

void
usage(char *s) {
  fprintf(stderr, "usage: ufpint [-nstatmax]%s\n", s);
  exit(1);
}

main(argc, argv)
int argc;
Char *argv[];
{  /* Main */
  FILE *TEMP;

  PASCAL_MAIN(argc, argv);
  argc--; argv++;
  while (argc) {
     if (argv[0][0] == '-') {
       switch (argv[0][1]) {
       case 'n':
         if ((statmax = atol(&argv[0][2])) <= 0L)
           usage(", statmax >= 0");
         break;
       default:
         usage("");
       }
       argc--; argv++;
     } else
       usage("");
  }

  pmdfile = NULL;
  objfile->file = NULL;
  seedx = seed(wallclock());
  TEMP = stdout;
/* p2c: ufpint.pas, line 2938:
 * Note: Taking address of stdout; consider setting VarFiles = 0 [144] */
  putversion(&TEMP);


  getcode();

  do {

    runprog();
    printf("\nType r and RETURN to rerun\n");
    if (P_eof(stdin)) {
      ch = 'x';
      printf("End of data file - program terminating\n\n");
    } else {
      if (P_eoln(stdin)) {
	scanf("%*[^\n]");
	getchar();
      }
      scanf("%c%*[^\n]", &ch);
      getchar();
      if (ch == '\n')
	ch = ' ';
      putchar('\n');
    }

  } while (ch == 'R' || ch == 'r');
  if (objfile->file != NULL)
    fclose(objfile->file);
  if (pmdfile != NULL)
    fclose(pmdfile);
  exit(EXIT_SUCCESS);



}






/* End. */
